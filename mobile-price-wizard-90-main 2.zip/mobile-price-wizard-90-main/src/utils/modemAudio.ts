
export class ModemAudioManager {
  private audioContext: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private soundEnabled: boolean = true;

  constructor(soundEnabled: boolean = true) {
    this.soundEnabled = soundEnabled;
    this.initializeAudio();
  }

  private initializeAudio() {
    if (this.soundEnabled) {
      try {
        this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        this.noiseBuffer = this.createWhiteNoiseBuffer(this.audioContext);
      } catch (error) {
        console.log('Audio context not supported');
        this.soundEnabled = false;
      }
    }
  }

  private createWhiteNoiseBuffer(ctx: AudioContext, duration: number = 2): AudioBuffer {
    const frameCount = ctx.sampleRate * duration;
    const buffer = ctx.createBuffer(1, frameCount, ctx.sampleRate);
    const output = buffer.getChannelData(0);

    for (let i = 0; i < frameCount; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    return buffer;
  }

  playModemHandshakeSequence() {
    if (!this.soundEnabled || !this.audioContext) return;

    const ctx = this.audioContext;
    const startTime = ctx.currentTime;

    // Low pitch dial tone beeps
    this.createDialTone(400, 0.15, startTime);
    this.createDialTone(400, 0.15, startTime + 0.25);
    this.createDialTone(400, 0.15, startTime + 0.5);
  }

  playDataTransmissionSound() {
    if (!this.soundEnabled || !this.audioContext) return;

    const ctx = this.audioContext;
    const startTime = ctx.currentTime;

    // More low pitch beeps during data transmission
    this.createDialTone(350, 0.1, startTime);
    this.createDialTone(350, 0.1, startTime + 0.15);
  }

  playModemConnectedTone() {
    if (!this.soundEnabled || !this.audioContext) return;

    const ctx = this.audioContext;
    const startTime = ctx.currentTime;

    // Success: high pitch beep
    this.createDialTone(800, 0.2, startTime);
  }

  playModemErrorSequence() {
    if (!this.soundEnabled || !this.audioContext) return;

    const ctx = this.audioContext;
    const startTime = ctx.currentTime;

    // Error: low pitch beeps
    this.createDialTone(300, 0.15, startTime);
    this.createDialTone(300, 0.15, startTime + 0.2);
  }

  playCompletionBeep() {
    if (!this.soundEnabled || !this.audioContext) return;

    const ctx = this.audioContext;
    const startTime = ctx.currentTime;

    // Final sequence: low beeps followed by high beep
    this.createDialTone(400, 0.1, startTime);
    this.createDialTone(400, 0.1, startTime + 0.15);
    this.createDialTone(900, 0.3, startTime + 0.35);
  }

  private createDialTone(frequency: number, duration: number, startTime: number) {
    if (!this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);
    
    oscillator.frequency.setValueAtTime(frequency, startTime);
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0, startTime);
    gainNode.gain.linearRampToValueAtTime(0.1, startTime + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
    
    oscillator.start(startTime);
    oscillator.stop(startTime + duration);
  }

  cleanup() {
    if (this.audioContext) {
      this.audioContext.close();
    }
  }

  setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
    if (enabled && !this.audioContext) {
      this.initializeAudio();
    }
  }
}
