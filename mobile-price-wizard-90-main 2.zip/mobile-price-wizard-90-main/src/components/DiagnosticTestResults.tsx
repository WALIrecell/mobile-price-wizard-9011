
import React from 'react';
import { CheckCircle, AlertTriangle } from 'lucide-react';
import { DiagnosticTest } from '../types/diagnostic';

interface DiagnosticTestResultsProps {
  tests: DiagnosticTest[];
}

const DiagnosticTestResults: React.FC<DiagnosticTestResultsProps> = ({ tests }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'testing': return 'text-blue-600 animate-pulse';
      case 'passed': return 'text-green-600';
      case 'failed': return 'text-red-600';
      default: return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'testing': return <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />;
      case 'passed': return <CheckCircle size={16} className="text-green-600" />;
      case 'failed': return <AlertTriangle size={16} className="text-red-600" />;
      default: return <div className="w-4 h-4 border border-gray-300 rounded-full" />;
    }
  };

  return (
    <div className="space-y-3">
      <h3 className="font-semibold text-lg text-white">Component Analysis</h3>
      {tests.map((test, index) => (
        <div key={index} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg border border-purple-500/20">
          <div className="flex items-center gap-3">
            <div className={getStatusColor(test.status)}>
              {test.icon}
            </div>
            <span className={`font-medium text-purple-100`}>
              {test.name}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {getStatusIcon(test.status)}
            <span className={`text-sm font-medium ${getStatusColor(test.status)}`}>
              {test.status === 'pending' && 'Pending'}
              {test.status === 'testing' && 'Scanning...'}
              {test.status === 'passed' && 'No Issues Found'}
              {test.status === 'failed' && 'Issues Detected'}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default DiagnosticTestResults;
