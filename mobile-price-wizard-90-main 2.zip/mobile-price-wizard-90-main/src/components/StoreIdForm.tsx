
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Store } from 'lucide-react';

interface StoreIdFormProps {
  onSubmit: (storeId: string) => void;
}

const StoreIdForm: React.FC<StoreIdFormProps> = ({ onSubmit }) => {
  const [storeId, setStoreId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (storeId.trim()) {
      onSubmit(storeId.trim());
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <Store className="text-blue-600" />
          Store Information
        </CardTitle>
        <p className="text-gray-600">Enter your store ID to continue</p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="storeId">Store ID</Label>
            <Input
              id="storeId"
              type="text"
              value={storeId}
              onChange={(e) => setStoreId(e.target.value)}
              placeholder="Enter store ID (e.g., STORE001, S123, 456)"
              className="w-full text-lg py-3"
              maxLength={20}
              required
            />
            <p className="text-sm text-gray-500">
              Use letters and/or numbers only (max 20 characters)
            </p>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
            disabled={!storeId.trim()}
          >
            Continue to Contact Details
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default StoreIdForm;
