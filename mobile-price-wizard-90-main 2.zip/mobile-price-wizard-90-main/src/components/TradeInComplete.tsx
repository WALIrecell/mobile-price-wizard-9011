
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, X, Phone, Mail } from 'lucide-react';
import { PhoneData } from '../pages/Index';

interface TradeInCompleteProps {
  phoneData: PhoneData;
  offerAccepted: boolean;
  finalPrice?: number;
  onStartNew: () => void;
}

const TradeInComplete: React.FC<TradeInCompleteProps> = ({ 
  phoneData, 
  offerAccepted, 
  finalPrice,
  onStartNew 
}) => {
  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className={`text-center ${offerAccepted ? 'bg-gradient-to-r from-green-50 to-blue-50' : 'bg-gradient-to-r from-gray-50 to-red-50'}`}>
        <CardTitle className={`flex items-center justify-center gap-2 text-2xl ${offerAccepted ? 'text-green-700' : 'text-gray-700'}`}>
          {offerAccepted ? (
            <>
              <CheckCircle className="text-green-600" />
              Trade-In Accepted!
            </>
          ) : (
            <>
              <X className="text-gray-600" />
              Trade-In Declined
            </>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 text-center">
        <div className="py-6">
          {offerAccepted ? (
            <div>
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle size={40} className="text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-green-700">Congratulations!</h3>
              <p className="text-gray-600 mb-4">
                Your trade-in offer of <span className="font-bold text-green-600">${finalPrice}</span> has been accepted.
              </p>
              <div className="bg-green-50 p-4 rounded-lg mb-6">
                <h4 className="font-semibold mb-2 text-green-800">Next Steps:</h4>
                <ul className="text-left space-y-1 text-sm text-green-700">
                  <li>• We'll contact you within 24 hours</li>
                  <li>• Prepare your device for pickup/shipping</li>
                  <li>• Payment will be processed after device inspection</li>
                  <li>• Keep your device in the same condition as evaluated</li>
                </ul>
              </div>
            </div>
          ) : (
            <div>
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <X size={40} className="text-gray-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Thank You for Your Time</h3>
              <p className="text-gray-600 mb-4">
                We understand our offer wasn't quite right for you. Your evaluation has been saved for future reference.
              </p>
              <div className="bg-blue-50 p-4 rounded-lg mb-6">
                <h4 className="font-semibold mb-2 text-blue-800">Other Options:</h4>
                <p className="text-sm text-blue-700">
                  Consider checking back later as prices may change, or explore our other services for device repair and accessories.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Contact Information */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-semibold mb-3">Contact Information:</h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-center gap-2">
              <Phone size={16} className="text-blue-600" />
              <span>Mobile: {phoneData.mobileNumber}</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <Mail size={16} className="text-blue-600" />
              <span>We'll send updates via SMS</span>
            </div>
          </div>
        </div>

        {/* Summary */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-semibold mb-2">Evaluation Summary:</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div><span className="text-gray-600">Device:</span> {phoneData.make} {phoneData.model}</div>
            <div><span className="text-gray-600">Grade:</span> {phoneData.grade}</div>
            <div><span className="text-gray-600">Storage:</span> {phoneData.storage}</div>
            {phoneData.batteryHealth && (
              <div><span className="text-gray-600">Battery:</span> {phoneData.batteryHealth}%</div>
            )}
            <div><span className="text-gray-600">Status:</span> {offerAccepted ? 'Accepted' : 'Declined'}</div>
            <div><span className="text-gray-600">{offerAccepted ? 'Final Price:' : 'Evaluated at:'}</span> 
              <span className={offerAccepted ? 'text-green-600 font-semibold' : 'text-gray-600'}>
                ${finalPrice || phoneData.price}
              </span>
            </div>
          </div>
        </div>

        <Button 
          onClick={onStartNew}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
        >
          Start New Evaluation
        </Button>

        <p className="text-sm text-gray-500">
          All data has been saved to our system. Reference ID: {Date.now()}
        </p>
      </CardContent>
    </Card>
  );
};

export default TradeInComplete;
