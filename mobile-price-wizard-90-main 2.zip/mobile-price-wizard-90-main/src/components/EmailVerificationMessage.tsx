
import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Clock, Mail } from 'lucide-react';

interface EmailVerificationMessageProps {
  email: string;
  onResendEmail?: () => void;
}

const EmailVerificationMessage: React.FC<EmailVerificationMessageProps> = ({ 
  email, 
  onResendEmail 
}) => {
  const [timeRemaining, setTimeRemaining] = useState<string>('');

  useEffect(() => {
    // Calculate time remaining (24 hours from when email was sent)
    const calculateTimeRemaining = () => {
      // Assuming email was sent when component mounts or when resend is clicked
      const emailSentTime = Date.now();
      const expiryTime = emailSentTime + (24 * 60 * 60 * 1000); // 24 hours in milliseconds
      
      const updateTimer = () => {
        const now = Date.now();
        const remaining = expiryTime - now;
        
        if (remaining <= 0) {
          setTimeRemaining('expired');
          return;
        }
        
        const hours = Math.floor(remaining / (1000 * 60 * 60));
        const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
        
        if (hours > 0) {
          setTimeRemaining(`${hours} hour${hours > 1 ? 's' : ''} ${minutes} minute${minutes !== 1 ? 's' : ''}`);
        } else {
          setTimeRemaining(`${minutes} minute${minutes !== 1 ? 's' : ''}`);
        }
      };
      
      updateTimer();
      const interval = setInterval(updateTimer, 60000); // Update every minute
      
      return () => clearInterval(interval);
    };
    
    return calculateTimeRemaining();
  }, []);

  return (
    <Card className="p-6 max-w-md mx-auto bg-blue-50 border-blue-200">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-blue-100 rounded-full">
          <Mail className="h-5 w-5 text-blue-600" />
        </div>
        <h3 className="text-lg font-semibold text-blue-900">
          Check Your Email
        </h3>
      </div>
      
      <div className="space-y-3 text-sm text-gray-700">
        <p>
          We've sent a verification link to <strong>{email}</strong>
        </p>
        
        <div className="flex items-center gap-2 text-blue-700 bg-blue-100 p-3 rounded-lg">
          <Clock className="h-4 w-4" />
          <span>
            {timeRemaining === 'expired' 
              ? 'Link has expired' 
              : `Link expires in ${timeRemaining}`
            }
          </span>
        </div>
        
        <p className="text-xs text-gray-600">
          Don't see the email? Check your spam folder or click below to resend.
        </p>
        
        {onResendEmail && (
          <button
            onClick={onResendEmail}
            className="w-full mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Resend Email
          </button>
        )}
      </div>
    </Card>
  );
};

export default EmailVerificationMessage;
