import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Clock,
  Download,
  Share2,
  Smartphone,
  TrendingUp,
  TrendingDown,
  Minus
} from 'lucide-react';
import { DiagnosticReport } from '../types/enhancedDiagnostic';

interface DiagnosticReportViewerProps {
  report: DiagnosticReport;
  onDownloadReport?: () => void;
  onShareReport?: () => void;
  onStartNewTest?: () => void;
}

const DiagnosticReportViewer: React.FC<DiagnosticReportViewerProps> = ({
  report,
  onDownloadReport,
  onShareReport,
  onStartNewTest
}) => {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreGrade = (score: number) => {
    if (score >= 90) return { grade: 'A+', description: 'Excellent' };
    if (score >= 80) return { grade: 'A', description: 'Very Good' };
    if (score >= 70) return { grade: 'B', description: 'Good' };
    if (score >= 60) return { grade: 'C', description: 'Fair' };
    if (score >= 50) return { grade: 'D', description: 'Poor' };
    return { grade: 'F', description: 'Failed' };
  };

  const formatDuration = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getTestStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'skipped':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getTrendIcon = (score: number) => {
    if (score >= 80) return <TrendingUp className="w-4 h-4 text-green-500" />;
    if (score >= 60) return <Minus className="w-4 h-4 text-yellow-500" />;
    return <TrendingDown className="w-4 h-4 text-red-500" />;
  };

  const { grade, description } = getScoreGrade(report.overallScore);

  const allTests = report.categories.flatMap(cat => cat.tests);
  const passedTests = allTests.filter(test => test.status === 'passed').length;
  const failedTests = allTests.filter(test => test.status === 'failed').length;
  const skippedTests = allTests.filter(test => test.status === 'skipped').length;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Smartphone className="w-8 h-8 text-primary" />
              <div>
                <CardTitle className="text-2xl">Diagnostic Report</CardTitle>
                <p className="text-muted-foreground">
                  {report.deviceInfo.make} {report.deviceInfo.model}
                </p>
                <p className="text-sm text-muted-foreground">
                  Generated on {new Date(report.deviceInfo.timestamp).toLocaleString()}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              {onDownloadReport && (
                <Button variant="outline" onClick={onDownloadReport}>
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              )}
              {onShareReport && (
                <Button variant="outline" onClick={onShareReport}>
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Overall Score */}
      <Card>
        <CardHeader>
          <CardTitle>Overall Device Health</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className={`text-6xl font-bold ${getScoreColor(report.overallScore)}`}>
                {grade}
              </div>
              <div>
                <div className={`text-3xl font-bold ${getScoreColor(report.overallScore)}`}>
                  {report.overallScore}%
                </div>
                <div className="text-lg text-muted-foreground">{description}</div>
              </div>
            </div>
            {getTrendIcon(report.overallScore)}
          </div>
          
          <Progress value={report.overallScore} className="h-2 mb-4" />
          
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-green-600">{passedTests}</div>
              <div className="text-sm text-muted-foreground">Passed</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-red-600">{failedTests}</div>
              <div className="text-sm text-muted-foreground">Failed</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-yellow-600">{skippedTests}</div>
              <div className="text-sm text-muted-foreground">Skipped</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">{formatDuration(report.duration)}</div>
              <div className="text-sm text-muted-foreground">Duration</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Category Results */}
      <div className="grid gap-4 md:grid-cols-2">
        {report.categories.map(category => {
          const categoryTests = category.tests.filter(test => 
            test.status === 'passed' || test.status === 'failed'
          );
          const categoryScore = categoryTests.length > 0 
            ? Math.round(categoryTests.reduce((sum, test) => sum + test.score, 0) / categoryTests.length)
            : 0;
          
          return (
            <Card key={category.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{category.name}</CardTitle>
                  <div className="flex items-center gap-2">
                    {getTrendIcon(categoryScore)}
                    <span className={`text-xl font-bold ${getScoreColor(categoryScore)}`}>
                      {categoryScore}%
                    </span>
                  </div>
                </div>
                <Progress value={categoryScore} className="h-1" />
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {category.tests.map(test => (
                    <div key={test.id} className="flex items-center justify-between py-2">
                      <div className="flex items-center gap-2">
                        {getTestStatusIcon(test.status)}
                        <span className="text-sm">{test.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {test.status === 'passed' || test.status === 'failed' ? (
                          <span className={`text-sm font-medium ${getScoreColor(test.score)}`}>
                            {test.score}%
                          </span>
                        ) : (
                          <Badge variant="secondary" className="text-xs">
                            {test.status}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Recommendations */}
      {report.recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {report.recommendations.map((recommendation, index) => (
                <div key={index} className="flex items-start gap-2 p-3 bg-muted rounded-lg">
                  <AlertTriangle className="w-4 h-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{recommendation}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Device Information */}
      <Card>
        <CardHeader>
          <CardTitle>Device Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <div className="font-medium text-muted-foreground">Make & Model</div>
              <div>{report.deviceInfo.make} {report.deviceInfo.model}</div>
            </div>
            {report.deviceInfo.imei && (
              <div>
                <div className="font-medium text-muted-foreground">IMEI</div>
                <div className="font-mono">{report.deviceInfo.imei}</div>
              </div>
            )}
            <div>
              <div className="font-medium text-muted-foreground">Test Date</div>
              <div>{new Date(report.deviceInfo.timestamp).toLocaleDateString()}</div>
            </div>
            <div>
              <div className="font-medium text-muted-foreground">Test Duration</div>
              <div>{formatDuration(report.duration)}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      {onStartNewTest && (
        <div className="flex justify-center">
          <Button onClick={onStartNewTest} size="lg">
            Run New Diagnostic Test
          </Button>
        </div>
      )}
    </div>
  );
};

export default DiagnosticReportViewer;