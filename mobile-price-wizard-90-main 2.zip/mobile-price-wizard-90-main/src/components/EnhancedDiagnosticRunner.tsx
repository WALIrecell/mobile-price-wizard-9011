import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Smartphone, 
  Monitor, 
  Volume2, 
  Camera, 
  Compass, 
  Wifi, 
  Cpu,
  Play,
  Pause,
  SkipForward,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  Settings
} from 'lucide-react';
import { EnhancedDiagnosticProps, DiagnosticReport, TestCategory, EnhancedDiagnosticTest } from '../types/enhancedDiagnostic';
import { createDiagnosticTestSuite, testRunners } from '../utils/enhancedDiagnosticTests';
import { toast } from '@/components/ui/use-toast';

const categoryIcons: Record<string, React.ComponentType<any>> = {
  display: Monitor,
  audio: Volume2,
  camera: Camera,
  sensors: Compass,
  connectivity: Wifi,
  hardware: Cpu
};

const EnhancedDiagnosticRunner: React.FC<EnhancedDiagnosticProps> = ({ 
  phoneData, 
  onComplete,
  testConfiguration = { categories: [], automated: true, skipPermissionTests: false }
}) => {
  const [categories, setCategories] = useState<TestCategory[]>(() => createDiagnosticTestSuite());
  const [currentCategoryIndex, setCurrentCategoryIndex] = useState(0);
  const [currentTestIndex, setCurrentTestIndex] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [startTime, setStartTime] = useState<number>(0);
  const [selectedCategories, setSelectedCategories] = useState<string[]>(
    testConfiguration.categories.length > 0 ? testConfiguration.categories : categories.map(c => c.id)
  );
  const [showConfiguration, setShowConfiguration] = useState(false);
  
  const abortControllerRef = useRef<AbortController | null>(null);

  const currentCategory = categories[currentCategoryIndex];
  const currentTest = currentCategory?.tests[currentTestIndex];

  const totalTests = categories
    .filter(cat => selectedCategories.includes(cat.id))
    .reduce((sum, cat) => sum + cat.tests.length, 0);
  
  const completedTests = categories
    .filter(cat => selectedCategories.includes(cat.id))
    .reduce((sum, cat) => sum + cat.tests.filter(test => 
      test.status === 'passed' || test.status === 'failed' || test.status === 'skipped'
    ).length, 0);

  const progress = totalTests > 0 ? (completedTests / totalTests) * 100 : 0;

  useEffect(() => {
    if (isRunning && !isPaused && currentTest && currentTest.status === 'pending') {
      runCurrentTest();
    }
  }, [isRunning, isPaused, currentCategoryIndex, currentTestIndex]);

  const runCurrentTest = async () => {
    if (!currentTest || currentTest.status !== 'pending') return;

    // Skip if category not selected
    if (!selectedCategories.includes(currentCategory.id)) {
      moveToNextTest();
      return;
    }

    // Skip permission tests if configured
    if (testConfiguration.skipPermissionTests && currentTest.requiredPermissions) {
      updateTestStatus(currentTest.id, 'skipped', 0, 'Skipped - permissions required');
      moveToNextTest();
      return;
    }

    // Skip manual tests if in automated mode
    if (testConfiguration.automated && !currentTest.automated) {
      updateTestStatus(currentTest.id, 'skipped', 0, 'Skipped - manual test');
      moveToNextTest();
      return;
    }

    updateTestStatus(currentTest.id, 'testing');
    
    try {
      abortControllerRef.current = new AbortController();
      
      const testRunner = testRunners[currentTest.id as keyof typeof testRunners];
      if (testRunner) {
        const result = await testRunner();
        
        if (!abortControllerRef.current.signal.aborted) {
          updateTestStatus(
            currentTest.id, 
            result.passed ? 'passed' : 'failed', 
            result.score,
            result.details
          );
        }
      } else {
        // Fallback for tests without runners
        updateTestStatus(currentTest.id, 'skipped', 0, 'Test runner not implemented');
      }
    } catch (error: any) {
      if (!abortControllerRef.current?.signal.aborted) {
        updateTestStatus(currentTest.id, 'failed', 0, error.message || 'Test failed');
      }
    }

    setTimeout(() => {
      if (!abortControllerRef.current?.signal.aborted) {
        moveToNextTest();
      }
    }, 1000);
  };

  const updateTestStatus = (testId: string, status: EnhancedDiagnosticTest['status'], score = 0, details?: string, errorMessage?: string) => {
    setCategories(prev => prev.map(category => ({
      ...category,
      tests: category.tests.map(test => 
        test.id === testId 
          ? { ...test, status, score, details, errorMessage }
          : test
      )
    })));
  };

  const moveToNextTest = () => {
    const currentCat = categories[currentCategoryIndex];
    if (currentTestIndex < currentCat.tests.length - 1) {
      setCurrentTestIndex(prev => prev + 1);
    } else if (currentCategoryIndex < categories.length - 1) {
      setCurrentCategoryIndex(prev => prev + 1);
      setCurrentTestIndex(0);
    } else {
      // All tests completed
      completeDiagnostics();
    }
  };

  const startDiagnostics = () => {
    setIsRunning(true);
    setStartTime(Date.now());
    setCurrentCategoryIndex(0);
    setCurrentTestIndex(0);
    
    // Reset all test statuses
    setCategories(prev => prev.map(category => ({
      ...category,
      tests: category.tests.map(test => ({
        ...test,
        status: 'pending' as const,
        score: 0,
        details: undefined,
        errorMessage: undefined
      }))
    })));

    toast({
      title: "Diagnostics Started",
      description: `Running ${totalTests} tests across ${selectedCategories.length} categories`,
    });
  };

  const pauseDiagnostics = () => {
    setIsPaused(!isPaused);
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  const skipCurrentTest = () => {
    if (currentTest) {
      updateTestStatus(currentTest.id, 'skipped', 0, 'Manually skipped');
      moveToNextTest();
    }
  };

  const completeDiagnostics = () => {
    setIsRunning(false);
    const endTime = Date.now();
    const duration = endTime - startTime;

    // Calculate overall score
    const allTests = categories.flatMap(cat => cat.tests);
    const scoredTests = allTests.filter(test => test.status === 'passed' || test.status === 'failed');
    const weightedScore = categories.reduce((sum, category) => {
      const categoryTests = category.tests.filter(test => test.status === 'passed' || test.status === 'failed');
      const categoryScore = categoryTests.length > 0 
        ? categoryTests.reduce((testSum, test) => testSum + test.score, 0) / categoryTests.length
        : 0;
      return sum + (categoryScore * category.weight);
    }, 0);

    const report: DiagnosticReport = {
      deviceInfo: {
        make: phoneData.make,
        model: phoneData.model,
        imei: phoneData.imeiNumber,
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString()
      },
      categories,
      overallScore: Math.round(weightedScore),
      completedTests,
      totalTests,
      duration,
      recommendations: generateRecommendations(categories)
    };

    onComplete(report);

    toast({
      title: "Diagnostics Complete",
      description: `Overall score: ${report.overallScore}% (${completedTests}/${totalTests} tests)`,
    });
  };

  const generateRecommendations = (categories: TestCategory[]): string[] => {
    const recommendations: string[] = [];
    const failedTests = categories.flatMap(cat => cat.tests).filter(test => test.status === 'failed');

    if (failedTests.length === 0) {
      recommendations.push("Device is in excellent condition with all tests passing.");
    } else {
      if (failedTests.some(test => test.priority === 'critical')) {
        recommendations.push("Critical issues detected - consider professional repair.");
      }
      if (failedTests.some(test => test.category === 'display')) {
        recommendations.push("Display issues may affect usability and resale value.");
      }
      if (failedTests.some(test => test.category === 'camera')) {
        recommendations.push("Camera problems may indicate hardware damage.");
      }
      if (failedTests.some(test => test.category === 'audio')) {
        recommendations.push("Audio issues may affect call quality and media playback.");
      }
    }

    return recommendations;
  };

  const getTestIcon = (test: EnhancedDiagnosticTest) => {
    switch (test.status) {
      case 'passed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'testing':
        return <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />;
      case 'skipped':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getCategoryProgress = (category: TestCategory) => {
    const total = category.tests.length;
    const completed = category.tests.filter(test => 
      test.status === 'passed' || test.status === 'failed' || test.status === 'skipped'
    ).length;
    return total > 0 ? (completed / total) * 100 : 0;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Smartphone className="w-8 h-8 text-primary" />
              <div>
                <CardTitle className="text-2xl">Enhanced Mobile Diagnostics</CardTitle>
                <p className="text-muted-foreground">
                  {phoneData.make} {phoneData.model} - Comprehensive Testing Suite
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowConfiguration(!showConfiguration)}
            >
              <Settings className="w-4 h-4 mr-2" />
              Configure
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Configuration Panel */}
      {showConfiguration && (
        <Card>
          <CardHeader>
            <CardTitle>Test Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {categories.map(category => {
                const IconComponent = categoryIcons[category.id] || Cpu;
                return (
                  <div key={category.id} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={category.id}
                      checked={selectedCategories.includes(category.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedCategories(prev => [...prev, category.id]);
                        } else {
                          setSelectedCategories(prev => prev.filter(id => id !== category.id));
                        }
                      }}
                      className="rounded"
                    />
                    <label htmlFor={category.id} className="flex items-center gap-2 text-sm font-medium">
                      <IconComponent className="w-4 h-4" />
                      {category.name}
                    </label>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Progress Overview */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Overall Progress</h3>
              <Badge variant={isRunning ? "default" : "secondary"}>
                {isRunning ? (isPaused ? "Paused" : "Running") : "Ready"}
              </Badge>
            </div>
            
            <Progress value={progress} className="h-2" />
            
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>{completedTests} of {totalTests} tests completed</span>
              <span>{Math.round(progress)}%</span>
            </div>

            {/* Control Buttons */}
            <div className="flex gap-2">
              {!isRunning ? (
                <Button onClick={startDiagnostics} disabled={selectedCategories.length === 0}>
                  <Play className="w-4 h-4 mr-2" />
                  Start Diagnostics
                </Button>
              ) : (
                <>
                  <Button variant="outline" onClick={pauseDiagnostics}>
                    <Pause className="w-4 h-4 mr-2" />
                    {isPaused ? "Resume" : "Pause"}
                  </Button>
                  <Button variant="outline" onClick={skipCurrentTest} disabled={!currentTest}>
                    <SkipForward className="w-4 h-4 mr-2" />
                    Skip Test
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Test Categories */}
      <Tabs defaultValue={categories[0]?.id} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
          {categories.map(category => {
            const IconComponent = categoryIcons[category.id] || Cpu;
            return (
              <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-1">
                <IconComponent className="w-4 h-4" />
                <span className="hidden sm:inline">{category.name}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        {categories.map(category => (
          <TabsContent key={category.id} value={category.id}>
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {React.createElement(categoryIcons[category.id] || Cpu, { className: "w-5 h-5" })}
                      {category.name}
                    </CardTitle>
                    <p className="text-muted-foreground">{category.description}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold">{Math.round(getCategoryProgress(category))}%</div>
                    <div className="text-sm text-muted-foreground">Complete</div>
                  </div>
                </div>
                <Progress value={getCategoryProgress(category)} className="h-1" />
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {category.tests.map(test => (
                    <div 
                      key={test.id}
                      className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                        currentTest?.id === test.id && isRunning 
                          ? 'border-primary bg-primary/5' 
                          : 'border-border'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {getTestIcon(test)}
                        <div>
                          <div className="font-medium">{test.name}</div>
                          <div className="text-sm text-muted-foreground">{test.description}</div>
                          {test.details && (
                            <div className="text-xs text-muted-foreground mt-1">{test.details}</div>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge 
                          variant={test.priority === 'critical' ? 'destructive' : 
                                 test.priority === 'high' ? 'default' : 'secondary'}
                          className="mb-1"
                        >
                          {test.priority}
                        </Badge>
                        {test.status !== 'pending' && (
                          <div className="text-lg font-bold">
                            {test.score}%
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default EnhancedDiagnosticRunner;