
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, Upload, AlertTriangle, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface PriceData {
  make: string;
  model: string;
  memorySize: string;
  gradeA: number;
  gradeB: number;
  gradeC: number;
  broken: number;
}

interface AdminPriceUploadProps {
  onPriceDataUploaded: () => void;
}

const AdminPriceUpload: React.FC<AdminPriceUploadProps> = ({ onPriceDataUploaded }) => {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [priceData, setPriceData] = useState<PriceData[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);
  const { toast } = useToast();

  const parseCSV = (csvText: string): PriceData[] => {
    console.log('🔍 CSV PARSING: Starting to parse CSV...');
    console.log('🔍 CSV PARSING: Raw CSV text length:', csvText.length);
    
    // Handle different line endings and clean the text
    const normalizedCsv = csvText.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    const lines = normalizedCsv.split('\n').filter(line => line.trim());
    
    console.log('🔍 CSV PARSING: Total lines after cleaning:', lines.length);
    
    if (lines.length < 2) {
      throw new Error('CSV file must have at least a header row and one data row');
    }

    // More robust CSV parsing to handle quoted fields and commas within quotes
    const parseCSVLine = (line: string): string[] => {
      const result: string[] = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      
      result.push(current.trim());
      return result.map(field => field.replace(/^"(.*)"$/, '$1')); // Remove surrounding quotes
    };

    const headers = parseCSVLine(lines[0]);
    console.log('🔍 CSV PARSING: Headers found:', headers);

    const data: PriceData[] = [];
    const skippedLines: number[] = [];
    const samsungModels: string[] = [];
    const foldModels: string[] = [];
    const s20Models: string[] = [];
    
    for (let i = 1; i < lines.length; i++) {
      try {
        const values = parseCSVLine(lines[i]);
        
        if (values.length < headers.length) {
          console.warn(`🔍 CSV PARSING: Skipping line ${i + 1} - insufficient columns`);
          skippedLines.push(i + 1);
          continue;
        }

        const make = (values[0] || '').trim();
        const model = (values[1] || '').trim();
        const memorySize = (values[2] || '').trim();
        
        // Skip completely empty rows
        if (!make && !model) {
          continue;
        }

        // Track Samsung models specifically
        if (make.toLowerCase().includes('samsung')) {
          samsungModels.push(model);
          
          // Check for fold/flip models with more variations
          const modelLower = model.toLowerCase();
          if (modelLower.includes('fold') || modelLower.includes('flip') || 
              modelLower.includes('z fold') || modelLower.includes('z flip') ||
              modelLower.includes('galaxy z') || modelLower.includes('filp')) {
            foldModels.push(model);
            console.log(`📱 FOUND SAMSUNG FOLD/FLIP: "${model}" at line ${i + 1}`);
          }
          
          // Check for S20 models with more variations
          if (modelLower.includes('s20') || modelLower.includes('s 20') || 
              modelLower.includes('galaxy s20') || modelLower.includes('galaxy s 20')) {
            s20Models.push(model);
            console.log(`📱 FOUND SAMSUNG S20: "${model}" at line ${i + 1}`);
          }
        }

        const rowData: PriceData = {
          make,
          model,
          memorySize,
          gradeA: parseFloat(values[3]) || 0,
          gradeB: parseFloat(values[4]) || 0,
          gradeC: parseFloat(values[5]) || 0,
          broken: parseFloat(values[6]) || 0
        };

        data.push(rowData);
      } catch (error) {
        console.error(`🔍 CSV PARSING: Error parsing line ${i + 1}:`, error);
        skippedLines.push(i + 1);
      }
    }

    console.log('🔍 CSV PARSING SUMMARY:');
    console.log('📊 Total parsed records:', data.length);
    console.log('📊 Samsung models found:', samsungModels.length);
    console.log('📱 Samsung Fold/Flip models:', foldModels.length, foldModels);
    console.log('📱 Samsung S20 models:', s20Models.length, s20Models);
    console.log('⚠️ Skipped lines:', skippedLines.length);

    return data;
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files && event.target.files[0];
    if (!selectedFile) return;

    console.log('📁 FILE UPLOAD: File selected:', selectedFile.name, selectedFile.size, 'bytes');
    setFile(selectedFile);
    setError(null);
    setUploadComplete(false);
    setUploadProgress(0);
  };

  const processFile = async () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select a CSV file first",
        variant: "destructive"
      });
      return;
    }

    try {
      setUploading(true);
      setError(null);
      setUploadProgress(0);

      console.log('📁 FILE PROCESSING: Starting...');

      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const csvText = e.target?.result as string;
          console.log('📁 FILE PROCESSING: CSV loaded, length:', csvText.length);
          
          const parsedData = parseCSV(csvText);
          console.log('📁 FILE PROCESSING: Parsed records:', parsedData.length);

          if (parsedData.length === 0) {
            throw new Error('No valid data found in CSV file');
          }

          // Clear existing data first
          setUploadProgress(5);
          console.log('🗑️ DATABASE: Clearing existing data...');
          const { error: deleteError } = await supabase
            .from('price_data')
            .delete()
            .neq('id', '00000000-0000-0000-0000-000000000000');

          if (deleteError) {
            console.error('🗑️ DATABASE ERROR:', deleteError);
            throw deleteError;
          }

          // Insert all data in small batches to ensure reliability
          setUploadProgress(10);
          const batchSize = 25; // Even smaller batches for maximum reliability
          let totalInserted = 0;

          console.log(`💾 DATABASE: Starting upload of ${parsedData.length} records in batches of ${batchSize}`);

          for (let i = 0; i < parsedData.length; i += batchSize) {
            const batch = parsedData.slice(i, i + batchSize);
            const batchNumber = Math.floor(i / batchSize) + 1;
            const totalBatches = Math.ceil(parsedData.length / batchSize);
            
            console.log(`💾 BATCH ${batchNumber}/${totalBatches}: Uploading records ${i + 1}-${Math.min(i + batchSize, parsedData.length)}`);
            
            const supabaseData = batch.map(item => ({
              make: item.make,
              model: item.model,
              memory_size: item.memorySize,
              grade_a: item.gradeA,
              grade_b: item.gradeB,
              grade_c: item.gradeC,
              broken: item.broken
            }));

            const { data: insertData, error: insertError } = await supabase
              .from('price_data')
              .insert(supabaseData)
              .select('*');

            if (insertError) {
              console.error(`💾 BATCH ${batchNumber} ERROR:`, insertError);
              throw insertError;
            }

            totalInserted += insertData?.length || 0;
            console.log(`💾 BATCH ${batchNumber} SUCCESS: ${insertData?.length} records. Total: ${totalInserted}/${parsedData.length}`);

            // Update progress based on batches completed
            const progress = 10 + ((i + batchSize) / parsedData.length) * 80;
            setUploadProgress(Math.min(progress, 90));

            // Small delay between batches
            await new Promise(resolve => setTimeout(resolve, 200));
          }

          console.log('✅ UPLOAD COMPLETE!');
          console.log(`✅ Total records uploaded: ${totalInserted} out of ${parsedData.length}`);

          // Verify upload
          setUploadProgress(95);
          const { count, error: countError } = await supabase
            .from('price_data')
            .select('*', { count: 'exact', head: true });

          if (countError) {
            console.error('🔍 VERIFICATION ERROR:', countError);
          } else {
            console.log('🔍 VERIFICATION: Records in database:', count);
            
            if (count !== totalInserted) {
              console.warn(`⚠️ MISMATCH: Expected ${totalInserted}, found ${count} in database`);
            }
          }

          // Verify Samsung models are uploaded
          const { data: samsungVerify } = await supabase
            .from('price_data')
            .select('model')
            .eq('make', 'Samsung')
            .order('model');
            
          if (samsungVerify) {
            const dbSamsungModels = samsungVerify.map(item => item.model);
            const dbFoldModels = dbSamsungModels.filter(model => 
              model.toLowerCase().includes('fold') || 
              model.toLowerCase().includes('flip') ||
              model.toLowerCase().includes('z fold') ||
              model.toLowerCase().includes('z flip') ||
              model.toLowerCase().includes('filp')
            );
            const dbS20Models = dbSamsungModels.filter(model => 
              model.toLowerCase().includes('s20') ||
              model.toLowerCase().includes('s 20')
            );
            
            console.log('🔍 DB VERIFICATION: Samsung models in database:', dbSamsungModels.length);
            console.log('🔍 DB VERIFICATION: Fold models in database:', dbFoldModels);
            console.log('🔍 DB VERIFICATION: S20 models in database:', dbS20Models);
          }

          setUploadProgress(100);
          setPriceData(parsedData);
          setUploadComplete(true);
          
          toast({
            title: "Upload successful",
            description: `Successfully uploaded all ${totalInserted} records to database`
          });

          onPriceDataUploaded();
        } catch (err) {
          console.error('❌ UPLOAD ERROR:', err);
          setError(err instanceof Error ? err.message : 'Failed to process file');
          toast({
            title: "Upload failed",
            description: err instanceof Error ? err.message : "Unknown error occurred",
            variant: "destructive"
          });
        } finally {
          setUploading(false);
        }
      };

      reader.onerror = () => {
        console.error('❌ FILE READER ERROR');
        setError('Failed to read file');
        setUploading(false);
      };

      reader.readAsText(file);
    } catch (err) {
      console.error('❌ FILE ERROR:', err);
      setError(err instanceof Error ? err.message : 'Failed to read file');
      setUploading(false);
    }
  };

  const downloadDatabase = async () => {
    try {
      setDownloading(true);
      
      console.log('📥 DOWNLOAD: Fetching all price data...');
      const { data, error } = await supabase
        .from('price_data')
        .select('*')
        .order('make', { ascending: true })
        .order('model', { ascending: true });

      if (error) {
        console.error('📥 DOWNLOAD ERROR:', error);
        throw error;
      }

      if (!data || data.length === 0) {
        toast({
          title: "No data found",
          description: "No price data available to download",
          variant: "destructive"
        });
        return;
      }

      console.log('📥 DOWNLOAD: Retrieved', data.length, 'records');

      // Convert to CSV format
      const headers = ['Make', 'Model', 'Memory Size', 'Grade A', 'Grade B', 'Grade C', 'Broken'];
      const csvContent = [
        headers.join(','),
        ...data.map(row => [
          `"${row.make}"`,
          `"${row.model}"`,
          `"${row.memory_size}"`,
          row.grade_a,
          row.grade_b,
          row.grade_c,
          row.broken
        ].join(','))
      ].join('\n');

      // Create and download file
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', `price_database_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "Download successful",
        description: `Downloaded ${data.length} records as CSV file`
      });

      console.log('📥 DOWNLOAD: Complete');
    } catch (err) {
      console.error('📥 DOWNLOAD ERROR:', err);
      toast({
        title: "Download failed",
        description: err instanceof Error ? err.message : "Failed to download database",
        variant: "destructive"
      });
    } finally {
      setDownloading(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Upload Price Data (CSV)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Current Database</h3>
          <Button
            onClick={downloadDatabase}
            disabled={downloading}
            variant="outline"
            className="flex items-center gap-2"
          >
            {downloading ? (
              <>
                <Download className="h-4 w-4 animate-pulse" />
                Downloading...
              </>
            ) : (
              <>
                <Download className="h-4 w-4" />
                Download CSV
              </>
            )}
          </Button>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="price-data">CSV File Upload</Label>
          <Input
            type="file"
            id="price-data"
            accept=".csv"
            onChange={handleFileUpload}
            disabled={uploading}
          />
          <p className="text-sm text-gray-500">
            Upload a CSV file containing device price data. File should have columns: Make, Model, Memory Size, Grade A, Grade B, Grade C, Broken.
          </p>
        </div>

        {file && (
          <div className="p-3 bg-blue-50 rounded-md">
            <p className="text-sm text-blue-700">
              Selected file: <strong>{file.name}</strong> ({(file.size / 1024).toFixed(1)} KB)
            </p>
          </div>
        )}

        {uploading && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Upload Progress:</Label>
              <span>{uploadProgress.toFixed(0)}%</span>
            </div>
            <Progress value={uploadProgress} />
            <p className="text-sm text-gray-600">
              Processing records in small batches for reliability...
            </p>
          </div>
        )}

        {uploadComplete && (
          <div className="flex items-center space-x-2 text-green-500">
            <CheckCircle className="h-4 w-4" />
            <span>Upload Complete! Successfully uploaded {priceData.length} records.</span>
          </div>
        )}

        {error && (
          <div className="flex items-center space-x-2 text-red-500">
            <AlertTriangle className="h-4 w-4" />
            <span>Error: {error}</span>
          </div>
        )}

        <Button
          onClick={processFile}
          disabled={uploading || !file}
          className="w-full"
        >
          {uploading ? (
            <>
              <Upload className="mr-2 h-4 w-4 animate-spin" />
              Uploading All Records...
            </>
          ) : (
            <>
              <Upload className="mr-2 h-4 w-4" />
              Upload Complete CSV
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default AdminPriceUpload;
