import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Printer, CheckCircle } from 'lucide-react';
import { PhoneData } from '../pages/Index';
import { imeiDiagnosticCache } from '../utils/imeiDiagnosticCache';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface DiagnosticTest {
  name: string;
  status: 'pending' | 'testing' | 'passed' | 'failed';
  icon: React.ReactNode;
  duration: number;
  finalStatus: 'passed' | 'failed';
}

interface PrintReportProps {
  phoneData: PhoneData;
  finalPrice?: number;
  diagnosticResults?: DiagnosticTest[];
  onContinue: () => void;
}

const PrintReport: React.FC<PrintReportProps> = ({ phoneData, finalPrice, diagnosticResults, onContinue }) => {
  const { toast } = useToast();
  // Generate unique transaction number with 3 letters + 3 numbers format
  const generateTransactionNumber = () => {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000000);
    
    // Generate 3 random letters
    let letterPart = '';
    for (let i = 0; i < 3; i++) {
      letterPart += letters.charAt(Math.floor(Math.random() * letters.length));
    }
    
    // Generate 3 numbers ensuring uniqueness with timestamp and random
    const numberPart = ((timestamp % 1000) + random).toString().slice(-3).padStart(3, '0');
    
    return `${letterPart}${numberPart}`;
  };

  // Generate proper Code 128B barcode with correct algorithm
  const generateBarcode = (data: string) => {
    // Code 128B character patterns (103 patterns total)
    const patterns = [
      '11011001100', '11001101100', '11001100110', '10010011000', '10010001100',
      '10001001100', '10011001000', '10011000100', '10001100100', '11001001000',
      '11001000100', '11000100100', '10110011100', '10011011100', '10011001110',
      '10111001100', '10011101100', '10011100110', '11001110010', '11001011100',
      '11001001110', '11011100100', '11001110100', '11101101110', '11101001100',
      '11100101100', '11100100110', '11101100100', '11100110100', '11100110010',
      '11011011000', '11011000110', '11000110110', '10100011000', '10001011000',
      '10001000110', '10110001000', '10001101000', '10001100010', '11010001000',
      '11000101000', '11000100010', '10110111000', '10110001110', '10001101110',
      '10111011000', '10111000110', '10001110110', '11101110110', '11010001110',
      '11000101110', '11011101000', '11011100010', '11011101110', '11101011000',
      '11101000110', '11100010110', '11101101000', '11101100010', '11100011010',
      '11101111010', '11001000010', '11110001010', '10100110000', '10100001100',
      '10010110000', '10010000110', '10000101100', '10000100110', '10110010000',
      '10110000100', '10011010000', '10011000010', '10000110100', '10000110010',
      '11000010010', '11001010000', '11110111010', '11000010100', '10001111010',
      '10100111100', '10010111100', '10010011110', '10111100100', '10011110100',
      '10011110010', '11110100100', '11110010100', '11110010010', '11011011110',
      '11011110110', '11110110110', '10101111000', '10100011110', '10001011110',
      '10111101000', '10111100010', '11110101000', '11110100010', '10111011110',
      '10111101110', '11101011110', '11110101110', '11010000100', '11010010000',
      '11010011100', '11000111010'
    ];

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return '';
    
    // Set canvas size for better resolution
    canvas.width = 600;
    canvas.height = 120;
    
    // Fill white background
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Calculate checksum for Code 128B
    let checksum = 104; // Start B
    for (let i = 0; i < data.length; i++) {
      const charValue = data.charCodeAt(i) - 32; // ASCII to Code 128B value
      checksum += charValue * (i + 1);
    }
    checksum = checksum % 103;
    
    // Build the complete barcode pattern
    let barcodePattern = patterns[104]; // Start B
    
    // Add data characters
    for (let i = 0; i < data.length; i++) {
      const charValue = data.charCodeAt(i) - 32;
      if (charValue >= 0 && charValue < patterns.length) {
        barcodePattern += patterns[charValue];
      }
    }
    
    // Add checksum
    barcodePattern += patterns[checksum];
    
    // Add stop pattern
    barcodePattern += '1100011101011'; // Stop pattern
    
    // Draw the barcode
    ctx.fillStyle = 'black';
    const barWidth = 2; // Width of each bar
    const barHeight = 80;
    const startX = 50;
    let x = startX;
    
    // Draw bars based on pattern (1 = black bar, 0 = white space)
    for (let i = 0; i < barcodePattern.length; i++) {
      if (barcodePattern[i] === '1') {
        ctx.fillRect(x, 20, barWidth, barHeight);
      }
      x += barWidth;
    }
    
    // Add human readable text
    ctx.fillStyle = 'black';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(data, canvas.width / 2, canvas.height - 10);
    
    return canvas.toDataURL();
  };

  // Generate diagnostic issues using cached results for consistency
  const generateDiagnosticIssues = () => {
    const passedMessages = {
      'Camera Sensor Analysis': "✓ Camera sensor: optimal performance verified",
      'CPU Thermal Check': "✓ CPU temperature: within normal operating range",
      'Internal Moisture Scan': "✓ Internal moisture: no detection, device dry",
      'WiFi Connectivity Test': "✓ WiFi connectivity: stable and strong signal",
      'Speaker Performance': "✓ Audio output: clear and balanced performance"
    };

    const failedMessages = {
      'Camera Sensor Analysis': "Camera sensor calibration drift detected",
      'CPU Thermal Check': "Processor heat dissipation variance found",
      'Internal Moisture Scan': "Internal moisture detection: 0.03% humidity",
      'WiFi Connectivity Test': "WiFi antenna signal strength below optimal",
      'Speaker Performance': "Speaker frequency response deviation detected"
    };

    const issues: string[] = [];
    let effectiveResults = diagnosticResults;
    
    // Try to get cached results for consistency if IMEI is available
    if (phoneData.imeiNumber && (!diagnosticResults || diagnosticResults.length === 0)) {
      const cachedResults = imeiDiagnosticCache.getCachedResults(phoneData.imeiNumber);
      if (cachedResults && cachedResults.length > 0) {
        console.log(`📄 Receipt: Using cached diagnostic results for IMEI ${phoneData.imeiNumber}`);
        effectiveResults = cachedResults;
      }
    }
    
    if (effectiveResults && effectiveResults.length > 0) {
      // Use the actual diagnostic results (either passed in or from cache)
      effectiveResults.forEach(test => {
        if (test.status === 'failed' || test.finalStatus === 'failed') {
          const failedMessage = failedMessages[test.name as keyof typeof failedMessages];
          if (failedMessage) {
            issues.push(failedMessage);
          }
        } else if (test.status === 'passed' || test.finalStatus === 'passed') {
          const passedMessage = passedMessages[test.name as keyof typeof passedMessages];
          if (passedMessage) {
            issues.push(passedMessage);
          }
        }
      });
    } else {
      // Fallback if no diagnostic results available
      issues.push(
        "✓ Camera sensor: optimal performance verified",
        "✓ CPU temperature: within normal operating range",
        "✓ Internal moisture: no detection, device dry",
        "✓ WiFi connectivity: stable and strong signal",
        "✓ Audio output: clear and balanced performance"
      );
    }

    return issues;
  };

  const transactionNumber = generateTransactionNumber();
  const diagnosticIssues = generateDiagnosticIssues();
  const acceptedPrice = finalPrice || phoneData.price || 0;
  const priceBarcodeDataUrl = generateBarcode(acceptedPrice.toString());
  const imeiBarcodeDataUrl = phoneData.imeiNumber ? generateBarcode(phoneData.imeiNumber) : '';

  // Notify customer API after transaction
  const notifyCustomer = async () => {
    try {
      const notificationData = {
        transaction_id: transactionNumber,
        amount: acceptedPrice
      };

      console.log('Sending customer notification for transaction:', transactionNumber);

      const { data, error } = await supabase.functions.invoke('notify-customer', {
        body: notificationData
      });

      if (error) {
        console.error('Customer notification error:', error);
        toast({
          title: "Integration Error",
          description: "Failed to send transaction to integration API",
          variant: "destructive",
        });
      } else if (data?.sent) {
        console.log('Customer notification sent successfully');
        toast({
          title: "Info sent to integration",
          description: "Transaction ID and amount successfully transmitted",
          duration: 3000,
        });
      } else {
        console.log('Customer notification skipped:', data?.message);
        toast({
          title: "Integration not configured",
          description: "No integration endpoint configured - continuing normally",
          variant: "default",
        });
      }
    } catch (error) {
      console.error('Failed to notify customer:', error);
      toast({
        title: "Integration Error", 
        description: "Failed to send transaction to integration API",
        variant: "destructive",
      });
    }
  };

  const handlePrint = async () => {
    const printContent = `
      <div style="width: 80mm; font-family: monospace; font-size: 12px; padding: 10px;">
        <div style="height: 144px;"></div>
        
        <div style="text-align: center; border-bottom: 1px solid #000; padding-bottom: 10px; margin-bottom: 10px;">
          <img src="/lovable-uploads/cb795a3c-9617-464e-820d-b73a979a492b.png" alt="ReCell Logo" style="height: 40px; width: auto; margin-bottom: 5px;" />
          <h2 style="margin: 0; font-size: 16px;">TRADE-IN RECEIPT</h2>
          <p style="margin: 5px 0;">Phone Trade-In Center</p>
        </div>
        
        <div style="margin-bottom: 15px;">
          <p><strong>Transaction #:</strong> ${transactionNumber}</p>
          <p><strong>Date:</strong> ${new Date().toLocaleString()}</p>
        </div>
        
        <div style="border-top: 1px solid #000; padding-top: 10px; margin-bottom: 15px;">
          <h3 style="margin: 0 0 10px 0; font-size: 14px; font-weight: bold;">DEVICE DETAILS</h3>
          <p><strong>Make:</strong> ${phoneData.make}</p>
          <p><strong>Model:</strong> ${phoneData.model}</p>
          <p><strong>Storage:</strong> ${phoneData.storage}</p>
          <p><strong>Grade:</strong> ${phoneData.grade}</p>
          <p><strong>Store ID:</strong> ${phoneData.storeId || 'Not provided'}</p>
          ${phoneData.batteryHealth ? `<p><strong>Battery:</strong> ${phoneData.batteryHealth}%</p>` : ''}
          ${phoneData.imeiNumber ? `<p style="font-size: 14px; font-weight: bold;"><strong>IMEI:</strong> ${phoneData.imeiNumber}</p>` : ''}
          
          ${phoneData.imeiNumber && imeiBarcodeDataUrl ? `
            <div style="text-align: center; margin: 15px 0;">
              <img src="${imeiBarcodeDataUrl}" alt="IMEI Barcode" style="width: 300px; height: 80px;" />
            </div>
          ` : ''}
        </div>
        
        <div style="border-top: 1px solid #000; padding-top: 10px; margin-bottom: 15px;">
          <h3 style="margin: 0 0 10px 0; font-size: 14px;">DIAGNOSTIC RESULTS</h3>
          ${diagnosticIssues.map(issue => `<p style="margin: 2px 0; font-size: 11px;">• ${issue}</p>`).join('')}
        </div>
        
        <div style="border-top: 2px solid #000; padding-top: 10px; text-align: center; margin-bottom: 15px;">
          <h3 style="margin: 0 0 5px 0; font-size: 16px;">ACCEPTED PRICE</h3>
          <p style="font-size: 20px; font-weight: bold; margin: 0;">د.إ ${acceptedPrice}</p>
        </div>
        
        <div style="text-align: center; margin-bottom: 15px;">
          <img src="${priceBarcodeDataUrl}" alt="Price Barcode" style="width: 300px; height: 80px;" />
          <p style="font-size: 10px; margin: 5px 0;">Scannable Barcode - Amount: د.إ ${acceptedPrice}</p>
        </div>
        
        <div style="border-top: 1px solid #000; padding-top: 10px; margin-top: 15px; text-align: center; font-size: 10px;">
          <p style="margin: 0;">Contact: ${phoneData.mobileNumber}</p>
          <p style="margin: 5px 0;">Thank you for choosing our service!</p>
          <div style="margin-top: 10px; text-align: left; font-size: 9px;">
            <p style="margin: 2px 0;">1. Validity 7 days from date of test</p>
            <p style="margin: 2px 0;">2. Device once submitted will not returned.</p>
            <p style="margin: 2px 0;">3. Device will be data wiped</p>
          </div>
        </div>
        
        <div style="height: 216px;"></div>
      </div>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Trade-In Receipt - ${transactionNumber}</title>
            <style>
              @media print {
                @page { 
                  size: 80mm auto; 
                  margin: 0; 
                }
                body { margin: 0; }
              }
            </style>
          </head>
          <body>
            ${printContent}
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
      
      // Send notification to customer API after successful print
      notifyCustomer();
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center bg-gradient-to-r from-blue-50 to-green-50">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <Printer className="text-blue-600" />
          Print Receipt
        </CardTitle>
        <p className="text-gray-600">Generate your trade-in receipt</p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Receipt Preview */}
        <div className="bg-white border-2 border-gray-200 rounded-lg p-6 max-w-md mx-auto" style={{ width: '80mm', fontFamily: 'monospace', fontSize: '12px' }}>
          {/* 2 inch top spacing preview (scaled down for display) */}
          <div className="bg-gray-100 border border-dashed border-gray-300 text-center text-xs text-gray-500 mb-2" style={{ height: '30px' }}>
            2" Top Spacing
          </div>
          
          <div className="text-center border-b border-gray-300 pb-2 mb-3">
            <img 
              src="/lovable-uploads/cb795a3c-9617-464e-820d-b73a979a492b.png" 
              alt="ReCell Logo" 
              className="h-8 w-auto mx-auto mb-1"
            />
            <h3 className="font-bold text-sm">TRADE-IN RECEIPT</h3>
            <p className="text-xs">Phone Trade-In Center</p>
          </div>
          
          <div className="mb-3 text-xs">
            <p><strong>Transaction #:</strong> {transactionNumber}</p>
            <p><strong>Date:</strong> {new Date().toLocaleString()}</p>
          </div>
          
          <div className="border-t border-gray-300 pt-2 mb-3">
            <h4 className="font-bold text-xs mb-2">DEVICE DETAILS</h4>
            <div className="text-xs space-y-1">
              <p><strong>Make:</strong> {phoneData.make}</p>
              <p><strong>Model:</strong> {phoneData.model}</p>
              <p><strong>Storage:</strong> {phoneData.storage}</p>
              <p><strong>Grade:</strong> {phoneData.grade}</p>
              <p><strong>Store ID:</strong> {phoneData.storeId || 'Not provided'}</p>
              {phoneData.batteryHealth && (
                <p><strong>Battery:</strong> {phoneData.batteryHealth}%</p>
              )}
              {phoneData.imeiNumber && (
                <p className="text-xs font-bold"><strong>IMEI:</strong> {phoneData.imeiNumber}</p>
              )}
              
              {/* IMEI Barcode Preview */}
              {phoneData.imeiNumber && imeiBarcodeDataUrl && (
                <div className="text-center my-2">
                  <img 
                    src={imeiBarcodeDataUrl} 
                    alt="IMEI Barcode" 
                    className="mx-auto"
                    style={{ width: '220px', height: '60px' }}
                  />
                </div>
              )}
            </div>
          </div>
          
          <div className="border-t border-gray-300 pt-2 mb-3">
            <h4 className="font-bold text-xs mb-2">DIAGNOSTIC RESULTS</h4>
            <div className="text-xs space-y-1">
              {diagnosticIssues.map((issue, index) => (
                <p key={index} className="text-xs">• {issue}</p>
              ))}
            </div>
          </div>
          
          <div className="border-t-2 border-gray-300 pt-2 text-center mb-3">
            <h4 className="font-bold text-sm mb-1">ACCEPTED PRICE</h4>
            <p className="text-lg font-bold">د.إ {acceptedPrice}</p>
          </div>
          
          {/* Price Barcode Section */}
          <div className="text-center mb-3">
            <img 
              src={priceBarcodeDataUrl} 
              alt="Price Barcode" 
              className="mx-auto"
              style={{ width: '220px', height: '50px' }}
            />
            <p className="text-xs mt-1">Scannable Barcode - Amount: د.إ {acceptedPrice}</p>
          </div>
          
          <div className="border-t border-gray-300 pt-2 text-center text-xs">
            <p>Contact: {phoneData.mobileNumber}</p>
            <p className="mt-1">Thank you for choosing our service!</p>
            <div className="mt-2 text-left text-xs space-y-1">
              <p>1. Validity 7 days from date of test</p>
              <p>2. Device once submitted will not returned.</p>
              <p>3. Device will be data wiped</p>
            </div>
          </div>
          
          {/* 3 inch bottom spacing preview (scaled down for display) */}
          <div className="bg-gray-100 border border-dashed border-gray-300 text-center text-xs text-gray-500 mt-2" style={{ height: '40px' }}>
            3" Bottom Spacing
          </div>
        </div>

        {/* Transaction Details */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle size={16} className="text-blue-600" />
            <span className="font-medium">Transaction Information</span>
          </div>
          <div className="text-sm text-blue-700">
            <p><strong>Unique ID:</strong> {transactionNumber} (3 Letters + 3 Numbers)</p>
            <p><strong>Paper Size:</strong> 80mm thermal receipt</p>
            <p><strong>Status:</strong> Ready to print</p>
            <p><strong>Barcode Type:</strong> Code 128B (industry standard)</p>
            <p><strong>Price Barcode Value:</strong> {acceptedPrice} (matches accepted amount)</p>
            {phoneData.imeiNumber && (
              <p><strong>IMEI Barcode:</strong> Code 128B barcode for IMEI: {phoneData.imeiNumber}</p>
            )}
            <p><strong>Spacing:</strong> 2" top + 3" bottom margins</p>
            <p><strong>Validity Terms:</strong> 7 days validity, device submission & data wipe notices included</p>
            {phoneData.imeiNumber && (
              <p><strong>Diagnostic Cache:</strong> Results cached for 24 hours for consistent evaluation</p>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <Button 
            onClick={handlePrint}
            className="py-3 text-lg bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Printer className="mr-2" size={20} />
            Print Receipt
          </Button>
          
          <Button 
            onClick={() => {
              // Send notification when user continues without printing
              notifyCustomer();
              onContinue();
            }}
            variant="outline"
            className="py-3 text-lg"
          >
            Continue
          </Button>
        </div>

        <div className="text-center text-sm text-gray-500">
          <p>Receipt formatted for 80mm thermal printers with scannable Code 128B barcodes</p>
          <p>Price barcode encodes: {acceptedPrice} | {phoneData.imeiNumber ? `IMEI barcode encodes: ${phoneData.imeiNumber}` : 'No IMEI provided'}</p>
          {phoneData.imeiNumber && (
            <p className="text-blue-600">🔄 Diagnostic results cached for 24 hours to ensure consistency</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default PrintReport;
