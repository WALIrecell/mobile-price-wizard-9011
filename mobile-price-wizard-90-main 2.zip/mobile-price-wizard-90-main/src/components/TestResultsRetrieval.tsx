import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle, XCircle, AlertTriangle, Smartphone } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface TestResult {
  multitouchTest?: boolean;
  displayTest?: boolean;
  volumeTest?: boolean;
  cameraTest?: boolean;
  audioTest?: boolean;
  flashTest?: boolean;
  vibrationTest?: boolean;
  wifiTest?: boolean;
  connectivityTest?: boolean;
  batteryTest?: boolean;
  sensorsTest?: boolean;
  performanceTest?: boolean;
  overallScore?: number;
  deviceModel?: string;
}

interface TestResultsRetrievalProps {
  onTestResultsRetrieved: (results: TestResult) => void;
  existingResults?: TestResult | null;
  savedResultCode?: string; // Added to accept pre-saved result code
}

const TestResultsRetrieval: React.FC<TestResultsRetrievalProps> = ({ 
  onTestResultsRetrieved, 
  existingResults,
  savedResultCode 
}) => {
  const [resultCode, setResultCode] = useState(savedResultCode || '');
  const [isRetrieving, setIsRetrieving] = useState(false);
  const [testResults, setTestResults] = useState<TestResult | null>(existingResults || null);
  const { toast } = useToast();

  // Auto-display existing results if they exist
  useEffect(() => {
    if (existingResults && Object.keys(existingResults).length > 0) {
      setTestResults(existingResults);
    }
  }, [existingResults]);

  // Auto-retrieve results if savedResultCode is provided and no existing results
  useEffect(() => {
    if (savedResultCode && !existingResults && !testResults) {
      console.log('🔍 AUTO-RETRIEVING: Using saved result code:', savedResultCode);
      handleCodeSubmit();
    }
  }, [savedResultCode, existingResults, testResults]);

  const testLabels = {
    multitouchTest: 'Multi-touch Screen',
    displayTest: 'Multi-touch Screen',
    volumeTest: 'Volume Buttons',
    cameraTest: 'Camera',
    audioTest: 'Audio & Microphone',
    flashTest: 'Flash/Torch',
    vibrationTest: 'Vibration',
    connectivityTest: 'WiFi Connectivity',
    wifiTest: 'WiFi Connectivity'
  };

  const handleCodeSubmit = async () => {
    if (!resultCode.trim()) {
      toast({
        title: "Code Required",
        description: "Please enter the 5-digit test result code from your phone",
        variant: "destructive",
      });
      return;
    }

    setIsRetrieving(true);

    try {
      const { data, error } = await supabase.functions.invoke('receive-test-results', {
        body: {
          action: 'retrieve',
          resultCode: resultCode.trim()
        }
      });

      if (error) {
        throw new Error('Invalid code or test results not found');
      }

      if (!data?.testResults) {
        throw new Error('No test results found for this code');
      }

      const results = data.testResults;
      setTestResults(results);
      onTestResultsRetrieved(results);

      toast({
        title: "Test Results Retrieved",
        description: `Found test results with ${results.overallScore || 0}% overall score`,
      });

    } catch (error) {
      console.error('Error retrieving test results:', error);
      toast({
        title: "Retrieval Failed",
        description: error.message || "Failed to retrieve test results. Please check your code.",
        variant: "destructive",
      });
    } finally {
      setIsRetrieving(false);
    }
  };

  const getTestIcon = (passed: boolean) => {
    return passed ? (
      <CheckCircle className="w-5 h-5 text-green-600" />
    ) : (
      <XCircle className="w-5 h-5 text-red-600" />
    );
  };

  const getOverallStatus = (score: number) => {
    if (score >= 80) return { color: 'text-green-600', label: 'Excellent' };
    if (score >= 60) return { color: 'text-yellow-600', label: 'Good' };
    return { color: 'text-red-600', label: 'Needs Attention' };
  };

  if (testResults) {
    const score = testResults.overallScore || 0;
    const status = getOverallStatus(score);

    return (
      <Card className="w-full">
        <CardHeader className="bg-blue-50 border-b">
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <Smartphone className="w-6 h-6" />
            Mobile Test Results
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Overall Device Health</h3>
              <div className="text-right">
                <div className="text-2xl font-bold">{score}%</div>
                <div className={`text-sm font-medium ${status.color}`}>
                  {status.label}
                </div>
                {testResults.deviceModel && (
                  <div className="text-xs text-gray-600 mt-1">
                    {testResults.deviceModel}
                  </div>
                )}
              </div>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
              <div 
                className={`h-3 rounded-full transition-all duration-500 ${
                  score >= 80 ? 'bg-green-500' : 
                  score >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                }`}
                style={{ width: `${score}%` }}
              />
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-gray-800 mb-3">Component Test Results:</h4>
            {Object.entries(testLabels).map(([key, label]) => {
              // Check if this test was performed and get its value
              const testValue = testResults[key as keyof TestResult];
              const hasMultitouchTest = testResults.multitouchTest !== undefined || testResults.displayTest !== undefined;
              const hasConnectivityTest = testResults.connectivityTest !== undefined || testResults.wifiTest !== undefined;
              
              // Skip duplicates
              if ((key === 'displayTest' && testResults.multitouchTest !== undefined) ||
                  (key === 'wifiTest' && testResults.connectivityTest !== undefined)) {
                return null;
              }
              
              // For multitouch, check both possible properties
              let passed = false;
              if (key === 'multitouchTest' || key === 'displayTest') {
                passed = !!(testResults.multitouchTest || testResults.displayTest);
              } else if (key === 'connectivityTest' || key === 'wifiTest') {
                passed = !!(testResults.connectivityTest || testResults.wifiTest);
              } else {
                passed = typeof testValue === 'boolean' ? testValue : false;
              }
              
              return (
                <div key={key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium text-gray-700">{label}</span>
                  <div className="flex items-center gap-2">
                    {getTestIcon(passed)}
                    <span className={`text-sm font-medium ${passed ? 'text-green-600' : 'text-red-600'}`}>
                      {passed ? 'Passed' : 'Failed'}
                    </span>
                  </div>
                </div>
              );
            }).filter(Boolean)}
          </div>

          <Button
            onClick={() => {
              setTestResults(null);
              setResultCode('');
            }}
            variant="outline"
            className="w-full mt-4"
          >
            Enter Different Code
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader className="bg-blue-50 border-b">
        <CardTitle className="flex items-center gap-2 text-blue-800">
          <Smartphone className="w-6 h-6" />
          Retrieve Mobile Test Results
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <p className="text-blue-800 font-medium mb-1">Mobile Test Results Available</p>
                <p className="text-blue-700 text-sm">
                  Enter the 5-digit code from your phone's test results to integrate the diagnostic data into your evaluation.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <Label htmlFor="testResultCode" className="text-gray-700 font-medium">
              Test Result Code
            </Label>
            <div className="flex gap-2">
              <Input
                id="testResultCode"
                value={resultCode}
                onChange={(e) => setResultCode(e.target.value.toUpperCase())}
                placeholder="Enter 5-digit code (e.g., A1B2C)"
                className="flex-1 font-mono text-lg text-center"
                maxLength={5}
              />
              <Button 
                onClick={handleCodeSubmit}
                disabled={!resultCode.trim() || isRetrieving}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6"
              >
                {isRetrieving ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Retrieving...
                  </div>
                ) : (
                  'Retrieve Results'
                )}
              </Button>
            </div>
          </div>

          <div className="text-center">
            <Button
              onClick={() => onTestResultsRetrieved({})}
              variant="ghost"
              className="text-gray-600 hover:text-gray-800"
            >
              Skip - No Mobile Test Results
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TestResultsRetrieval;