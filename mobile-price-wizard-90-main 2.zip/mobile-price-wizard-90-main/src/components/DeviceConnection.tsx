import React, { useState, useRef, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Smartphone, Cable, CheckCircle, AlertCircle, Camera, QrCode } from 'lucide-react';
import { BrowserMultiFormatReader } from '@zxing/library';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface DeviceConnectionProps {
  onContinue: (resultCode?: string) => void;
}

const DeviceConnection: React.FC<DeviceConnectionProps> = ({ onContinue }) => {
  console.log('DeviceConnection component rendered');
  
  const [isScanning, setIsScanning] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [resultCode, setResultCode] = useState('');
  const [manualResults, setManualResults] = useState({
    flash: false,
    vibration: false,
    wifi: false,
    multitouch: false,
    volume: false,
    camera: false,
    audio: false
  });
  const [showManualEntry, setShowManualEntry] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const codeReader = useRef<BrowserMultiFormatReader | null>(null);

  const startScanning = async () => {
    try {
      setIsScanning(true);
      
      // Initialize the code reader
      if (!codeReader.current) {
        codeReader.current = new BrowserMultiFormatReader();
      }

      // Get available video devices
      const videoInputDevices = await codeReader.current.listVideoInputDevices();
      
      if (videoInputDevices.length === 0) {
        toast({
          title: "Camera Error",
          description: "No camera found on this device",
          variant: "destructive",
        });
        setIsScanning(false);
        return;
      }

      // Use the first available camera (usually back camera on mobile)
      const deviceId = videoInputDevices[0].deviceId;
      
      // Start decoding from video element
      await codeReader.current.decodeFromVideoDevice(deviceId, videoRef.current!, (result, error) => {
        if (result) {
          handleQRCodeResult(result.getText());
        }
        if (error && !(error instanceof Error)) {
          console.log('QR scanning in progress...');
        }
      });

    } catch (error) {
      console.error('Error starting QR scanner:', error);
      toast({
        title: "Scanner Error",
        description: "Failed to start camera scanner",
        variant: "destructive",
      });
      setIsScanning(false);
    }
  };

  const stopScanning = () => {
    if (codeReader.current) {
      codeReader.current.reset();
    }
    setIsScanning(false);
  };

  const handleQRCodeResult = async (qrData: string) => {
    try {
      console.log('QR Code scanned:', qrData);
      
      // Stop scanning
      stopScanning();
      
      // Parse the QR code data (expecting JSON with test results)
      const testResults = JSON.parse(qrData);
      
      // Send results to our Supabase function
      const { data, error } = await supabase.functions.invoke('receive-test-results', {
        body: {
          sessionId: Date.now().toString(),
          testResults
        }
      });

      if (error) {
        throw error;
      }

      toast({
        title: "Test Results Received",
        description: "Diagnostic test results have been integrated successfully",
      });

      // Continue to next step
      onContinue();

    } catch (error) {
      console.error('Error processing QR code:', error);
      toast({
        title: "QR Code Error",
        description: "Failed to process test results from QR code",
        variant: "destructive",
      });
      setIsScanning(false);
    }
  };

  const handleCodeSubmit = async () => {
    if (!resultCode.trim()) {
      toast({
        title: "Code Required",
        description: "Please enter the 5-digit test result code from your phone",
        variant: "destructive",
      });
      return;
    }

    try {
      // Try to parse as JSON first (if they paste JSON results)
      let testResults;
      try {
        testResults = JSON.parse(resultCode);
        
        // If it's JSON, send it directly for processing
        const { data, error } = await supabase.functions.invoke('receive-test-results', {
          body: {
            sessionId: Date.now().toString(),
            testResults
          }
        });

        if (error) {
          throw error;
        }

        toast({
          title: "Test Results Received",
          description: "JSON test results have been integrated successfully",
        });

        onContinue();
        
      } catch (jsonError) {
        // If not JSON, treat as a 5-digit code and retrieve results
        const { data, error } = await supabase.functions.invoke('receive-test-results', {
          body: {
            action: 'retrieve',
            resultCode: resultCode.trim()
          }
        });

        if (error) {
          throw new Error('Invalid code or test results not found');
        }

        if (!data?.testResults) {
          throw new Error('No test results found for this code');
        }

        // Send the retrieved results to save-to-sheets function
        const { error: saveError } = await supabase.functions.invoke('save-to-sheets', {
          body: {
            phoneData: {
              make: 'Unknown',
              model: 'Unknown', 
              storage: 'Unknown',
              storeId: 'web-entry',
              grade: 'Pending',
              price: 0,
              mobileNumber: 'N/A',
              testResults: {
                multitouchTest: data.testResults.multitouch || data.testResults.multitouchTest?.passed || false,
                volumeTest: data.testResults.volume || data.testResults.volumeTest?.passed || false,
                cameraTest: data.testResults.camera || data.testResults.cameraTest?.passed || false,
                audioTest: data.testResults.audio || data.testResults.audioTest?.passed || false,
                flashTest: data.testResults.flash || data.testResults.flashTest?.passed || false,
                overallScore: data.testResults.overallScore || 0
              }
            }
          }
        });

        if (saveError) {
          console.error('Error saving to sheets:', saveError);
        }

        toast({
          title: "Test Results Retrieved",
          description: "Test results have been retrieved and integrated successfully",
        });

        onContinue(resultCode.trim());
      }

    } catch (error) {
      console.error('Error processing code:', error);
      toast({
        title: "Code Error",
        description: error.message || "Failed to process test results code",
        variant: "destructive",
      });
    }
  };

  const handleManualSubmit = async () => {
    try {
      const testResults = {
        ...manualResults,
        overallScore: Object.values(manualResults).filter(Boolean).length * 14 // Rough score calculation
      };

      // Send results to our Supabase function
      const { data, error } = await supabase.functions.invoke('receive-test-results', {
        body: {
          sessionId: Date.now().toString(),
          testResults
        }
      });

      if (error) {
        throw error;
      }

      toast({
        title: "Test Results Received",
        description: "Manual test results have been integrated successfully",
      });

      onContinue();

    } catch (error) {
      console.error('Error processing manual results:', error);
      toast({
        title: "Error",
        description: "Failed to process manual test results",
        variant: "destructive",
      });
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (codeReader.current) {
        codeReader.current.reset();
      }
    };
  }, []);

  return (
    <div className="relative w-full max-w-6xl mx-auto px-4">
      {/* Main content container */}
      <div className="flex items-center justify-center gap-8 lg:gap-16">
        {/* Center card content */}
        <div className="max-w-2xl">
          <Card className="p-8 bg-white/90 backdrop-blur-sm border border-pink-200 shadow-xl">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full mb-6">
                <Smartphone className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-4">
                Test Your Device
              </h2>
              <p className="text-lg text-gray-700 mb-6">
                Scan the QR code with your smartphone to run comprehensive diagnostic tests.
              </p>
            </div>

            <div className="space-y-6 mb-8">
              {/* QR Code for Device Testing */}
              <div className="flex flex-col items-center justify-center p-6 bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg border border-pink-200">
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(window.location.origin + '/mobile-testing?sessionId=' + Date.now())}`}
                  alt="Device Testing QR Code"
                  className="w-48 h-48 mb-4"
                />
                <p className="text-sm text-gray-600 text-center">
                  Scan with your device's camera to start diagnostic tests
                </p>
              </div>

              {/* Test Result Code Entry */}
              <div className="bg-green-50 rounded-lg p-6 border border-green-200">
                <h3 className="font-semibold text-green-800 mb-4">Enter Test Result Code</h3>
                
                {/* Code Input Method */}
                <div className="space-y-4 mb-6">
                  <div>
                    <Label htmlFor="resultCode" className="text-green-700 font-medium">
                      Enter Test Result Code
                    </Label>
                    <p className="text-sm text-green-600 mb-2">
                      Enter the 5-digit alphanumeric code from your phone's test results
                    </p>
                    <div className="flex gap-2">
                      <Input
                        id="resultCode"
                        value={resultCode}
                        onChange={(e) => setResultCode(e.target.value)}
                        placeholder="Enter 5-digit code (e.g., A1B2C)"
                        className="flex-1"
                        maxLength={5}
                      />
                      <Button 
                        onClick={handleCodeSubmit}
                        disabled={!resultCode.trim()}
                        className="bg-green-600 hover:bg-green-700 text-white"
                      >
                        Submit
                      </Button>
                    </div>
                  </div>
                </div>

              </div>

              <Alert className="border-blue-200 bg-blue-50">
                <AlertCircle className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800">
                  <strong>Note:</strong> You must enter a valid test result code from your phone to proceed. The diagnostic tests will check your device's functionality including multi-touch, volume buttons, cameras, audio, and flash.
                </AlertDescription>
              </Alert>

              <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  Diagnostic Tests Include:
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Multi-touch screen sensitivity test</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Volume button functionality test</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Front and back camera quality test</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Audio output and microphone test</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Camera flash functionality test</span>
                  </li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DeviceConnection;
