
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Database, HardDrive, Zap, AlertTriangle, CheckCircle } from 'lucide-react';

interface UsageStats {
  dailyRecords: number;
  monthlyRecords: number;
  storageUsed: number;
  apiCalls: number;
}

const UsageMonitor: React.FC = () => {
  const [usage, setUsage] = useState<UsageStats>({
    dailyRecords: 0,
    monthlyRecords: 0,
    storageUsed: 0,
    apiCalls: 0
  });

  // Simulate usage tracking (in real app, this would come from Supabase)
  useEffect(() => {
    // This would be replaced with actual Supabase usage API calls
    const simulatedUsage = {
      dailyRecords: Math.floor(Math.random() * 50), // 0-50 records today
      monthlyRecords: Math.floor(Math.random() * 800), // 0-800 records this month
      storageUsed: Math.floor(Math.random() * 200), // 0-200MB used
      apiCalls: Math.floor(Math.random() * 5000) // 0-5000 API calls this month
    };
    setUsage(simulatedUsage);
  }, []);

  const limits = {
    dailyRecords: 500,
    monthlyRecords: 15000, // Estimate based on 500/day
    storageUsed: 500, // 500MB free tier
    apiCalls: 50000 // 50k API calls free tier
  };

  const getUsagePercentage = (used: number, limit: number) => {
    return (used / limit) * 100;
  };

  const getStatusColor = (percentage: number) => {
    if (percentage < 50) return 'text-green-600';
    if (percentage < 80) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStatusIcon = (percentage: number) => {
    if (percentage < 50) return <CheckCircle className="w-4 h-4 text-green-600" />;
    if (percentage < 80) return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
    return <AlertTriangle className="w-4 h-4 text-red-600" />;
  };

  const shouldUpgrade = () => {
    return getUsagePercentage(usage.monthlyRecords, limits.monthlyRecords) > 70 ||
           getUsagePercentage(usage.storageUsed, limits.storageUsed) > 70 ||
           getUsagePercentage(usage.apiCalls, limits.apiCalls) > 70;
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="text-blue-600" />
          Usage Monitor
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {shouldUpgrade() && (
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              You're approaching your usage limits. Consider upgrading to Supabase Pro for higher limits and better performance.
            </AlertDescription>
          </Alert>
        )}

        {/* Daily Records */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              <span className="font-medium">Daily Records</span>
              {getStatusIcon(getUsagePercentage(usage.dailyRecords, limits.dailyRecords))}
            </div>
            <span className={`text-sm font-medium ${getStatusColor(getUsagePercentage(usage.dailyRecords, limits.dailyRecords))}`}>
              {usage.dailyRecords} / {limits.dailyRecords}
            </span>
          </div>
          <Progress 
            value={getUsagePercentage(usage.dailyRecords, limits.dailyRecords)} 
            className="h-2"
          />
        </div>

        {/* Monthly Records */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4" />
              <span className="font-medium">Monthly Records</span>
              {getStatusIcon(getUsagePercentage(usage.monthlyRecords, limits.monthlyRecords))}
            </div>
            <span className={`text-sm font-medium ${getStatusColor(getUsagePercentage(usage.monthlyRecords, limits.monthlyRecords))}`}>
              {usage.monthlyRecords} / {limits.monthlyRecords}
            </span>
          </div>
          <Progress 
            value={getUsagePercentage(usage.monthlyRecords, limits.monthlyRecords)} 
            className="h-2"
          />
        </div>

        {/* Storage Usage */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <HardDrive className="w-4 h-4" />
              <span className="font-medium">Storage Used</span>
              {getStatusIcon(getUsagePercentage(usage.storageUsed, limits.storageUsed))}
            </div>
            <span className={`text-sm font-medium ${getStatusColor(getUsagePercentage(usage.storageUsed, limits.storageUsed))}`}>
              {usage.storageUsed}MB / {limits.storageUsed}MB
            </span>
          </div>
          <Progress 
            value={getUsagePercentage(usage.storageUsed, limits.storageUsed)} 
            className="h-2"
          />
        </div>

        {/* API Calls */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              <span className="font-medium">API Calls (Monthly)</span>
              {getStatusIcon(getUsagePercentage(usage.apiCalls, limits.apiCalls))}
            </div>
            <span className={`text-sm font-medium ${getStatusColor(getUsagePercentage(usage.apiCalls, limits.apiCalls))}`}>
              {usage.apiCalls} / {limits.apiCalls}
            </span>
          </div>
          <Progress 
            value={getUsagePercentage(usage.apiCalls, limits.apiCalls)} 
            className="h-2"
          />
        </div>

        {/* Recommendations */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-semibold text-blue-900 mb-2">Capacity Recommendations</h4>
          <div className="space-y-2 text-sm text-blue-800">
            <p>✅ <strong>10 stores:</strong> Your current setup can easily handle 10 stores</p>
            <p>✅ <strong>500 records/day:</strong> Well within current limits</p>
            <p>⚠️ <strong>Store segregation:</strong> Use store-specific links for better organization</p>
            <p>💡 <strong>Upgrade when:</strong> You consistently exceed 70% of any limit</p>
          </div>
        </div>

        {/* Store Links Information */}
        <div className="bg-green-50 p-4 rounded-lg">
          <h4 className="font-semibold text-green-900 mb-2">Store-Specific Links</h4>
          <div className="space-y-2 text-sm text-green-800">
            <p><strong>Format:</strong> yourapp.com/store/STORE001</p>
            <p><strong>Benefits:</strong></p>
            <ul className="list-disc list-inside ml-4 space-y-1">
              <li>Automatic store identification</li>
              <li>Better data organization</li>
              <li>Store-specific analytics</li>
              <li>Professional appearance</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default UsageMonitor;
