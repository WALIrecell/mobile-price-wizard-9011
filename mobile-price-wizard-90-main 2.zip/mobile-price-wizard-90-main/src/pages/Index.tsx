
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import PhoneInfoForm from '../components/PhoneInfoForm';
import DiagnosticAnimation from '../components/DiagnosticAnimation';
import GradeSelection from '../components/GradeSelection';
import PriceDisplay from '../components/PriceDisplay';
import ContactForm from '../components/ContactForm';
import ReportUpload from '../components/ReportUpload';
import DeviceImages from '../components/DeviceImages';
import TradeInOfferWithIMEI from '../components/TradeInOfferWithIMEI';
import PrintReport from '../components/PrintReport';
import TradeInComplete from '../components/TradeInComplete';
import AdminPriceUpload from '../components/AdminPriceUpload';
import AdminPasswordProtection from '../components/AdminPasswordProtection';
import StaffPasswordProtection from '../components/StaffPasswordProtection';
import AdminQuickEntry from '../components/AdminQuickEntry';
import PriceDataLoader from '../components/PriceDataLoader';
import StoreIdForm from '../components/StoreIdForm';
import UsageMonitor from '../components/UsageMonitor';
import DeviceConnection from '../components/DeviceConnection';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Store } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// FORCE BUILD VERSION UPDATE - UNIQUE TIMESTAMP
const BUILD_VERSION = "2025-06-09-FINAL-DEVICE-CONNECTION-FIRST";
const BUILD_TIMESTAMP = Date.now();

export interface PhoneData {
  make: string;
  model: string;
  storage: string;
  batteryHealth?: number;
  imeiNumber?: string;
  condition?: string;
  storeId?: string;
  mobileNumber?: string;
  grade?: string;
  price?: number;
  reportImage?: File;
  resultCode?: string; // Added for mobile test result code
  testResults?: {
    multitouchTest?: boolean;
    volumeTest?: boolean;
    cameraTest?: boolean;
    audioTest?: boolean;
    flashTest?: boolean;
    vibrationTest?: boolean;
    wifiTest?: boolean;
    overallScore?: number;
    deviceModel?: string;
  };
  aiAnalysis?: {
    grade: string;
    scratchCount: number;
    hasCracks: boolean;
    hasScreenDamage: boolean;
    condition: string;
    confidence: number;
  };
}

interface PriceData {
  make: string;
  model: string;
  memorySize: string;
  gradeA: number;
  gradeB: number;
  gradeC: number;
  broken: number;
}

const Index = () => {
  const { storeId } = useParams<{ storeId: string }>();
  
  // ABSOLUTE REQUIREMENT: START AT STEP 0 - DEVICE CONNECTION
  const [currentStep, setCurrentStep] = useState(0);
  const [phoneData, setPhoneData] = useState<PhoneData>({
    make: '',
    model: '',
    storage: '',
    storeId: storeId || ''
  });
  const [priceData, setPriceData] = useState<PriceData[]>([]);
  const [diagnosticResults, setDiagnosticResults] = useState<any[]>([]);
  const [offerDecision, setOfferDecision] = useState<{accepted: boolean, finalPrice?: number} | null>(null);
  const [activeTab, setActiveTab] = useState('evaluate');
  const [adminAuthenticated, setAdminAuthenticated] = useState(false);
  const [staffAuthenticated, setStaffAuthenticated] = useState(false);
  const { toast } = useToast();

  // FORCE APP TO ALWAYS START AT STEP 0 - DEVICE CONNECTION
  useEffect(() => {
    console.log(`🚀 BUILD VERSION: ${BUILD_VERSION}`);
    console.log(`🚀 BUILD TIMESTAMP: ${BUILD_TIMESTAMP}`);
    console.log('🚀 FORCING START AT STEP 0 - DEVICE CONNECTION SCREEN');
    
    // Aggressive state clearing to prevent any cached state
    try {
      sessionStorage.clear();
      localStorage.clear();
      // Clear history state
      if (window.history && window.history.replaceState) {
        window.history.replaceState(null, '', window.location.pathname);
      }
    } catch (e) {
      console.log('Cache clear failed:', e);
    }
    
    // Absolutely force step to 0
    setCurrentStep(0);
    console.log('🚀 STEP FORCED TO 0 - DEVICE CONNECTION');
  }, []); 

  // Force step 0 on any route change
  useEffect(() => {
    console.log('🚀 Route change detected - forcing step 0');
    setCurrentStep(0);
  }, [storeId]);

  useEffect(() => {
    // Check admin authentication status
    const authStatus = sessionStorage.getItem('admin_authenticated');
    setAdminAuthenticated(authStatus === 'true');
    
    // Check staff authentication status
    const staffAuthStatus = sessionStorage.getItem('staff_authenticated');
    setStaffAuthenticated(staffAuthStatus === 'true');
  }, []);

  const totalSteps = storeId ? 10 : 11;
  const progress = currentStep === 0 ? 0 : ((currentStep - 1) / (totalSteps - 2)) * 100;

  const handleAdminAuthenticated = () => {
    setAdminAuthenticated(true);
  };

  const handleStaffAuthenticated = () => {
    setStaffAuthenticated(true);
  };

  const handleDeviceConnectionContinue = (resultCode?: string) => {
    console.log('=== INDEX.TSX: Device connection continue ===');
    if (resultCode) {
      console.log('=== INDEX.TSX: Saving result code ===', resultCode);
      setPhoneData(prev => ({ ...prev, resultCode }));
    }
    setCurrentStep(1);
  };

  const handlePriceDataLoaded = (data: PriceData[]) => {
    console.log('Price data loaded:', data);
    setPriceData(data);
    if (data.length > 0) {
      setCurrentStep(2);
      setActiveTab('evaluate');
    }
  };

  const handlePriceDataUploaded = () => {
    setCurrentStep(0);
    setPriceData([]);
    setActiveTab('evaluate');
  };

  const handleStoreIdSubmit = (storeId: string) => {
    console.log('=== INDEX.TSX: Store ID submitted ===');
    console.log('Store ID:', storeId);
    
    const updatedPhoneData = { 
      ...phoneData, 
      storeId
    };
    
    console.log('Updated phone data with store ID:', updatedPhoneData);
    
    setPhoneData(updatedPhoneData);
    setCurrentStep(3);
  };

  const handlePhoneInfoSubmit = (data: Partial<PhoneData>) => {
    console.log('=== INDEX.TSX: Phone info submitted ===');
    console.log('Received data:', data);
    console.log('Store ID in received data:', data.storeId);
    console.log('Condition in received data:', data.condition);
    
    const updatedPhoneData = { 
      ...phoneData, 
      ...data
    };
    
    console.log('Updated phone data:', updatedPhoneData);
    console.log('Store ID in updated phone data:', updatedPhoneData.storeId);
    console.log('Condition in updated phone data:', updatedPhoneData.condition);
    
    setPhoneData(updatedPhoneData);
    setCurrentStep(storeId ? 3 : 4);
  };

  const handleContactSubmit = (mobileNumber: string) => {
    console.log('=== INDEX.TSX: Contact submitted ===');
    console.log('Current phone data before contact update:', phoneData);
    console.log('Store ID before contact update:', phoneData.storeId);
    
    const updatedData = { ...phoneData, mobileNumber };
    console.log('Phone data after adding mobile number:', updatedData);
    console.log('Store ID after adding mobile number:', updatedData.storeId);
    
    setPhoneData(updatedData);
    setCurrentStep(storeId ? 4 : 5);
  };

  const handleDiagnosticComplete = (results: any[]) => {
    console.log('=== INDEX.TSX: Diagnostic complete ===');
    console.log('Phone data at diagnostic complete:', phoneData);
    console.log('Store ID at diagnostic complete:', phoneData.storeId);
    console.log('Diagnostic results:', results);
    setDiagnosticResults(results);
    setCurrentStep(storeId ? 5 : 6);
  };

  const handleGradeSelection = (grade: string, price: number) => {
    console.log('=== INDEX.TSX: Grade selected ===');
    console.log('Grade:', grade, 'Price:', price);
    console.log('Current phone data before grade update:', phoneData);
    console.log('Store ID before grade update:', phoneData.storeId);
    
    const updatedData = { ...phoneData, grade, price };
    console.log('Phone data after grade selection:', updatedData);
    console.log('Store ID after grade selection:', updatedData.storeId);
    
    setPhoneData(updatedData);
    setCurrentStep(storeId ? 6 : 7);
  };

  const handlePriceDisplayContinue = () => {
    console.log('=== INDEX.TSX: Price display continue ===');
    console.log('Phone data at price display continue:', phoneData);
    console.log('Store ID at price display continue:', phoneData.storeId);
    setCurrentStep(storeId ? 7 : 8);
  };

  const handleReportUpload = (reportImage: File, testResults?: any, aiAnalysis?: any) => {
    console.log('=== INDEX.TSX: Report upload ===');
    console.log('Current phone data before report upload:', phoneData);
    console.log('Store ID before report upload:', phoneData.storeId);
    console.log('Test results:', testResults);
    console.log('AI Analysis:', aiAnalysis);
    
    let updatedData = { ...phoneData, reportImage, testResults };
    
    // If AI analysis detected a grade, auto-apply it
    if (aiAnalysis && aiAnalysis.grade && priceData.length > 0) {
      const priceInfo = priceData.find(p => 
        p.make.toLowerCase() === updatedData.make.toLowerCase() &&
        p.model.toLowerCase() === updatedData.model.toLowerCase() &&
        p.memorySize.toLowerCase() === updatedData.storage.toLowerCase()
      );
      
      if (priceInfo) {
        let autoPrice = 0;
        let gradeKey = aiAnalysis.grade.toLowerCase();
        
        switch (gradeKey) {
          case 'a':
            autoPrice = priceInfo.gradeA;
            break;
          case 'b':
            autoPrice = priceInfo.gradeB;
            break;
          case 'c':
            autoPrice = priceInfo.gradeC;
            break;
          case 'broken':
            autoPrice = priceInfo.broken;
            break;
          default:
            autoPrice = priceInfo.gradeB; // Default to B grade
        }
        
        updatedData = {
          ...updatedData,
          grade: aiAnalysis.grade,
          price: autoPrice,
          condition: aiAnalysis.condition || `AI detected: ${aiAnalysis.grade} grade`,
          aiAnalysis
        };
        
        toast({
          title: "AI Auto-Grading Applied!",
          description: `Device graded as ${aiAnalysis.grade} - Price: د.إ ${autoPrice}`,
        });
      }
    }
    
    console.log('Phone data after report upload:', updatedData);
    console.log('Store ID after report upload:', updatedData.storeId);
    
    setPhoneData(updatedData);
    setCurrentStep(storeId ? 8 : 9);
  };

  const handleOfferDecision = (accepted: boolean, finalPrice?: number) => {
    console.log('=== INDEX.TSX: Offer decision ===');
    console.log('Phone data at offer decision:', phoneData);
    console.log('Store ID at offer decision:', phoneData.storeId);
    
    setOfferDecision({ accepted, finalPrice });
    if (accepted) {
      setCurrentStep(storeId ? 9 : 10);
    } else {
      setCurrentStep(storeId ? 10 : 11);
    }
  };

  const handlePrintComplete = () => {
    console.log('=== INDEX.TSX: Print complete ===');
    console.log('Phone data at print complete:', phoneData);
    console.log('Store ID at print complete:', phoneData.storeId);
    setCurrentStep(storeId ? 10 : 11);
  };

  const handleStartNew = () => {
    console.log('Starting new evaluation');
    // Reset to step 0 to always show the "Connect Your Device" screen
    setCurrentStep(0);
    setPhoneData({
      make: '',
      model: '',
      storage: '',
      storeId: storeId || ''
    });
    setPriceData([]);
    setOfferDecision(null);
  };

  const handleBackStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderCurrentStep = () => {
    console.log(`🚀 RENDERING STEP: ${currentStep} (Version: ${BUILD_VERSION})`);
    
    // ABSOLUTE REQUIREMENT: Step 0 = DeviceConnection
    if (currentStep === 0) {
      console.log('🚀 RENDERING DEVICE CONNECTION SCREEN');
      return <DeviceConnection onContinue={handleDeviceConnectionContinue} />;
    }
    
    // All other steps
    switch (currentStep) {
      case 1:
        return <PriceDataLoader onPriceDataLoaded={handlePriceDataLoaded} />;
      case 2:
        if (storeId) {
          return <PhoneInfoForm onSubmit={handlePhoneInfoSubmit} priceData={priceData} testResults={phoneData.testResults} />;
        } else {
          return <StoreIdForm onSubmit={handleStoreIdSubmit} />;
        }
      case 3:
        if (storeId) {
          return <ContactForm onSubmit={handleContactSubmit} />;
        } else {
          return <PhoneInfoForm onSubmit={handlePhoneInfoSubmit} priceData={priceData} testResults={phoneData.testResults} />;
        }
      case 4:
        if (storeId) {
          return <DiagnosticAnimation phoneData={phoneData} onComplete={handleDiagnosticComplete} />;
        } else {
          return <ContactForm onSubmit={handleContactSubmit} />;
        }
      case 5:
        if (storeId) {
          return <GradeSelection phoneData={phoneData} priceData={priceData} onGradeSelect={handleGradeSelection} />;
        } else {
          return <DiagnosticAnimation phoneData={phoneData} onComplete={handleDiagnosticComplete} />;
        }
      case 6:
        if (storeId) {
          return <PriceDisplay phoneData={phoneData} onContinue={handlePriceDisplayContinue} />;
        } else {
          return <GradeSelection phoneData={phoneData} priceData={priceData} onGradeSelect={handleGradeSelection} />;
        }
      case 7:
        if (storeId) {
          return <ReportUpload phoneData={phoneData} onUpload={handleReportUpload} />;
        } else {
          return <PriceDisplay phoneData={phoneData} onContinue={handlePriceDisplayContinue} />;
        }
      case 8:
        if (storeId) {
          return <TradeInOfferWithIMEI phoneData={phoneData} priceData={priceData} onOfferDecision={handleOfferDecision} />;
        } else {
          return <ReportUpload phoneData={phoneData} onUpload={handleReportUpload} />;
        }
      case 9:
        if (storeId) {
          return <PrintReport phoneData={phoneData} finalPrice={offerDecision?.finalPrice} diagnosticResults={diagnosticResults} onContinue={handlePrintComplete} />;
        } else {
          return <TradeInOfferWithIMEI phoneData={phoneData} priceData={priceData} onOfferDecision={handleOfferDecision} />;
        }
      case 10:
        if (storeId) {
          return (
            <TradeInComplete 
              phoneData={phoneData} 
              offerAccepted={offerDecision?.accepted || false}
              finalPrice={offerDecision?.finalPrice}
              onStartNew={handleStartNew}
            />
          );
        } else {
          return <PrintReport phoneData={phoneData} finalPrice={offerDecision?.finalPrice} diagnosticResults={diagnosticResults} onContinue={handlePrintComplete} />;
        }
      case 11:
        return (
          <TradeInComplete 
            phoneData={phoneData} 
            offerAccepted={offerDecision?.accepted || false}
            finalPrice={offerDecision?.finalPrice}
            onStartNew={handleStartNew}
          />
        );
      default:
        // Emergency fallback - force to step 0
        console.log('🚀 EMERGENCY FALLBACK - FORCING DEVICE CONNECTION');
        setCurrentStep(0);
        return <DeviceConnection onContinue={handleDeviceConnectionContinue} />;
    }
  };

  const getStepTitle = () => {
    const baseTitles = [
      'Connect Device',
      'Load Price Data',
      'Store Information',
      'ReCell Beta Test',
      'Contact Details',
      'Diagnostic Scan',
      'Condition Assessment',
      'Price Evaluation',
      'Report Upload',
      'Trade-In Offer',
      'Print Receipt',
      'Complete'
    ];
    
    if (storeId) {
      const adjustedTitles = [
        'Connect Device',
        'Load Price Data',
        'ReCell Beta Test',
        'Contact Details',
        'Diagnostic Scan',
        'Condition Assessment',
        'Price Evaluation',
        'Report Upload',
        'Trade-In Offer',
        'Print Receipt',
        'Complete'
      ];
      return adjustedTitles[currentStep];
    }
    
    return baseTitles[currentStep];
  };

  const shouldShowBackButton = () => {
    if (storeId) {
      return currentStep >= 3 && currentStep <= 9;
    } else {
      return currentStep >= 3 && currentStep <= 10;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-pink-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header with Logo and Store Info */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <img 
              src="/lovable-uploads/cb795a3c-9617-464e-820d-b73a979a492b.png" 
              alt="ReCell Logo" 
              className="h-16 w-auto"
            />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-2">
            ReCell Trade-In Center v{BUILD_VERSION}
          </h1>
          <p className="text-lg text-gray-700">
            Evaluate your phone and get instant trade-in offers
          </p>
          
          {phoneData.storeId && (
            <div className="mt-4 inline-flex items-center gap-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-lg">
              <Store size={16} />
              <span className="font-medium">Store: {phoneData.storeId}</span>
            </div>
          )}
        </div>

        {/* Build version confirmation banner */}
        <div className="mb-4 p-4 bg-emerald-100 border border-emerald-300 rounded-lg text-center">
          <div className="text-emerald-800 font-bold text-lg mb-2">
            ✅ LATEST BUILD DEPLOYED: {BUILD_VERSION}
          </div>
          <div className="text-emerald-700 text-sm">
            Current Step: {currentStep} | Expected: 0 (Connect Your Device Screen)
          </div>
          <div className="text-emerald-600 text-xs mt-1">
            Build Timestamp: {new Date(BUILD_TIMESTAMP).toLocaleString()}
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full grid-cols-4 bg-white/70 backdrop-blur-sm border border-pink-200">
            <TabsTrigger value="evaluate" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-purple-500 data-[state=active]:text-white">Device Evaluation</TabsTrigger>
            <TabsTrigger value="quick-entry" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-purple-500 data-[state=active]:text-white">Staff Quick Entry</TabsTrigger>
            <TabsTrigger value="admin" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-purple-500 data-[state=active]:text-white">Admin: Upload Prices</TabsTrigger>
            <TabsTrigger value="usage" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-purple-500 data-[state=active]:text-white">Usage Monitor</TabsTrigger>
          </TabsList>
          
          <TabsContent value="evaluate">
            {/* Progress Bar - only show if not step 0 */}
            {currentStep > 0 && currentStep < totalSteps && (
              <Card className="p-6 mb-8 bg-white/80 backdrop-blur-sm border border-pink-200 shadow-lg">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                    Step {currentStep === 1 ? 1 : currentStep - 1} of {totalSteps - 2}: {getStepTitle()}
                  </h2>
                  <span className="text-sm text-gray-600">{Math.round(progress)}% Complete</span>
                </div>
                <Progress value={progress} className="h-3 bg-pink-100" />
              </Card>
            )}

            {/* Back Button */}
            {shouldShowBackButton() && (
              <div className="mb-4">
                <Button 
                  onClick={handleBackStep}
                  variant="outline"
                  className="flex items-center gap-2 border-pink-300 text-pink-700 hover:bg-pink-50"
                >
                  <ArrowLeft size={16} />
                  Back
                </Button>
              </div>
            )}

            {/* Main Content - DEVICE CONNECTION FIRST */}
            <div className="animate-fade-in">
              {renderCurrentStep()}
            </div>
          </TabsContent>
          
          <TabsContent value="quick-entry">
            {!staffAuthenticated ? (
              <StaffPasswordProtection onAuthenticated={handleStaffAuthenticated} />
            ) : (
              <AdminQuickEntry onDataAdded={() => toast({ title: "Price added successfully", description: "The device price has been saved to the database." })} />
            )}
          </TabsContent>
          
          <TabsContent value="admin">
            {!adminAuthenticated ? (
              <AdminPasswordProtection onAuthenticated={handleAdminAuthenticated} />
            ) : (
              <AdminPriceUpload onPriceDataUploaded={handlePriceDataUploaded} />
            )}
          </TabsContent>
          
          <TabsContent value="usage">
            <UsageMonitor />
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-600">
          <p>Powered by ReCell Advanced Phone Diagnostic & Trade-In Technology</p>
        </div>
      </div>
    </div>
  );
};

export default Index;
