
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, Database, Upload, LogOut, Plus } from 'lucide-react';
import AdminPasswordProtection from '@/components/AdminPasswordProtection';
import AdminPriceUpload from '@/components/AdminPriceUpload';
import AdminQuickEntry from '@/components/AdminQuickEntry';
import PriceDataLoader from '@/components/PriceDataLoader';

const Admin = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [priceDataLoaded, setPriceDataLoaded] = useState(false);

  useEffect(() => {
    // Force check authentication status on every load
    const authStatus = sessionStorage.getItem('admin_authenticated');
    console.log('Admin auth check:', authStatus);
    
    // Only set to true if explicitly authenticated
    if (authStatus === 'true') {
      setIsAuthenticated(true);
    } else {
      // Clear any stale session data
      sessionStorage.removeItem('admin_authenticated');
      setIsAuthenticated(false);
    }
  }, []);

  const handleAuthenticated = () => {
    console.log('Admin authenticated successfully');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    console.log('Admin logging out');
    sessionStorage.removeItem('admin_authenticated');
    setIsAuthenticated(false);
  };

  const handlePriceDataUploaded = () => {
    setPriceDataLoaded(true);
  };

  const handlePriceDataLoaded = () => {
    setPriceDataLoaded(true);
  };

  // Always show password protection if not authenticated
  if (!isAuthenticated) {
    console.log('Showing password protection');
    return <AdminPasswordProtection onAuthenticated={handleAuthenticated} />;
  }

  console.log('Showing admin panel');
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Shield className="h-8 w-8 text-green-600" />
            <h1 className="text-3xl font-bold">Admin Panel</h1>
          </div>
          <Button 
            onClick={handleLogout} 
            variant="outline" 
            className="flex items-center gap-2"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>

        <Tabs defaultValue="upload" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upload" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Upload CSV
            </TabsTrigger>
            <TabsTrigger value="quick-entry" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Quick Entry
            </TabsTrigger>
            <TabsTrigger value="database" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              Database Status
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Bulk Price Data Upload</CardTitle>
                <p className="text-sm text-gray-600">
                  Upload CSV files containing device pricing information. This will replace all existing price data.
                </p>
              </CardHeader>
              <CardContent>
                <AdminPriceUpload onPriceDataUploaded={handlePriceDataUploaded} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quick-entry" className="space-y-6">
            <AdminQuickEntry onDataAdded={handlePriceDataUploaded} />
          </TabsContent>

          <TabsContent value="database" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Database Status & Verification</CardTitle>
                <p className="text-sm text-gray-600">
                  View current database status and verify uploaded data.
                </p>
              </CardHeader>
              <CardContent>
                <PriceDataLoader onPriceDataLoaded={handlePriceDataLoaded} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;
