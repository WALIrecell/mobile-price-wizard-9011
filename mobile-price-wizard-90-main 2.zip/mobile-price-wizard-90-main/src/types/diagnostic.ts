
import { ReactNode } from 'react';

export interface DiagnosticTest {
  name: string;
  icon?: ReactNode;
  iconName?: 'Camera' | 'Cpu' | 'Smartphone' | 'Wifi' | 'Speaker';
  status: 'pending' | 'testing' | 'passed' | 'failed';
  duration: number;
  finalStatus: 'passed' | 'failed';
}

export interface DiagnosticAnimationProps {
  phoneData: {
    make: string;
    model: string;
    imeiNumber?: string;
  };
  onComplete: (diagnosticResults: DiagnosticTest[]) => void;
}
