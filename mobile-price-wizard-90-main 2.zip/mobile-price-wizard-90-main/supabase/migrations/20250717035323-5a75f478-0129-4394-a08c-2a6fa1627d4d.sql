-- Remove existing voucher integration tables
DROP TABLE IF EXISTS public.voucher_verifications;
DROP TABLE IF EXISTS public.vouchers;

-- Remove the update function if no longer needed by other tables
DROP FUNCTION IF EXISTS public.update_updated_at_column();