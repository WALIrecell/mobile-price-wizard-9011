
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

export async function uploadImageToSupabase(reportImage: string): Promise<string> {
  if (!reportImage) {
    return '';
  }

  try {
    console.log('Uploading image to Supabase Storage...');
    
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    const base64Data = reportImage.split(',')[1];
    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `diagnostic-report-${timestamp}.jpg`;
    
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === 'diagnostic-reports');
    
    if (!bucketExists) {
      console.log('Creating diagnostic-reports bucket...');
      const { error: bucketError } = await supabase.storage.createBucket('diagnostic-reports', {
        public: true,
        allowedMimeTypes: ['image/jpeg', 'image/png', 'image/jpg'],
        fileSizeLimit: 10485760
      });
      
      if (bucketError) {
        console.error('Error creating bucket:', bucketError);
      } else {
        console.log('Bucket created successfully');
      }
    }
    
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('diagnostic-reports')
      .upload(filename, byteArray, {
        contentType: 'image/jpeg',
        upsert: false
      });

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return 'Failed to upload image';
    }

    const { data: urlData } = supabase.storage
      .from('diagnostic-reports')
      .getPublicUrl(filename);

    console.log('Image uploaded successfully, URL:', urlData.publicUrl);
    return urlData.publicUrl;
  } catch (error) {
    console.error('Error uploading image:', error);
    return 'Error uploading image';
  }
}
