
export interface PhoneData {
  make: string;
  model: string;
  storage: string;
  batteryHealth?: number;
  imeiNumber?: string;
  storeId: string;
  condition?: string;
  grade: string;
  price: number;
  mobileNumber: string;
  reportImage?: string;
  offerStatus?: string;
  testResults?: {
    multitouchTest: boolean;
    volumeTest: boolean;
    cameraTest: boolean;
    audioTest: boolean;
    flashTest: boolean;
    overallScore: number;
  };
}

export interface GoogleTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}
