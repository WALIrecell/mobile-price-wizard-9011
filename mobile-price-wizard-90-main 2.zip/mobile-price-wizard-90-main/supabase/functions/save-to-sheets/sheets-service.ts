
import { PhoneData } from './types.ts';

export async function saveToGoogleSheets(phoneData: PhoneData, imageUrl: string, accessToken: string): Promise<any> {
  const sheetId = Deno.env.get('GOOGLE_SHEET_ID');
  if (!sheetId) {
    throw new Error('Missing Google Sheet ID');
  }

  console.log('🔄 Using explicit cell range approach');
  
  const timestamp = new Date().toISOString();
  const offerStatus = phoneData.offerStatus || 'EVALUATED';
  
  // Store ID debugging
  console.log('🚨 STORE ID ANALYSIS:');
  console.log('  - phoneData.storeId:', phoneData.storeId);
  console.log('  - Type:', typeof phoneData.storeId);
  console.log('  - Length:', phoneData.storeId?.length);
  
  const storeIdValue = phoneData.storeId?.toString()?.trim() || 'MISSING_STORE_ID';
  console.log('  - Final storeIdValue:', storeIdValue);
  
  // IMEI debugging
  console.log('🚨 IMEI ANALYSIS:');
  console.log('  - phoneData.imeiNumber:', phoneData.imeiNumber);
  console.log('  - Type:', typeof phoneData.imeiNumber);
  console.log('  - Length:', phoneData.imeiNumber?.length);
  
  const imeiValue = phoneData.imeiNumber?.toString()?.trim() || '';
  console.log('  - Final imeiValue:', imeiValue);
  
  // First, let's get the current sheet data to find the next row
  const readUrl = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Sheet1!A:N`;
  
  let nextRow = 2; // Default to row 2 if sheet is empty
  try {
    const readResponse = await fetch(readUrl, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    });
    
    if (readResponse.ok) {
      const readData = await readResponse.json();
      nextRow = (readData.values?.length || 1) + 1;
      console.log('📊 Current sheet has', readData.values?.length || 0, 'rows, writing to row', nextRow);
    }
  } catch (error) {
    console.log('⚠️ Could not read current sheet data, using default row 2');
  }

  // Create test results summary
  const testResultsSummary = phoneData.testResults ? 
    `Multitouch:${phoneData.testResults.multitouchTest || phoneData.testResults.displayTest ? 'PASS' : 'FAIL'}|Volume:${phoneData.testResults.volumeTest ? 'PASS' : 'FAIL'}|Camera:${phoneData.testResults.cameraTest ? 'PASS' : 'FAIL'}|Audio:${phoneData.testResults.audioTest ? 'PASS' : 'FAIL'}|Flash:${phoneData.testResults.flashTest ? 'PASS' : 'FAIL'}|Vibration:${phoneData.testResults.vibrationTest ? 'PASS' : 'FAIL'}|WiFi:${phoneData.testResults.connectivityTest ? 'PASS' : 'FAIL'}|Score:${phoneData.testResults.overallScore || 0}|Device:${phoneData.testResults.deviceModel || 'Unknown'}` : 
    'No test results';

  // Create the row data array - IMEI goes in column N, Test Results in column O
  const rowValues = [
    timestamp,                                    // A - Timestamp
    phoneData.make || '',                        // B - Make  
    phoneData.model || '',                       // C - Model
    phoneData.storage || '',                     // D - Storage
    phoneData.batteryHealth?.toString() || '',   // E - Battery Health
    storeIdValue,                               // F - Store ID
    phoneData.condition || '',                   // G - CONDITION
    phoneData.grade || '',                       // H - GRADE
    phoneData.price?.toString() || '0',          // I - PRICE
    phoneData.mobileNumber || '',                // J - MOBILE NUMBER
    imageUrl || 'No image uploaded',             // K - REPORT
    offerStatus,                                 // L - STATUS
    '',                                          // M - Empty column
    imeiValue,                                   // N - IMEI (mapped to column N as requested)
    testResultsSummary                           // O - TEST RESULTS
  ];

  console.log('📊 ROW DATA TO WRITE:');
  rowValues.forEach((value, index) => {
    const columnLetter = String.fromCharCode(65 + index);
    console.log(`  ${columnLetter}${nextRow}: "${value}" (${typeof value})`);
  });

  // Use explicit range approach - now correctly maps to A through O
  const range = `Sheet1!A${nextRow}:O${nextRow}`;
  const updateUrl = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?valueInputOption=RAW`;
  
  const requestBody = {
    values: [rowValues]
  };
  
  console.log('📤 WRITING TO RANGE:', range);
  console.log('📤 REQUEST BODY:', JSON.stringify(requestBody, null, 2));
  console.log('📤 STORE ID IN COLUMN F:', requestBody.values[0][5]);
  console.log('📤 IMEI IN COLUMN N:', requestBody.values[0][13]);

  const updateResponse = await fetch(updateUrl, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestBody),
  });

  console.log('📥 GOOGLE SHEETS RESPONSE STATUS:', updateResponse.status);
  console.log('📥 GOOGLE SHEETS RESPONSE OK:', updateResponse.ok);

  if (!updateResponse.ok) {
    const errorText = await updateResponse.text();
    console.error('❌ Update API failed:', errorText);
    throw new Error(`Update API failed: ${updateResponse.statusText} - ${errorText}`);
  }

  const updateData = await updateResponse.json();
  console.log('✅ UPDATE API SUCCESS!');
  console.log('✅ Response:', JSON.stringify(updateData, null, 2));

  // Read back the specific range to verify the data was written
  console.log('🔍 VERIFYING WRITTEN DATA...');
  try {
    const verifyResponse = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}`,
      {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      }
    );
    
    if (verifyResponse.ok) {
      const verifyData = await verifyResponse.json();
      console.log('🔍 VERIFICATION DATA:', JSON.stringify(verifyData, null, 2));
      const writtenRow = verifyData.values?.[0];
      console.log('🔍 WRITTEN ROW:', writtenRow);
      console.log('🔍 STORE ID IN COLUMN F (index 5):', writtenRow?.[5]);
      console.log('🔍 IMEI IN COLUMN N (index 13):', writtenRow?.[13]);
      console.log('🔍 STORE ID MATCHES EXPECTED:', writtenRow?.[5] === storeIdValue);
      console.log('🔍 IMEI MATCHES EXPECTED:', writtenRow?.[13] === imeiValue);
    }
  } catch (verifyError) {
    console.log('⚠️ Could not verify written data:', verifyError);
  }

  return {
    updatedRange: range,
    storeIdValue: storeIdValue,
    imeiValue: imeiValue,
    rowNumber: nextRow,
    debug: {
      storeIdReceived: phoneData.storeId,
      storeIdSaved: storeIdValue,
      imeiReceived: phoneData.imeiNumber,
      imeiSaved: imeiValue,
      method: 'values:update with explicit range',
      rowData: rowValues,
      columnF: rowValues[5],
      columnN: rowValues[13],
      fullApiResponse: updateData,
      sheetId: sheetId,
      range: range
    }
  };
}
