import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TestResults {
  sessionId?: string;
  multitouchTest?: {
    passed: boolean;
    score?: number;
  };
  volumeTest?: {
    passed: boolean;
    volumeUpWorks: boolean;
    volumeDownWorks: boolean;
  };
  cameraTest?: {
    passed: boolean;
    frontCameraWorks: boolean;
    backCameraWorks: boolean;
  };
  audioTest?: {
    passed: boolean;
    speakerWorks: boolean;
    microphoneWorks: boolean;
  };
  flashTest?: {
    passed: boolean;
    flashWorks: boolean;
  };
  overallScore?: number;
  completedAt?: string;
  // Simple format for manual entry
  flash?: boolean;
  vibration?: boolean;
  wifi?: boolean;
  multitouch?: boolean;
  volume?: boolean;
  camera?: boolean;
  audio?: boolean;
}

function generateResultCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 5; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  )

  try {
    const body = await req.json();
    
    // Check if this is a request to store results (from phone) or retrieve results (from webapp)
    if (body.action === 'store') {
      // Store test results with a generated code (called from phone test app)
      const { testResults } = body as { testResults: TestResults };
      const resultCode = generateResultCode();

      console.log('📱 Storing test results with code:', resultCode);
      console.log('🔍 Test Results:', JSON.stringify(testResults, null, 2));

      const { data, error } = await supabase
        .from('test_results')
        .insert({
          result_code: resultCode,
          test_data: testResults
        })
        .select()
        .single();

      if (error) {
        throw error;
      }

      return new Response(
        JSON.stringify({
          success: true,
          message: 'Test results stored successfully',
          resultCode,
          data
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        },
      )
    } else if (body.action === 'retrieve') {
      // Retrieve test results by code (called from webapp)
      const { resultCode } = body as { resultCode: string };

      console.log('🔍 Retrieving test results for code:', resultCode);

      const { data, error } = await supabase
        .from('test_results')
        .select('*')
        .eq('result_code', resultCode.toUpperCase())
        .gt('expires_at', new Date().toISOString())
        .single();

      if (error) {
        console.error('❌ Error retrieving test results:', error);
        throw new Error('Test results not found or expired');
      }

      if (!data) {
        throw new Error('Test results not found or expired');
      }

      console.log('✅ Test results retrieved successfully');

      return new Response(
        JSON.stringify({
          success: true,
          message: 'Test results retrieved successfully',
          testResults: data.test_data
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        },
      )
    } else {
      // Legacy support for direct result submission
      const testResults: TestResults = body;
      
      console.log('📱 Received test results from external testing webapp');
      console.log('🔍 Test Results:', JSON.stringify(testResults, null, 2));

      console.log('✅ Test results received successfully for session:', testResults.sessionId);
      console.log('📊 Overall Score:', testResults.overallScore);
      console.log('🧪 Test Summary:');
      
      if (testResults.multitouchTest) {
        console.log(`  - Multitouch: ${testResults.multitouchTest.passed ? 'PASS' : 'FAIL'}`);
      }
      if (testResults.volumeTest) {
        console.log(`  - Volume: ${testResults.volumeTest.passed ? 'PASS' : 'FAIL'}`);
      }
      if (testResults.cameraTest) {
        console.log(`  - Camera: ${testResults.cameraTest.passed ? 'PASS' : 'FAIL'}`);
      }
      if (testResults.audioTest) {
        console.log(`  - Audio: ${testResults.audioTest.passed ? 'PASS' : 'FAIL'}`);
      }
      if (testResults.flashTest) {
        console.log(`  - Flash: ${testResults.flashTest.passed ? 'PASS' : 'FAIL'}`);
      }

      return new Response(
        JSON.stringify({
          success: true,
          message: 'Test results received successfully',
          sessionId: testResults.sessionId,
          overallScore: testResults.overallScore,
          receivedAt: new Date().toISOString()
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }
  } catch (error) {
    console.error('❌ Error processing request:', error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: 'Failed to process request',
        details: error.message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});