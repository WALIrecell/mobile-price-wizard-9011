-- Create a table to store test results with codes
CREATE TABLE public.test_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  result_code TEXT NOT NULL UNIQUE,
  test_data JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + interval '24 hours')
);

-- Enable Row Level Security
ALTER TABLE public.test_results ENABLE ROW LEVEL SECURITY;

-- Create policies to allow anyone to read/write (since these are temporary test results)
CREATE POLICY "Anyone can insert test results" 
ON public.test_results 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can read test results" 
ON public.test_results 
FOR SELECT 
USING (true);

-- Create index for faster lookups
CREATE INDEX idx_test_results_code ON public.test_results(result_code);
CREATE INDEX idx_test_results_expires ON public.test_results(expires_at);