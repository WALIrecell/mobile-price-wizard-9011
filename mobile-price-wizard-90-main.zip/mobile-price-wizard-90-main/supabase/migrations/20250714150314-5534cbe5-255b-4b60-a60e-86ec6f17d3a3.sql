-- Create vouchers table to store voucher codes and their details
CREATE TABLE public.vouchers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  voucher_code TEXT NOT NULL UNIQUE,
  original_amount NUMERIC NOT NULL DEFAULT 0,
  available_amount NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'used', 'expired', 'cancelled')),
  transaction_id TEXT, -- Reference to the original trade-in transaction
  store_id TEXT,
  customer_phone TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE,
  used_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create voucher_verifications table to log all verification attempts
CREATE TABLE public.voucher_verifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  voucher_code TEXT NOT NULL,
  requested_amount NUMERIC NOT NULL,
  transaction_id TEXT NOT NULL,
  verified_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  api_key_used TEXT,
  status TEXT NOT NULL DEFAULT 'verified' CHECK (status IN ('verified', 'rejected', 'error')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on both tables
ALTER TABLE public.vouchers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.voucher_verifications ENABLE ROW LEVEL SECURITY;

-- RLS policies for vouchers (allow all operations for service role, read-only for others)
CREATE POLICY "Service role full access to vouchers" 
ON public.vouchers 
FOR ALL 
USING (true);

CREATE POLICY "Public read access to vouchers" 
ON public.vouchers 
FOR SELECT 
USING (true);

-- RLS policies for voucher_verifications (allow all operations for service role)
CREATE POLICY "Service role full access to voucher_verifications" 
ON public.voucher_verifications 
FOR ALL 
USING (true);

-- Create indexes for better performance
CREATE INDEX idx_vouchers_code ON public.vouchers(voucher_code);
CREATE INDEX idx_vouchers_status ON public.vouchers(status);
CREATE INDEX idx_voucher_verifications_code ON public.voucher_verifications(voucher_code);
CREATE INDEX idx_voucher_verifications_transaction_id ON public.voucher_verifications(transaction_id);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic timestamp updates on vouchers
CREATE TRIGGER update_vouchers_updated_at
  BEFORE UPDATE ON public.vouchers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();