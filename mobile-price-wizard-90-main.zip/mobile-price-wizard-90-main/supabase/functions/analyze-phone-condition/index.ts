import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageData } = await req.json();
    
    if (!imageData) {
      return new Response(
        JSON.stringify({ error: 'Image data is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAIApiKey) {
      return new Response(
        JSON.stringify({ error: 'OpenAI API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Analyzing phone condition with AI...');

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `You are an expert phone condition assessor. Analyze the phone image and detect:
            1. Scratches on the screen (LCD/display area)
            2. Scratches on the back/sides
            3. Cracks on screen or back
            4. Broken/shattered screen
            5. Overall cosmetic condition
            
            Grade the device as:
            - A grade: 0-1 minor scratches, excellent condition
            - B grade: 2-3 scratches, good condition with minor wear
            - C grade: 4+ scratches, fair condition with visible wear
            - Broken: Any cracks, shattered screen, or major damage
            
            Return a JSON response with:
            {
              "grade": "A|B|C|Broken",
              "scratchCount": number,
              "hasCracks": boolean,
              "hasScreenDamage": boolean,
              "condition": "brief description",
              "confidence": number (0-100)
            }`
          },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'Please analyze this phone image for cosmetic damage and assign an appropriate grade.'
              },
              {
                type: 'image_url',
                image_url: {
                  url: imageData
                }
              }
            ]
          }
        ],
        max_tokens: 500,
        temperature: 0.1
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('OpenAI API error:', errorText);
      return new Response(
        JSON.stringify({ error: 'Failed to analyze image' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const data = await response.json();
    const analysisText = data.choices[0].message.content;
    
    console.log('AI Analysis Result:', analysisText);

    // Parse the JSON response from the AI
    let analysis;
    try {
      analysis = JSON.parse(analysisText);
    } catch (e) {
      // Fallback parsing if AI doesn't return perfect JSON
      console.log('Failed to parse JSON, using fallback parsing');
      const gradeMatch = analysisText.match(/grade['":\s]*([ABCD]|Broken)/i);
      const scratchMatch = analysisText.match(/scratch[es]*['":\s]*(\d+)/i);
      const cracksMatch = analysisText.match(/crack[s]*['":\s]*(true|false)/i);
      
      analysis = {
        grade: gradeMatch ? gradeMatch[1].toUpperCase() : 'B',
        scratchCount: scratchMatch ? parseInt(scratchMatch[1]) : 2,
        hasCracks: cracksMatch ? cracksMatch[1] === 'true' : false,
        hasScreenDamage: cracksMatch ? cracksMatch[1] === 'true' : false,
        condition: 'AI analysis completed',
        confidence: 75
      };
    }

    // Ensure grade is valid
    if (!['A', 'B', 'C', 'Broken'].includes(analysis.grade)) {
      analysis.grade = 'B'; // Default to B grade if uncertain
    }

    console.log('Final analysis:', analysis);

    return new Response(
      JSON.stringify(analysis),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in analyze-phone-condition function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});