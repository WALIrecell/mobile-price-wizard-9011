
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { PhoneData } from './types.ts';
import { getGoogleAccessToken } from './jwt-utils.ts';
import { uploadImageToSupabase } from './image-upload.ts';
import { saveToGoogleSheets } from './sheets-service.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-requested-with',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE',
  'Access-Control-Max-Age': '86400',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { 
      status: 200,
      headers: corsHeaders 
    });
  }

  try {
    console.log('🚀 ===== SUPABASE FUNCTION STARTED =====');
    const phoneData: PhoneData = await req.json();
    
    console.log('📥 SHEETS: Raw incoming data:', JSON.stringify(phoneData, null, 2));
    console.log('🏪 SHEETS: Store ID received:', `"${phoneData.storeId}"`);
    console.log('🏪 SHEETS: Store ID type:', typeof phoneData.storeId);
    console.log('🏪 SHEETS: Store ID exists:', !!phoneData.storeId);
    console.log('🏪 SHEETS: Store ID length:', phoneData.storeId?.length);

    // Validate that Store ID exists
    if (!phoneData.storeId || phoneData.storeId.trim() === '') {
      throw new Error('Store ID is missing or empty');
    }

    // Upload image to Supabase Storage if provided
    const imageUrl = await uploadImageToSupabase(phoneData.reportImage || '');

    // Get Google access token
    const accessToken = await getGoogleAccessToken();

    // Save to Google Sheets
    const result = await saveToGoogleSheets(phoneData, imageUrl, accessToken);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Data saved to Google Sheets successfully using append API',
        storeIdDebug: {
          received: phoneData.storeId,
          type: typeof phoneData.storeId,
          length: phoneData.storeId?.length,
          trimmed: phoneData.storeId?.trim()
        },
        ...result
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('❌ SHEETS: Function error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        details: error.toString()
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
