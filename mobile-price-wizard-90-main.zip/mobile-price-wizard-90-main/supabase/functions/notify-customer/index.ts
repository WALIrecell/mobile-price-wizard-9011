import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface CustomerNotificationData {
  transaction_id: string
  amount: number
}

interface CustomerNotificationResponse {
  success: boolean
  message: string
  sent: boolean
  error?: string
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Parse request body
    const notificationData: CustomerNotificationData = await req.json()
    
    console.log('Customer API notification request:', {
      transaction_id: notificationData.transaction_id,
      amount: notificationData.amount
    })

    // Check if integration is enabled
    const integrationEnabled = Deno.env.get('INTEGRATION_ENABLED')
    if (!integrationEnabled || integrationEnabled.toLowerCase() !== 'true') {
      console.log('Integration not enabled, skipping customer notification')
      return new Response(
        JSON.stringify({
          success: true,
          message: 'Integration not enabled',
          sent: false
        } as CustomerNotificationResponse),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    }

    // Get customer API configuration
    const customerApiEndpoint = Deno.env.get('CUSTOMER_API_ENDPOINT')
    const customerApiKey = Deno.env.get('CUSTOMER_API_KEY')

    if (!customerApiEndpoint) {
      console.log('Customer API endpoint not configured, skipping notification')
      return new Response(
        JSON.stringify({
          success: true,
          message: 'Customer API endpoint not configured',
          sent: false
        } as CustomerNotificationResponse),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    }

    // Prepare headers for customer API call
    const customerApiHeaders: Record<string, string> = {
      'Content-Type': 'application/json'
    }

    // Add authentication if API key is provided
    if (customerApiKey) {
      customerApiHeaders['Authorization'] = `Bearer ${customerApiKey}`
      // Alternative: Use API key in header if customer prefers
      // customerApiHeaders['X-API-Key'] = customerApiKey
    }

    // Make API call to customer/retailer system
    try {
      console.log(`Sending notification to customer API: ${customerApiEndpoint}`)
      
      const customerResponse = await fetch(customerApiEndpoint, {
        method: 'POST',
        headers: customerApiHeaders,
        body: JSON.stringify(notificationData)
      })

      const responseText = await customerResponse.text()
      console.log(`Customer API response: ${customerResponse.status} - ${responseText}`)

      if (customerResponse.ok) {
        return new Response(
          JSON.stringify({
            success: true,
            message: 'Customer notification sent successfully',
            sent: true
          } as CustomerNotificationResponse),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200 
          }
        )
      } else {
        console.error(`Customer API error: ${customerResponse.status} - ${responseText}`)
        return new Response(
          JSON.stringify({
            success: true, // Still success for our app flow
            message: 'Customer API returned error, but transaction completed',
            sent: false,
            error: `API Error: ${customerResponse.status}`
          } as CustomerNotificationResponse),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200 
          }
        )
      }
    } catch (fetchError) {
      console.error('Failed to reach customer API:', fetchError)
      return new Response(
        JSON.stringify({
          success: true, // Still success for our app flow
          message: 'Failed to reach customer API, but transaction completed',
          sent: false,
          error: 'Network error'
        } as CustomerNotificationResponse),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    }

  } catch (error) {
    console.error('Customer notification error:', error)
    return new Response(
      JSON.stringify({
        success: true, // Still success for our app flow
        message: 'Internal error during notification, but transaction completed',
        sent: false,
        error: 'Internal error'
      } as CustomerNotificationResponse),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )
  }
}

serve(handler)