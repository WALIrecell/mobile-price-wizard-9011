import { ReactNode } from 'react';

export interface EnhancedDiagnosticTest {
  id: string;
  name: string;
  category: 'hardware' | 'display' | 'audio' | 'camera' | 'sensors' | 'connectivity' | 'performance' | 'biometric';
  description: string;
  icon?: ReactNode;
  iconName?: string;
  status: 'pending' | 'testing' | 'passed' | 'failed' | 'skipped';
  score: number; // 0-100
  automated: boolean;
  requiredPermissions?: string[];
  estimatedDuration: number; // milliseconds
  priority: 'critical' | 'high' | 'medium' | 'low';
  details?: string;
  errorMessage?: string;
}

export interface TestCategory {
  id: string;
  name: string;
  description: string;
  tests: EnhancedDiagnosticTest[];
  weight: number; // for overall score calculation
}

export interface DiagnosticReport {
  deviceInfo: {
    make: string;
    model: string;
    imei?: string;
    userAgent: string;
    timestamp: string;
  };
  categories: TestCategory[];
  overallScore: number;
  completedTests: number;
  totalTests: number;
  duration: number;
  recommendations: string[];
}

export interface EnhancedDiagnosticProps {
  phoneData: {
    make: string;
    model: string;
    imeiNumber?: string;
  };
  onComplete: (report: DiagnosticReport) => void;
  testConfiguration?: {
    categories: string[];
    automated: boolean;
    skipPermissionTests: boolean;
  };
}