
import { DiagnosticTest } from '../types/diagnostic';
import { imeiDiagnosticCache } from './imeiDiagnosticCache';

// Define the base test structure without icons
interface BaseTestData {
  name: string;
  iconName: 'Camera' | 'Cpu' | 'Smartphone' | 'Wifi' | 'Speaker';
  status: 'pending';
  duration: number;
}

export const generateOrRetrieveTestResults = (phoneData: { imeiNumber?: string }) => {
  const baseTestsData: BaseTestData[] = [
    { name: 'Camera Sensor Analysis', iconName: 'Camera', status: 'pending' as const, duration: 2200 },
    { name: 'CPU Thermal Check', iconName: 'Cpu', status: 'pending' as const, duration: 2000 },
    { name: 'Internal Moisture Scan', iconName: 'Smartphone', status: 'pending' as const, duration: 1800 },
    { name: 'WiFi Connectivity Test', iconName: 'Wifi', status: 'pending' as const, duration: 1500 },
    { name: 'Speaker Performance', iconName: 'Speaker', status: 'pending' as const, duration: 1200 },
  ];

  // Check for cached results first
  if (phoneData.imeiNumber) {
    const cachedResults = imeiDiagnosticCache.getCachedResults(phoneData.imeiNumber);
    
    if (cachedResults && cachedResults.length === baseTestsData.length) {
      console.log(`🔄 Using cached diagnostic results for IMEI ${phoneData.imeiNumber}`);
      
      return baseTestsData.map((test, index) => ({
        ...test,
        finalStatus: cachedResults[index]?.finalStatus || 'passed'
      }));
    }
  }

  // Generate new random results
  console.log('🆕 Generating new diagnostic results');
  
  const failCount = Math.floor(Math.random() * 2) + 2; // 2-3 failures
  const failedIndices = new Set<number>();
  
  while (failedIndices.size < failCount) {
    failedIndices.add(Math.floor(Math.random() * baseTestsData.length));
  }

  const newResults = baseTestsData.map((test, index) => ({
    ...test,
    finalStatus: failedIndices.has(index) ? 'failed' as const : 'passed' as const
  }));

  // Store new results in cache if IMEI is available
  if (phoneData.imeiNumber) {
    imeiDiagnosticCache.storeDiagnosticResults(phoneData.imeiNumber, newResults);
  }

  return newResults;
};
