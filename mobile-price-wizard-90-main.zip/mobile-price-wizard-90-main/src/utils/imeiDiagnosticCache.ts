
interface CachedDiagnosticResult {
  imei: string;
  diagnosticResults: any[];
  timestamp: number;
  expiresAt: number;
}

const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
const STORAGE_KEY = 'imei_diagnostic_cache';

export class IMEIDiagnosticCache {
  private static instance: IMEIDiagnosticCache;
  
  private constructor() {}
  
  static getInstance(): IMEIDiagnosticCache {
    if (!IMEIDiagnosticCache.instance) {
      IMEIDiagnosticCache.instance = new IMEIDiagnosticCache();
    }
    return IMEIDiagnosticCache.instance;
  }

  // Clean expired entries from cache
  private cleanExpiredEntries(): void {
    try {
      const now = Date.now();
      const cachedData = localStorage.getItem(STORAGE_KEY);
      
      if (!cachedData) return;
      
      const cache: CachedDiagnosticResult[] = JSON.parse(cachedData);
      const validEntries = cache.filter(entry => entry.expiresAt > now);
      
      // Only update localStorage if we removed any entries
      if (validEntries.length !== cache.length) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(validEntries));
        console.log(`🗑️ IMEI Cache: Cleaned ${cache.length - validEntries.length} expired entries`);
      }
    } catch (error) {
      console.error('Error cleaning expired cache entries:', error);
      // Reset cache if corrupted
      localStorage.removeItem(STORAGE_KEY);
    }
  }

  // Get cached diagnostic results for an IMEI
  getCachedResults(imei: string): any[] | null {
    if (!imei || imei.trim() === '') return null;
    
    this.cleanExpiredEntries();
    
    try {
      const cachedData = localStorage.getItem(STORAGE_KEY);
      if (!cachedData) return null;
      
      const cache: CachedDiagnosticResult[] = JSON.parse(cachedData);
      const entry = cache.find(item => item.imei === imei.trim());
      
      if (entry && entry.expiresAt > Date.now()) {
        console.log(`✅ IMEI Cache: Found cached results for IMEI ${imei}`);
        console.log('Cached diagnostic results:', entry.diagnosticResults);
        return entry.diagnosticResults;
      }
      
      return null;
    } catch (error) {
      console.error('Error retrieving cached results:', error);
      return null;
    }
  }

  // Store diagnostic results for an IMEI
  storeDiagnosticResults(imei: string, diagnosticResults: any[]): void {
    if (!imei || imei.trim() === '' || !diagnosticResults) return;
    
    this.cleanExpiredEntries();
    
    try {
      const now = Date.now();
      const expiresAt = now + CACHE_DURATION;
      
      const cachedData = localStorage.getItem(STORAGE_KEY);
      let cache: CachedDiagnosticResult[] = cachedData ? JSON.parse(cachedData) : [];
      
      // Remove existing entry for this IMEI
      cache = cache.filter(item => item.imei !== imei.trim());
      
      // Add new entry
      const newEntry: CachedDiagnosticResult = {
        imei: imei.trim(),
        diagnosticResults,
        timestamp: now,
        expiresAt
      };
      
      cache.push(newEntry);
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cache));
      
      console.log(`💾 IMEI Cache: Stored diagnostic results for IMEI ${imei}`);
      console.log('Stored diagnostic results:', diagnosticResults);
      console.log(`Cache expires at: ${new Date(expiresAt).toLocaleString()}`);
    } catch (error) {
      console.error('Error storing diagnostic results:', error);
    }
  }

  // Get cache statistics
  getCacheStats(): { totalEntries: number; oldestEntry: Date | null; newestEntry: Date | null } {
    this.cleanExpiredEntries();
    
    try {
      const cachedData = localStorage.getItem(STORAGE_KEY);
      if (!cachedData) return { totalEntries: 0, oldestEntry: null, newestEntry: null };
      
      const cache: CachedDiagnosticResult[] = JSON.parse(cachedData);
      
      if (cache.length === 0) {
        return { totalEntries: 0, oldestEntry: null, newestEntry: null };
      }
      
      const timestamps = cache.map(entry => entry.timestamp).sort((a, b) => a - b);
      
      return {
        totalEntries: cache.length,
        oldestEntry: new Date(timestamps[0]),
        newestEntry: new Date(timestamps[timestamps.length - 1])
      };
    } catch (error) {
      console.error('Error getting cache stats:', error);
      return { totalEntries: 0, oldestEntry: null, newestEntry: null };
    }
  }

  // Clear all cache (for debugging)
  clearCache(): void {
    localStorage.removeItem(STORAGE_KEY);
    console.log('🗑️ IMEI Cache: All cache cleared');
  }
}

export const imeiDiagnosticCache = IMEIDiagnosticCache.getInstance();
