import { EnhancedDiagnosticTest, TestCategory } from '../types/enhancedDiagnostic';

export const createDiagnosticTestSuite = (): TestCategory[] => {
  return [
    {
      id: 'display',
      name: 'Display & Touch',
      description: 'Screen, touch sensitivity, and visual components',
      weight: 0.25,
      tests: [
        {
          id: 'display-colors',
          name: 'Color Accuracy Test',
          category: 'display',
          description: 'Tests display color reproduction and dead pixels',
          status: 'pending',
          score: 0,
          automated: false,
          estimatedDuration: 30000,
          priority: 'high'
        },
        {
          id: 'touch-multitouch',
          name: 'Multi-touch Detection',
          category: 'display',
          description: 'Tests touch sensitivity and multi-finger recognition',
          status: 'pending',
          score: 0,
          automated: true,
          estimatedDuration: 15000,
          priority: 'critical'
        },
        {
          id: 'display-brightness',
          name: 'Brightness Control',
          category: 'display',
          description: 'Tests auto-brightness and manual brightness controls',
          status: 'pending',
          score: 0,
          automated: true,
          estimatedDuration: 10000,
          priority: 'medium'
        },
        {
          id: 'display-deadpixels',
          name: 'Dead Pixel Detection',
          category: 'display',
          description: 'Scans for dead or stuck pixels across the display',
          status: 'pending',
          score: 0,
          automated: false,
          estimatedDuration: 20000,
          priority: 'high'
        }
      ]
    },
    {
      id: 'audio',
      name: 'Audio System',
      description: 'Speakers, microphone, and audio processing',
      weight: 0.15,
      tests: [
        {
          id: 'audio-speakers',
          name: 'Speaker Quality Test',
          category: 'audio',
          description: 'Tests speaker output across frequency ranges',
          status: 'pending',
          score: 0,
          automated: true,
          requiredPermissions: ['audio'],
          estimatedDuration: 20000,
          priority: 'high'
        },
        {
          id: 'audio-microphone',
          name: 'Microphone Sensitivity',
          category: 'audio',
          description: 'Tests microphone input and noise cancellation',
          status: 'pending',
          score: 0,
          automated: true,
          requiredPermissions: ['microphone'],
          estimatedDuration: 15000,
          priority: 'high'
        },
        {
          id: 'audio-stereo',
          name: 'Stereo Channel Test',
          category: 'audio',
          description: 'Tests left/right audio channel separation',
          status: 'pending',
          score: 0,
          automated: true,
          estimatedDuration: 10000,
          priority: 'medium'
        }
      ]
    },
    {
      id: 'camera',
      name: 'Camera System',
      description: 'Front and rear cameras, flash, and video recording',
      weight: 0.20,
      tests: [
        {
          id: 'camera-rear',
          name: 'Rear Camera Test',
          category: 'camera',
          description: 'Tests rear camera functionality and image quality',
          status: 'pending',
          score: 0,
          automated: true,
          requiredPermissions: ['camera'],
          estimatedDuration: 15000,
          priority: 'critical'
        },
        {
          id: 'camera-front',
          name: 'Front Camera Test',
          category: 'camera',
          description: 'Tests front-facing camera and selfie capabilities',
          status: 'pending',
          score: 0,
          automated: true,
          requiredPermissions: ['camera'],
          estimatedDuration: 15000,
          priority: 'high'
        },
        {
          id: 'camera-flash',
          name: 'Flash/Torch Test',
          category: 'camera',
          description: 'Tests camera flash and torch functionality',
          status: 'pending',
          score: 0,
          automated: true,
          requiredPermissions: ['camera'],
          estimatedDuration: 8000,
          priority: 'medium'
        },
        {
          id: 'camera-autofocus',
          name: 'Auto-focus Test',
          category: 'camera',
          description: 'Tests camera auto-focus accuracy and speed',
          status: 'pending',
          score: 0,
          automated: true,
          requiredPermissions: ['camera'],
          estimatedDuration: 12000,
          priority: 'medium'
        }
      ]
    },
    {
      id: 'sensors',
      name: 'Sensors',
      description: 'Motion sensors, environmental sensors, and positioning',
      weight: 0.15,
      tests: [
        {
          id: 'sensor-accelerometer',
          name: 'Accelerometer Test',
          category: 'sensors',
          description: 'Tests device motion and orientation detection',
          status: 'pending',
          score: 0,
          automated: true,
          estimatedDuration: 10000,
          priority: 'medium'
        },
        {
          id: 'sensor-gyroscope',
          name: 'Gyroscope Test',
          category: 'sensors',
          description: 'Tests rotational motion detection',
          status: 'pending',
          score: 0,
          automated: true,
          estimatedDuration: 10000,
          priority: 'medium'
        },
        {
          id: 'sensor-proximity',
          name: 'Proximity Sensor',
          category: 'sensors',
          description: 'Tests proximity detection for call handling',
          status: 'pending',
          score: 0,
          automated: false,
          estimatedDuration: 8000,
          priority: 'medium'
        },
        {
          id: 'sensor-light',
          name: 'Ambient Light Sensor',
          category: 'sensors',
          description: 'Tests automatic brightness adjustment',
          status: 'pending',
          score: 0,
          automated: true,
          estimatedDuration: 8000,
          priority: 'low'
        }
      ]
    },
    {
      id: 'connectivity',
      name: 'Connectivity',
      description: 'WiFi, Bluetooth, GPS, and network capabilities',
      weight: 0.15,
      tests: [
        {
          id: 'connectivity-wifi',
          name: 'WiFi Performance',
          category: 'connectivity',
          description: 'Tests WiFi connection strength and speed',
          status: 'pending',
          score: 0,
          automated: true,
          estimatedDuration: 15000,
          priority: 'high'
        },
        {
          id: 'connectivity-bluetooth',
          name: 'Bluetooth Discovery',
          category: 'connectivity',
          description: 'Tests Bluetooth availability and discovery',
          status: 'pending',
          score: 0,
          automated: true,
          requiredPermissions: ['bluetooth'],
          estimatedDuration: 10000,
          priority: 'medium'
        },
        {
          id: 'connectivity-gps',
          name: 'GPS Accuracy',
          category: 'connectivity',
          description: 'Tests location services and GPS accuracy',
          status: 'pending',
          score: 0,
          automated: true,
          requiredPermissions: ['geolocation'],
          estimatedDuration: 20000,
          priority: 'medium'
        }
      ]
    },
    {
      id: 'hardware',
      name: 'Hardware Components',
      description: 'Physical buttons, vibration, and charging',
      weight: 0.10,
      tests: [
        {
          id: 'hardware-vibration',
          name: 'Vibration Motor',
          category: 'hardware',
          description: 'Tests haptic feedback and vibration patterns',
          status: 'pending',
          score: 0,
          automated: true,
          estimatedDuration: 5000,
          priority: 'medium'
        },
        {
          id: 'hardware-buttons',
          name: 'Physical Buttons',
          category: 'hardware',
          description: 'Tests volume and power button responsiveness',
          status: 'pending',
          score: 0,
          automated: false,
          estimatedDuration: 15000,
          priority: 'high'
        },
        {
          id: 'hardware-charging',
          name: 'Charging Detection',
          category: 'hardware',
          description: 'Tests charging port and battery status',
          status: 'pending',
          score: 0,
          automated: true,
          estimatedDuration: 8000,
          priority: 'medium'
        }
      ]
    }
  ];
};

// Real test implementations with user interaction
export const testRunners = {
  // Display Tests  
  'display-dead-pixels': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; display: flex; flex-direction: column; align-items: center; 
        justify-content: center; background: red; color: white; font-size: 18px;
      `;
      
      const colors = ['red', 'green', 'blue', 'white', 'black'];
      let currentColor = 0;
      
      const instruction = document.createElement('div');
      instruction.innerHTML = `
        <div style="text-align: center; padding: 20px;">
          <h3>Dead Pixel Test</h3>
          <p>Look for any stuck or dead pixels on the screen</p>
          <p>Color: ${colors[currentColor].toUpperCase()}</p>
          <button id="nextColor" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Next Color</button>
          <button id="passTest" style="margin: 10px; padding: 10px 20px; font-size: 16px;">No Issues Found</button>
          <button id="failTest" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Issues Found</button>
        </div>
      `;
      testOverlay.appendChild(instruction);
      document.body.appendChild(testOverlay);
      
      const nextBtn = document.getElementById('nextColor');
      const passBtn = document.getElementById('passTest');
      const failBtn = document.getElementById('failTest');
      
      nextBtn?.addEventListener('click', () => {
        currentColor = (currentColor + 1) % colors.length;
        testOverlay.style.background = colors[currentColor];
        instruction.querySelector('p:nth-child(3)')!.textContent = `Color: ${colors[currentColor].toUpperCase()}`;
        if (colors[currentColor] === 'black') {
          instruction.style.color = 'white';
        } else {
          instruction.style.color = colors[currentColor] === 'white' ? 'black' : 'white';
        }
      });
      
      passBtn?.addEventListener('click', () => {
        document.body.removeChild(testOverlay);
        resolve({ passed: true, score: 100, details: 'No dead pixels detected' });
      });
      
      failBtn?.addEventListener('click', () => {
        document.body.removeChild(testOverlay);
        resolve({ passed: false, score: 50, details: 'Dead pixels detected' });
      });
    });
  },

  'display-color-accuracy': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; background: linear-gradient(45deg, #ff0000, #00ff00, #0000ff);
      `;
      
      // Create bubble popping test
      const bubbles: HTMLElement[] = [];
      let poppedCount = 0;
      const totalBubbles = 15;
      
      testOverlay.innerHTML = `
        <div style="position: absolute; top: 20px; left: 50%; transform: translateX(-50%); text-align: center; color: white; background: rgba(0,0,0,0.8); padding: 15px; border-radius: 10px; font-size: 18px;">
          <h3 style="margin: 0 0 10px 0;">Touch Screen Test 2</h3>
          <p style="margin: 5px 0;">Pop all the bubbles by touching them!</p>
          <div id="bubbleCounter" style="font-size: 20px; font-weight: bold; margin-top: 10px;">Bubbles: ${totalBubbles}/${totalBubbles}</div>
        </div>
      `;
      
      // Create bubbles at random positions
      for (let i = 0; i < totalBubbles; i++) {
        const bubble = document.createElement('div');
        const size = 50 + Math.random() * 30; // Random size between 50-80px
        const hue = Math.random() * 360;
        
        bubble.style.cssText = `
          position: absolute;
          width: ${size}px;
          height: ${size}px;
          background: radial-gradient(circle, hsla(${hue}, 70%, 80%, 0.9), hsla(${hue}, 60%, 60%, 0.7));
          border-radius: 50%;
          border: 3px solid rgba(255,255,255,0.8);
          cursor: pointer;
          animation: float 2s ease-in-out infinite;
          box-shadow: 0 4px 20px rgba(0,0,0,0.3);
          top: ${Math.random() * (window.innerHeight - 200) + 100}px;
          left: ${Math.random() * (window.innerWidth - 100) + 50}px;
          user-select: none;
        `;
        
        // Add ripple effect on click
        bubble.addEventListener('click', (e) => {
          e.stopPropagation();
          
          // Create pop animation
          bubble.style.animation = 'pop 0.3s ease-out forwards';
          bubble.style.transform = 'scale(0)';
          bubble.style.opacity = '0';
          
          setTimeout(() => bubble.remove(), 300);
          
          poppedCount++;
          const counter = document.getElementById('bubbleCounter');
          if (counter) {
            counter.textContent = `Bubbles: ${totalBubbles - poppedCount}/${totalBubbles}`;
            if (poppedCount === totalBubbles) {
              counter.innerHTML = `<span style="color: #00ff00;">✓ All bubbles popped!</span>`;
            }
          }
          
          if (poppedCount === totalBubbles) {
            setTimeout(() => {
              document.body.removeChild(testOverlay);
              resolve({ passed: true, score: 100, details: 'Touch screen excellent - all bubbles popped successfully!' });
            }, 1000);
          }
        });
        
        bubbles.push(bubble);
        testOverlay.appendChild(bubble);
      }
      
      // Add animations
      const style = document.createElement('style');
      style.textContent = `
        @keyframes float {
          0%, 100% { transform: translateY(0px) scale(1); opacity: 0.9; }
          50% { transform: translateY(-15px) scale(1.1); opacity: 1; }
        }
        @keyframes pop {
          0% { transform: scale(1); }
          50% { transform: scale(1.3); }
          100% { transform: scale(0); opacity: 0; }
        }
      `;
      document.head.appendChild(style);
      
      document.body.appendChild(testOverlay);
      
      // Auto-fail after 45 seconds if not completed
      setTimeout(() => {
        if (poppedCount < totalBubbles && document.body.contains(testOverlay)) {
          document.body.removeChild(testOverlay);
          document.head.removeChild(style);
          resolve({ 
            passed: false, 
            score: Math.round((poppedCount / totalBubbles) * 100), 
            details: `Touch screen partially responsive - ${poppedCount}/${totalBubbles} bubbles popped (${Math.round((poppedCount / totalBubbles) * 100)}%)` 
          });
        }
      }, 45000);
    });
  },

  'display-brightness': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; display: flex; flex-direction: column; align-items: center; 
        justify-content: center; background: white; color: black; font-size: 18px;
      `;
      
      testOverlay.innerHTML = `
        <div style="text-align: center; padding: 20px;">
          <h3>Brightness Test</h3>
          <p>Is the screen bright enough to see clearly?</p>
          <p>Can you read this text comfortably?</p>
          <button id="brightGood" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Yes, Clear</button>
          <button id="brightPoor" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Too Dim</button>
        </div>
      `;
      document.body.appendChild(testOverlay);
      
      document.getElementById('brightGood')?.addEventListener('click', () => {
        document.body.removeChild(testOverlay);
        resolve({ passed: true, score: 90, details: 'Brightness levels adequate' });
      });
      
      document.getElementById('brightPoor')?.addEventListener('click', () => {
        document.body.removeChild(testOverlay);
        resolve({ passed: false, score: 40, details: 'Brightness insufficient' });
      });
    });
  },

  // Audio Tests
  'audio-speaker': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      oscillator.frequency.value = 440; // A note
      gainNode.gain.value = 0.3;
      
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; display: flex; flex-direction: column; align-items: center; 
        justify-content: center; background: #1a1a1a; color: white; font-size: 18px;
      `;
      
      testOverlay.innerHTML = `
        <div style="text-align: center; padding: 20px;">
          <h3>Speaker Test</h3>
          <p>Playing a test tone...</p>
          <p>Can you hear the sound clearly?</p>
          <button id="soundGood" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Yes, Clear Sound</button>
          <button id="soundPoor" style="margin: 10px; padding: 10px 20px; font-size: 16px;">No/Poor Sound</button>
        </div>
      `;
      document.body.appendChild(testOverlay);
      
      oscillator.start();
      
      document.getElementById('soundGood')?.addEventListener('click', () => {
        oscillator.stop();
        audioContext.close();
        document.body.removeChild(testOverlay);
        resolve({ passed: true, score: 95, details: 'Speaker output excellent' });
      });
      
      document.getElementById('soundPoor')?.addEventListener('click', () => {
        oscillator.stop();
        audioContext.close();
        document.body.removeChild(testOverlay);
        resolve({ passed: false, score: 30, details: 'Speaker issues detected' });
      });
    });
  },

  'audio-microphone': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise(async (resolve) => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const audioContext = new AudioContext();
        const analyser = audioContext.createAnalyser();
        const microphone = audioContext.createMediaStreamSource(stream);
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        
        microphone.connect(analyser);
        analyser.fftSize = 256;
        
        const testOverlay = document.createElement('div');
        testOverlay.style.cssText = `
          position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
          z-index: 10000; display: flex; flex-direction: column; align-items: center; 
          justify-content: center; background: #2a2a2a; color: white; font-size: 18px;
        `;
        
        const levelBar = document.createElement('div');
        levelBar.style.cssText = `
          width: 300px; height: 20px; background: #555; margin: 20px 0; border-radius: 10px; overflow: hidden;
        `;
        const levelFill = document.createElement('div');
        levelFill.style.cssText = `
          height: 100%; background: #00ff00; width: 0%; transition: width 0.1s;
        `;
        levelBar.appendChild(levelFill);
        
        testOverlay.innerHTML = `
          <div style="text-align: center; padding: 20px;">
            <h3>Microphone Test</h3>
            <p>Speak into the microphone...</p>
            <p>The bar below should move when you speak</p>
          </div>
        `;
        testOverlay.querySelector('div')?.appendChild(levelBar);
        testOverlay.innerHTML += `
          <div style="text-align: center;">
            <button id="micGood" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Microphone Works</button>
            <button id="micPoor" style="margin: 10px; padding: 10px 20px; font-size: 16px;">No Response</button>
          </div>
        `;
        document.body.appendChild(testOverlay);
        
        const updateLevel = () => {
          analyser.getByteFrequencyData(dataArray);
          const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
          const percentage = (average / 255) * 100;
          levelFill.style.width = `${percentage}%`;
          requestAnimationFrame(updateLevel);
        };
        updateLevel();
        
        document.getElementById('micGood')?.addEventListener('click', () => {
          stream.getTracks().forEach(track => track.stop());
          audioContext.close();
          document.body.removeChild(testOverlay);
          resolve({ passed: true, score: 90, details: 'Microphone sensitivity good' });
        });
        
        document.getElementById('micPoor')?.addEventListener('click', () => {
          stream.getTracks().forEach(track => track.stop());
          audioContext.close();
          document.body.removeChild(testOverlay);
          resolve({ passed: false, score: 20, details: 'Microphone not responding' });
        });
        
      } catch (error) {
        resolve({ passed: false, score: 0, details: 'Microphone access denied' });
      }
    });
  },

  // Camera Tests
  'camera-rear': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise(async (resolve) => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment' } 
        });
        
        const testOverlay = document.createElement('div');
        testOverlay.style.cssText = `
          position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
          z-index: 10000; display: flex; flex-direction: column; align-items: center; 
          justify-content: center; background: black; color: white;
        `;
        
        const video = document.createElement('video');
        video.srcObject = stream;
        video.autoplay = true;
        video.style.cssText = 'width: 90%; max-width: 400px; border-radius: 10px;';
        
        const content = document.createElement('div');
        content.innerHTML = `
          <div style="text-align: center; padding: 20px;">
            <h3>Rear Camera Test</h3>
            <p>Point camera at something and check if image is clear</p>
          </div>
          <div style="text-align: center; margin: 20px 0;">
          </div>
          <div style="text-align: center; margin-top: 20px;">
            <button id="rearGood" style="margin: 10px; padding: 10px 20px; font-size: 16px; background: #4CAF50; color: white; border: none; border-radius: 5px;">Clear & Sharp</button>
            <button id="rearPoor" style="margin: 10px; padding: 10px 20px; font-size: 16px; background: #f44336; color: white; border: none; border-radius: 5px;">Blurry/Poor</button>
          </div>
        `;
        
        const videoContainer = content.querySelector('div:nth-child(2)');
        videoContainer?.appendChild(video);
        testOverlay.appendChild(content);
        document.body.appendChild(testOverlay);
        
        document.getElementById('rearGood')?.addEventListener('click', () => {
          stream.getTracks().forEach(track => track.stop());
          document.body.removeChild(testOverlay);
          resolve({ passed: true, score: 95, details: 'Rear camera quality excellent' });
        });
        
        document.getElementById('rearPoor')?.addEventListener('click', () => {
          stream.getTracks().forEach(track => track.stop());
          document.body.removeChild(testOverlay);
          resolve({ passed: false, score: 40, details: 'Rear camera quality poor' });
        });
        
      } catch (error) {
        resolve({ passed: false, score: 0, details: 'Rear camera access failed' });
      }
    });
  },

  'camera-front': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise(async (resolve) => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'user' } 
        });
        
        const testOverlay = document.createElement('div');
        testOverlay.style.cssText = `
          position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
          z-index: 10000; display: flex; flex-direction: column; align-items: center; 
          justify-content: center; background: black; color: white;
        `;
        
        const video = document.createElement('video');
        video.srcObject = stream;
        video.autoplay = true;
        video.style.cssText = 'width: 90%; max-width: 400px; border-radius: 10px; transform: scaleX(-1);';
        
        const content = document.createElement('div');
        content.innerHTML = `
          <div style="text-align: center; padding: 20px;">
            <h3>Front Camera Test</h3>
            <p>Look at yourself and check if the image is clear</p>
          </div>
          <div style="text-align: center; margin: 20px 0;">
          </div>
          <div style="text-align: center; margin-top: 20px;">
            <button id="frontGood" style="margin: 10px; padding: 10px 20px; font-size: 16px; background: #4CAF50; color: white; border: none; border-radius: 5px;">Clear & Sharp</button>
            <button id="frontPoor" style="margin: 10px; padding: 10px 20px; font-size: 16px; background: #f44336; color: white; border: none; border-radius: 5px;">Blurry/Poor</button>
          </div>
        `;
        
        const videoContainer = content.querySelector('div:nth-child(2)');
        videoContainer?.appendChild(video);
        testOverlay.appendChild(content);
        document.body.appendChild(testOverlay);
        
        document.getElementById('frontGood')?.addEventListener('click', () => {
          stream.getTracks().forEach(track => track.stop());
          document.body.removeChild(testOverlay);
          resolve({ passed: true, score: 90, details: 'Front camera quality excellent' });
        });
        
        document.getElementById('frontPoor')?.addEventListener('click', () => {
          stream.getTracks().forEach(track => track.stop());
          document.body.removeChild(testOverlay);
          resolve({ passed: false, score: 35, details: 'Front camera quality poor' });
        });
        
      } catch (error) {
        resolve({ passed: false, score: 0, details: 'Front camera access failed' });
      }
    });
  },

  // Sensor Tests
  'sensors-accelerometer': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      let readings: number[] = [];
      
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; display: flex; flex-direction: column; align-items: center; 
        justify-content: center; background: #1a1a2e; color: white; font-size: 18px;
      `;
      
      const readingDisplay = document.createElement('div');
      readingDisplay.style.cssText = 'font-family: monospace; font-size: 16px; margin: 20px;';
      
      testOverlay.innerHTML = `
        <div style="text-align: center; padding: 20px;">
          <h3>Accelerometer Test</h3>
          <p>Tilt and move your device...</p>
          <p>Values should change as you move</p>
        </div>
      `;
      testOverlay.querySelector('div')?.appendChild(readingDisplay);
      testOverlay.innerHTML += `
        <div style="text-align: center;">
          <button id="accelGood" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Sensor Responsive</button>
          <button id="accelPoor" style="margin: 10px; padding: 10px 20px; font-size: 16px;">No Response</button>
        </div>
      `;
      document.body.appendChild(testOverlay);
      
      const handleMotion = (event: DeviceMotionEvent) => {
        const acc = event.accelerationIncludingGravity;
        if (acc) {
          const magnitude = Math.sqrt((acc.x || 0)**2 + (acc.y || 0)**2 + (acc.z || 0)**2);
          readings.push(magnitude);
          readingDisplay.innerHTML = `
            X: ${(acc.x || 0).toFixed(2)}<br>
            Y: ${(acc.y || 0).toFixed(2)}<br>
            Z: ${(acc.z || 0).toFixed(2)}
          `;
        }
      };
      
      window.addEventListener('devicemotion', handleMotion);
      
      document.getElementById('accelGood')?.addEventListener('click', () => {
        window.removeEventListener('devicemotion', handleMotion);
        document.body.removeChild(testOverlay);
        resolve({ 
          passed: true, 
          score: readings.length > 10 ? 95 : 70, 
          details: `Accelerometer responsive (${readings.length} readings)` 
        });
      });
      
      document.getElementById('accelPoor')?.addEventListener('click', () => {
        window.removeEventListener('devicemotion', handleMotion);
        document.body.removeChild(testOverlay);
        resolve({ passed: false, score: 20, details: 'Accelerometer not responding' });
      });
    });
  },

  'sensors-gyroscope': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      let readings: number[] = [];
      
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; display: flex; flex-direction: column; align-items: center; 
        justify-content: center; background: #2e1a2e; color: white; font-size: 18px;
      `;
      
      const readingDisplay = document.createElement('div');
      readingDisplay.style.cssText = 'font-family: monospace; font-size: 16px; margin: 20px;';
      
      testOverlay.innerHTML = `
        <div style="text-align: center; padding: 20px;">
          <h3>Gyroscope Test</h3>
          <p>Rotate your device slowly...</p>
          <p>Values should change as you rotate</p>
        </div>
      `;
      testOverlay.querySelector('div')?.appendChild(readingDisplay);
      testOverlay.innerHTML += `
        <div style="text-align: center;">
          <button id="gyroGood" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Sensor Works</button>
          <button id="gyroPoor" style="margin: 10px; padding: 10px 20px; font-size: 16px;">No Response</button>
        </div>
      `;
      document.body.appendChild(testOverlay);
      
      const handleOrientation = (event: DeviceOrientationEvent) => {
        const alpha = event.alpha || 0;
        const beta = event.beta || 0;
        const gamma = event.gamma || 0;
        readings.push(Math.abs(alpha) + Math.abs(beta) + Math.abs(gamma));
        readingDisplay.innerHTML = `
          Alpha: ${alpha.toFixed(2)}°<br>
          Beta: ${beta.toFixed(2)}°<br>
          Gamma: ${gamma.toFixed(2)}°
        `;
      };
      
      window.addEventListener('deviceorientation', handleOrientation);
      
      document.getElementById('gyroGood')?.addEventListener('click', () => {
        window.removeEventListener('deviceorientation', handleOrientation);
        document.body.removeChild(testOverlay);
        resolve({ passed: true, score: 90, details: 'Gyroscope functioning correctly' });
      });
      
      document.getElementById('gyroPoor')?.addEventListener('click', () => {
        window.removeEventListener('deviceorientation', handleOrientation);
        document.body.removeChild(testOverlay);
        resolve({ passed: false, score: 25, details: 'Gyroscope not responding' });
      });
    });
  },

  // Connectivity Tests
  'connectivity-wifi': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
      
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; display: flex; flex-direction: column; align-items: center; 
        justify-content: center; background: #1a2e1a; color: white; font-size: 18px;
      `;
      
      // Test network speed
      const startTime = Date.now();
      fetch('https://httpbin.org/bytes/1024', { method: 'GET' })
        .then(() => {
          const endTime = Date.now();
          const duration = endTime - startTime;
          const speed = 1024 / (duration / 1000); // bytes per second
          
          testOverlay.innerHTML = `
            <div style="text-align: center; padding: 20px;">
              <h3>WiFi Connectivity Test</h3>
              <p>Connection Type: ${connection?.effectiveType || 'Unknown'}</p>
              <p>Download Speed: ~${(speed / 1024).toFixed(2)} KB/s</p>
              <p>Latency: ${duration}ms</p>
              <button id="wifiGood" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Connection Good</button>
              <button id="wifiPoor" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Connection Poor</button>
            </div>
          `;
          document.body.appendChild(testOverlay);
          
          document.getElementById('wifiGood')?.addEventListener('click', () => {
            document.body.removeChild(testOverlay);
            resolve({ passed: true, score: duration < 2000 ? 95 : 75, details: `Speed: ${(speed/1024).toFixed(2)} KB/s` });
          });
          
          document.getElementById('wifiPoor')?.addEventListener('click', () => {
            document.body.removeChild(testOverlay);
            resolve({ passed: false, score: 40, details: 'Poor connection quality' });
          });
        })
        .catch(() => {
          testOverlay.innerHTML = `
            <div style="text-align: center; padding: 20px;">
              <h3>WiFi Test Failed</h3>
              <p>Unable to connect to test server</p>
              <button id="wifiFail" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Continue</button>
            </div>
          `;
          document.body.appendChild(testOverlay);
          
          document.getElementById('wifiFail')?.addEventListener('click', () => {
            document.body.removeChild(testOverlay);
            resolve({ passed: false, score: 10, details: 'Network connectivity failed' });
          });
        });
    });
  },

  'connectivity-bluetooth': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; display: flex; flex-direction: column; align-items: center; 
        justify-content: center; background: #1a1a2e; color: white; font-size: 18px;
      `;
      
      if ('bluetooth' in navigator) {
        testOverlay.innerHTML = `
          <div style="text-align: center; padding: 20px;">
            <h3>Bluetooth Test</h3>
            <p>Testing Bluetooth availability...</p>
            <button id="testBluetooth" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Test Bluetooth</button>
            <button id="skipBluetooth" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Skip Test</button>
          </div>
        `;
        document.body.appendChild(testOverlay);
        
        document.getElementById('testBluetooth')?.addEventListener('click', async () => {
          try {
            await (navigator as any).bluetooth.getAvailability();
            document.body.removeChild(testOverlay);
            resolve({ passed: true, score: 85, details: 'Bluetooth available' });
          } catch (error) {
            document.body.removeChild(testOverlay);
            resolve({ passed: false, score: 30, details: 'Bluetooth unavailable' });
          }
        });
        
        document.getElementById('skipBluetooth')?.addEventListener('click', () => {
          document.body.removeChild(testOverlay);
          resolve({ passed: true, score: 50, details: 'Bluetooth test skipped' });
        });
      } else {
        testOverlay.innerHTML = `
          <div style="text-align: center; padding: 20px;">
            <h3>Bluetooth Not Supported</h3>
            <p>Bluetooth API not available in this browser</p>
            <button id="continueTest" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Continue</button>
          </div>
        `;
        document.body.appendChild(testOverlay);
        
        document.getElementById('continueTest')?.addEventListener('click', () => {
          document.body.removeChild(testOverlay);
          resolve({ passed: false, score: 0, details: 'Bluetooth API not supported' });
        });
      }
    });
  },

  // Hardware Tests
  'hardware-vibration': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; display: flex; flex-direction: column; align-items: center; 
        justify-content: center; background: #2e1a1a; color: white; font-size: 18px;
      `;
      
      if ('vibrate' in navigator) {
        testOverlay.innerHTML = `
          <div style="text-align: center; padding: 20px;">
            <h3>Vibration Test</h3>
            <p>Testing vibration motor...</p>
            <button id="testVibrate" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Test Vibration</button>
            <div style="margin-top: 20px;">
              <button id="vibrateGood" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Felt Vibration</button>
              <button id="vibratePoor" style="margin: 10px; padding: 10px 20px; font-size: 16px;">No Vibration</button>
            </div>
          </div>
        `;
        document.body.appendChild(testOverlay);
        
        document.getElementById('testVibrate')?.addEventListener('click', () => {
          navigator.vibrate([200, 100, 200, 100, 200]);
        });
        
        document.getElementById('vibrateGood')?.addEventListener('click', () => {
          document.body.removeChild(testOverlay);
          resolve({ passed: true, score: 95, details: 'Vibration motor working' });
        });
        
        document.getElementById('vibratePoor')?.addEventListener('click', () => {
          document.body.removeChild(testOverlay);
          resolve({ passed: false, score: 20, details: 'Vibration motor not working' });
        });
      } else {
        testOverlay.innerHTML = `
          <div style="text-align: center; padding: 20px;">
            <h3>Vibration Not Supported</h3>
            <p>Vibration API not available</p>
            <button id="continueTest" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Continue</button>
          </div>
        `;
        document.body.appendChild(testOverlay);
        
        document.getElementById('continueTest')?.addEventListener('click', () => {
          document.body.removeChild(testOverlay);
          resolve({ passed: false, score: 0, details: 'Vibration API not supported' });
        });
      }
    });
  },

  'hardware-buttons': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      let volumePressed = false;
      
      const testOverlay = document.createElement('div');
      testOverlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
        z-index: 10000; display: flex; flex-direction: column; align-items: center; 
        justify-content: center; background: #2e2e1a; color: white; font-size: 18px;
      `;
      
      testOverlay.innerHTML = `
        <div style="text-align: center; padding: 20px;">
          <h3>Hardware Buttons Test</h3>
          <p>Press your volume up/down buttons</p>
          <p>Volume detected: <span id="volumeStatus">No</span></p>
          <p>Try pressing any physical buttons on your device</p>
          <button id="buttonsGood" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Buttons Work</button>
          <button id="buttonsPoor" style="margin: 10px; padding: 10px 20px; font-size: 16px;">Buttons Don't Work</button>
        </div>
      `;
      document.body.appendChild(testOverlay);
      
      // Listen for any key events that might indicate button presses
      const handleKeyDown = (event: KeyboardEvent) => {
        if (event.key === 'AudioVolumeUp' || event.key === 'AudioVolumeDown' || 
            event.key === 'VolumeUp' || event.key === 'VolumeDown') {
          volumePressed = true;
          document.getElementById('volumeStatus')!.textContent = 'Yes';
        }
      };
      
      document.addEventListener('keydown', handleKeyDown);
      
      document.getElementById('buttonsGood')?.addEventListener('click', () => {
        document.removeEventListener('keydown', handleKeyDown);
        document.body.removeChild(testOverlay);
        const score = volumePressed ? 95 : 75;
        resolve({ passed: true, score, details: `Buttons responsive${volumePressed ? ' (volume detected)' : ''}` });
      });
      
      document.getElementById('buttonsPoor')?.addEventListener('click', () => {
        document.removeEventListener('keydown', handleKeyDown);
        document.body.removeChild(testOverlay);
        resolve({ passed: false, score: 25, details: 'Hardware buttons not responding' });
      });
    });
  },

  // Legacy test mappings for compatibility
  'connectivity-gps': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve({ passed: false, score: 0, details: 'Geolocation not supported' });
        return;
      }

      const timeoutId = setTimeout(() => {
        resolve({ passed: false, score: 20, details: 'GPS timeout' });
      }, 15000);

      navigator.geolocation.getCurrentPosition(
        (position) => {
          clearTimeout(timeoutId);
          const accuracy = position.coords.accuracy;
          const score = Math.max(0, 100 - (accuracy / 10)); // Better accuracy = higher score
          resolve({ 
            passed: true, 
            score: Math.round(score),
            details: `GPS accuracy: ${accuracy.toFixed(0)}m`
          });
        },
        (error) => {
          clearTimeout(timeoutId);
          resolve({ 
            passed: false, 
            score: 0, 
            details: `GPS error: ${error.message}`
          });
        },
        { timeout: 15000, enableHighAccuracy: true }
      );
    });
  },


  'hardware-charging': async (): Promise<{ passed: boolean; score: number; details?: string }> => {
    try {
      const battery = await (navigator as any).getBattery();
      if (battery) {
        return { 
          passed: true, 
          score: 90,
          details: `Battery: ${Math.round(battery.level * 100)}%, Charging: ${battery.charging ? 'Yes' : 'No'}`
        };
      }
    } catch (error) {
      // Battery API not available
    }
    return { passed: true, score: 60, details: 'Battery status unavailable' };
  }
};