
import React from 'react';
import { DiagnosticTest } from '../types/diagnostic';

interface PhoneVisualizationProps {
  progress: number;
  currentTest: number;
  tests: DiagnosticTest[];
}

const PhoneVisualization: React.FC<PhoneVisualizationProps> = ({
  progress,
  currentTest,
  tests
}) => {
  return (
    <div className="flex justify-center mb-8 relative min-h-[400px]">
      <div className="relative perspective-1000">
        {/* Floating Particles */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-purple-400 rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>

        {/* Layered Phone Components */}
        <div className="relative transform-gpu">
          {/* Base Phone Layer */}
          <div className="w-48 h-80 bg-gradient-to-b from-slate-800 to-slate-900 rounded-3xl border-2 border-purple-500/50 shadow-2xl relative overflow-hidden">
            {/* Glowing Border Animation */}
            <div className="absolute inset-0 rounded-3xl border-2 border-transparent bg-gradient-to-r from-purple-500 via-pink-500 to-purple-500 bg-clip-border animate-pulse" />
            
            {/* Screen Layer */}
            <div className="absolute inset-4 bg-gradient-to-br from-blue-900 to-purple-900 rounded-2xl border border-purple-400/30 overflow-hidden">
              {/* Scanning Lines */}
              <div className="absolute inset-0">
                <div className="absolute w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse transform -skew-y-12" 
                     style={{ top: `${(progress / 100) * 100}%`, transition: 'top 0.5s ease-out' }} />
              </div>
              
              {/* Component Layers - Floating */}
              <div className="absolute inset-2 space-y-1">
                {/* Camera Layer */}
                <div className={`h-8 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 rounded border border-emerald-400/30 transform transition-all duration-1000 ${
                  currentTest >= 0 ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-4 scale-95 opacity-50'
                } ${tests[0]?.status === 'testing' ? 'animate-pulse shadow-lg shadow-emerald-400/50' : ''}`}>
                  <div className="flex items-center justify-center h-full text-xs text-emerald-300 font-mono">
                    CAMERA
                  </div>
                </div>

                {/* CPU Layer */}
                <div className={`h-6 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded border border-cyan-400/30 transform transition-all duration-1000 ${
                  currentTest >= 1 ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-4 scale-95 opacity-50'
                } ${tests[1]?.status === 'testing' ? 'animate-pulse shadow-lg shadow-cyan-400/50' : ''}`}>
                  <div className="flex items-center justify-center h-full text-xs text-cyan-300 font-mono">
                    CPU CORE
                  </div>
                </div>

                {/* Moisture Layer */}
                <div className={`h-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded border border-purple-400/30 transform transition-all duration-1000 ${
                  currentTest >= 2 ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-4 scale-95 opacity-50'
                } ${tests[2]?.status === 'testing' ? 'animate-pulse shadow-lg shadow-purple-400/50' : ''}`}>
                  <div className="flex items-center justify-center h-full text-xs text-purple-300 font-mono">
                    INTERNALS
                  </div>
                </div>

                {/* WiFi Layer */}
                <div className={`h-4 bg-gradient-to-r from-blue-500/20 to-indigo-500/20 rounded border border-blue-400/30 transform transition-all duration-1000 ${
                  currentTest >= 3 ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-4 scale-95 opacity-50'
                } ${tests[3]?.status === 'testing' ? 'animate-pulse shadow-lg shadow-blue-400/50' : ''}`}>
                  <div className="flex items-center justify-center h-full text-xs text-blue-300 font-mono">
                    WIFI
                  </div>
                </div>

                {/* Speaker Layer */}
                <div className={`h-6 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded border border-orange-400/30 transform transition-all duration-1000 ${
                  currentTest >= 4 ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-4 scale-95 opacity-50'
                } ${tests[4]?.status === 'testing' ? 'animate-pulse shadow-lg shadow-orange-400/50' : ''}`}>
                  <div className="flex items-center justify-center h-full text-xs text-orange-300 font-mono">
                    AUDIO
                  </div>
                </div>
              </div>
            </div>

            {/* Central Scanning Beam */}
            {currentTest < tests.length && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-32 h-32 border-4 border-purple-400/30 border-t-purple-400 rounded-full animate-spin" />
                <div className="absolute w-24 h-24 border-2 border-pink-400/20 border-t-pink-400 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '3s' }} />
              </div>
            )}
          </div>

          {/* Data Flow Lines */}
          <div className="absolute -right-20 top-1/2 transform -translate-y-1/2">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="w-16 h-0.5 bg-gradient-to-r from-purple-400 to-transparent mb-4 animate-pulse"
                style={{
                  animationDelay: `${i * 0.2}s`,
                  opacity: currentTest > i ? 1 : 0.3
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PhoneVisualization;
