
import React, { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Smartphone, HardDrive, Battery, Scan, Settings, Database, Hash } from 'lucide-react';
import { PhoneData } from '../pages/Index';
import ModelTileSelection from './ModelTileSelection';

interface PriceData {
  make: string;
  model: string;
  memorySize: string;
  gradeA: number;
  gradeB: number;
  gradeC: number;
  broken: number;
}

interface PhoneInfoFormProps {
  onSubmit: (data: Partial<PhoneData>) => void;
  priceData: PriceData[];
  testResults?: {
    overallScore?: number;
    deviceModel?: string;
  };
}

const PhoneInfoForm: React.FC<PhoneInfoFormProps> = ({ onSubmit, priceData, testResults }) => {
  const [formData, setFormData] = useState({
    make: '',
    model: '',
    storage: '',
    condition: '',
    batteryHealth: '',
    storeId: '',
    imeiNumber: ''
  });

  // Get unique makes from price data
  const availableMakes = useMemo((): string[] => {
    const makes = [...new Set(priceData.map(item => item.make))];
    console.log('🔍 FORM DEBUG: Total price data records:', priceData.length);
    console.log('🔍 FORM DEBUG: Available makes:', makes);
    console.log('🔍 FORM DEBUG: Makes count:', makes.length);
    return makes.sort();
  }, [priceData]);

  const availableModels = useMemo(() => {
    if (!formData.make) return [];
    
    const modelsForMake = priceData
      .filter(item => item.make === formData.make)
      .map(item => item.model);
    
    const uniqueModels = [...new Set(modelsForMake)].sort();
    
    console.log(`🔍 FORM DEBUG: Raw records for ${formData.make}:`, modelsForMake.length);
    console.log(`🔍 FORM DEBUG: Unique models for ${formData.make}:`, uniqueModels.length);
    console.log(`🔍 FORM DEBUG: First 20 models:`, uniqueModels.slice(0, 20));
    console.log(`🔍 FORM DEBUG: Last 20 models:`, uniqueModels.slice(-20));
    
    // Enhanced Samsung debugging
    if (formData.make === 'Samsung') {
      console.log(`📱 SAMSUNG DETAILED DEBUG:`);
      console.log(`📱 All Samsung models (first 50):`, uniqueModels.slice(0, 50));
      console.log(`📱 All Samsung models (last 50):`, uniqueModels.slice(-50));
      
      // Look for S20 models with various patterns
      const s20Models = uniqueModels.filter(model => {
        const lowerModel = model.toLowerCase();
        return lowerModel.includes('s20') || 
               lowerModel.includes('s 20') ||
               lowerModel.includes('galaxy s20') ||
               lowerModel.includes('galaxy s 20');
      });
      console.log(`📱 Samsung S20 models found:`, s20Models.length, s20Models);
      
      // Look for fold models
      const foldModels = uniqueModels.filter(model => {
        const lowerModel = model.toLowerCase();
        return lowerModel.includes('fold') || 
               lowerModel.includes('flip') ||
               lowerModel.includes('z fold') ||
               lowerModel.includes('z flip');
      });
      console.log(`📱 Samsung Fold/Flip models found:`, foldModels.length, foldModels);
      
      // Show some sample models for pattern analysis
      console.log(`📱 Sample Samsung models for pattern check:`, uniqueModels.slice(100, 120));
    }
    
    return uniqueModels;
  }, [priceData, formData.make]);

  const availableMemorySize = useMemo(() => {
    if (!formData.make || !formData.model) return [];
    const memorySizes = priceData
      .filter(item => item.make === formData.make && item.model === formData.model)
      .map(item => item.memorySize);
    const uniqueMemorySizes = [...new Set(memorySizes)].sort();
    console.log(`🔍 FORM DEBUG: Available memory sizes for ${formData.make} ${formData.model}:`, uniqueMemorySizes);
    return uniqueMemorySizes;
  }, [priceData, formData.make, formData.model]);

  // Enhanced auto-fill with intelligent database search
  useEffect(() => {
    if (testResults?.deviceModel && priceData.length > 0) {
      console.log('🔍 AUTO-FILL: Processing device model from test results:', testResults.deviceModel);
      
      const deviceModel = testResults.deviceModel.toLowerCase().trim();
      
      // Helper function to calculate similarity score
      const calculateSimilarity = (str1: string, str2: string) => {
        const longer = str1.length > str2.length ? str1 : str2;
        const shorter = str1.length > str2.length ? str2 : str1;
        if (longer.length === 0) return 1.0;
        return (longer.length - editDistance(longer, shorter)) / longer.length;
      };
      
      // Helper function to calculate edit distance
      const editDistance = (str1: string, str2: string) => {
        const matrix = [];
        for (let i = 0; i <= str2.length; i++) {
          matrix[i] = [i];
        }
        for (let j = 0; j <= str1.length; j++) {
          matrix[0][j] = j;
        }
        for (let i = 1; i <= str2.length; i++) {
          for (let j = 1; j <= str1.length; j++) {
            if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
              matrix[i][j] = matrix[i - 1][j - 1];
            } else {
              matrix[i][j] = Math.min(
                matrix[i - 1][j - 1] + 1,
                matrix[i][j - 1] + 1,
                matrix[i - 1][j] + 1
              );
            }
          }
        }
        return matrix[str2.length][str1.length];
      };
      
      // Enhanced normalization for better database matching
      const normalizeModel = (model: string) => {
        return model
          .toLowerCase()
          .replace(/[^a-z0-9\s]/g, ' ')
          .replace(/\b(galaxy|sm-|gt-|sch-|sph-|model|phone|device|name|iphone)\b/gi, '')
          .replace(/\s+/g, ' ')
          .trim();
      };

      // Advanced pattern extraction for precise database matching
      const extractModelPatterns = (text: string) => {
        const patterns = [];
        const normalized = text.toLowerCase();
        
        // iPhone pattern matching - optimized for "iPhone 15 Pro Max" style inputs
        if (normalized.includes('iphone')) {
          // Match iPhone with number and variants
          const iphoneFullMatch = normalized.match(/iphone\s*(\d+)\s*(pro\s*max|pro|plus|mini)?/);
          if (iphoneFullMatch) {
            const number = iphoneFullMatch[1];
            const variant = iphoneFullMatch[2] ? iphoneFullMatch[2].replace(/\s+/g, ' ').trim() : '';
            
            // Generate multiple pattern variations for database search
            patterns.push(`iphone ${number}${variant ? ' ' + variant : ''}`);
            patterns.push(`${number}${variant ? ' ' + variant : ''}`);
            
            // Specific pattern for Pro Max
            if (variant === 'pro max') {
              patterns.push(`iphone ${number} pro max`);
              patterns.push(`${number} pro max`);
              patterns.push(`iphone${number}promax`);
            }
          }
          
          // Extract just the numeric and variant part for direct comparison
          const numericMatch = normalized.match(/(\d+)\s*(pro\s*max|pro|plus|mini)/);
          if (numericMatch) {
            const cleanVariant = numericMatch[2].replace(/\s+/g, ' ').trim();
            patterns.push(`${numericMatch[1]} ${cleanVariant}`);
          }
        }
        
        // Samsung Galaxy patterns
        if (normalized.includes('galaxy') || normalized.includes('samsung')) {
          const galaxyMatch = normalized.match(/galaxy\s*([a-z]\d+(?:\s*\w+)*)/);
          if (galaxyMatch) {
            patterns.push('galaxy ' + galaxyMatch[1].replace(/\s+/g, ' ').trim());
          }
        }
        
        // Extract core model identifiers
        const coreMatch = normalized.match(/(\d+)\s*(pro\s*max|pro|plus|mini|ultra)?/);
        if (coreMatch) {
          let core = coreMatch[1];
          if (coreMatch[2]) {
            core += ' ' + coreMatch[2].replace(/\s+/g, ' ').trim();
          }
          patterns.push(core);
        }
        
        return patterns;
      };

      // Smart database search function
      const searchDatabase = (patterns: string[]) => {
        console.log('🔍 Searching database with patterns:', patterns);
        
        // First try exact matches
        for (const pattern of patterns) {
          const exactMatches = priceData.filter(item => {
            const itemModel = item.model.toLowerCase();
            return itemModel === pattern || itemModel.includes(pattern);
          });
          
          if (exactMatches.length > 0) {
            console.log(`✅ Found exact matches for "${pattern}":`, exactMatches.map(m => `${m.make} ${m.model}`));
            return exactMatches;
          }
        }
        
        // Then try partial matches with high confidence
        const partialMatches = [];
        for (const pattern of patterns) {
          priceData.forEach(item => {
            const itemModel = normalizeModel(item.model);
            const normalizedPattern = normalizeModel(pattern);
            
            // Check if the item model contains key parts of our pattern
            if (itemModel.includes(normalizedPattern) || normalizedPattern.includes(itemModel)) {
              const similarity = calculateSimilarity(itemModel, normalizedPattern);
              if (similarity > 0.7) {
                partialMatches.push({ item, similarity, pattern });
              }
            }
          });
        }
        
        // Sort by similarity and return best matches
        partialMatches.sort((a, b) => b.similarity - a.similarity);
        return partialMatches.slice(0, 5).map(m => m.item);
      };
      
      const normalizedDeviceModel = normalizeModel(deviceModel);
      const modelPatterns = extractModelPatterns(deviceModel);
      
      console.log('🔍 AUTO-FILL: Normalized device model:', normalizedDeviceModel);
      console.log('🔍 AUTO-FILL: Extracted model patterns:', modelPatterns);
      
      // Try smart database search first for better results
      const quickMatches = searchDatabase(modelPatterns);
      if (quickMatches.length > 0) {
        console.log('🔍 AUTO-FILL: ✅ Quick database search found matches:', quickMatches.map(m => `${m.make} ${m.model}`));
        
        // Use the first match from quick search
        const quickMatch = quickMatches[0];
        setFormData(prev => ({
          ...prev,
          make: quickMatch.make,
          model: quickMatch.model
        }));
        
        // Auto-select storage if only one option available
        setTimeout(() => {
          const storageOptions = priceData
            .filter(item => item.make === quickMatch.make && item.model === quickMatch.model)
            .map(item => item.memorySize);
          const uniqueStorageOptions = [...new Set(storageOptions)];
          
          if (uniqueStorageOptions.length === 1) {
            console.log('🔍 AUTO-FILL: Auto-selecting single storage option:', uniqueStorageOptions[0]);
            setFormData(prev => ({ ...prev, storage: uniqueStorageOptions[0] }));
          }
        }, 100);
        
        return; // Exit early if quick search succeeded
      }
      
      // Fall back to comprehensive matching with scoring
      console.log('🔍 AUTO-FILL: No quick matches found, falling back to comprehensive scoring...');
      
      // Enhanced matching with multiple scoring strategies including pattern matching
      const matches = priceData.map(item => {
        const normalizedPriceModel = normalizeModel(item.model);
        const normalizedMake = item.make.toLowerCase();
        
        let score = 0;
        const scoringDetails = {
          exactMatch: 0,
          patternMatch: 0,
          containsMatch: 0,
          wordMatch: 0,
          similarityMatch: 0,
          numberMatch: 0,
          makeInModel: 0
        };
        
        // Strategy 1: Exact match (highest priority)
        if (normalizedPriceModel === normalizedDeviceModel) {
          scoringDetails.exactMatch = 1.0;
          score = 1.0;
        } else {
          // Strategy 2: Pattern matching - check if any extracted patterns match
          let bestPatternScore = 0;
          for (const pattern of modelPatterns) {
            const normalizedPattern = normalizeModel(pattern);
            
            // Check exact pattern match
            if (normalizedPriceModel === normalizedPattern) {
              bestPatternScore = Math.max(bestPatternScore, 0.95);
            }
            // Check if price model contains the pattern
            else if (normalizedPriceModel.includes(normalizedPattern)) {
              bestPatternScore = Math.max(bestPatternScore, 0.9);
            }
            // Check if pattern contains the price model (for cases like "15 pro max" matching "iPhone 15 Pro Max")
            else if (normalizedPattern.includes(normalizedPriceModel) && normalizedPriceModel.length > 2) {
              bestPatternScore = Math.max(bestPatternScore, 0.85);
            }
            
            // Special handling for iPhone models
            if (normalizedMake === 'apple' && pattern.includes('iphone')) {
              const priceModelLower = item.model.toLowerCase();
              
              // Check for specific iPhone patterns like "15 pro max" in "iPhone 15 Pro Max"
              if (pattern.includes('pro max') && priceModelLower.includes('pro max')) {
                const patternNumbers = pattern.match(/\d+/g) || [];
                const priceNumbers = item.model.match(/\d+/g) || [];
                if (patternNumbers.length > 0 && priceNumbers.length > 0 && patternNumbers[0] === priceNumbers[0]) {
                  bestPatternScore = Math.max(bestPatternScore, 0.95);
                }
              }
              else if (pattern.includes('pro') && !pattern.includes('max') && priceModelLower.includes('pro') && !priceModelLower.includes('pro max')) {
                const patternNumbers = pattern.match(/\d+/g) || [];
                const priceNumbers = item.model.match(/\d+/g) || [];
                if (patternNumbers.length > 0 && priceNumbers.length > 0 && patternNumbers[0] === priceNumbers[0]) {
                  bestPatternScore = Math.max(bestPatternScore, 0.9);
                }
              }
              else if (pattern.includes('plus') && priceModelLower.includes('plus')) {
                const patternNumbers = pattern.match(/\d+/g) || [];
                const priceNumbers = item.model.match(/\d+/g) || [];
                if (patternNumbers.length > 0 && priceNumbers.length > 0 && patternNumbers[0] === priceNumbers[0]) {
                  bestPatternScore = Math.max(bestPatternScore, 0.9);
                }
              }
            }
          }
          
          scoringDetails.patternMatch = bestPatternScore;
          score = Math.max(score, bestPatternScore);
          
          // Strategy 3: Contains match
          if (normalizedPriceModel.includes(normalizedDeviceModel)) {
            scoringDetails.containsMatch = 0.85;
            score = Math.max(score, 0.85);
          } else if (normalizedDeviceModel.includes(normalizedPriceModel) && normalizedPriceModel.length > 2) {
            scoringDetails.containsMatch = 0.8;
            score = Math.max(score, 0.8);
          }
          
          // Strategy 4: Word-based matching
          const deviceWords = normalizedDeviceModel.split(' ').filter(w => w.length > 1);
          const priceWords = normalizedPriceModel.split(' ').filter(w => w.length > 1);
          
          if (deviceWords.length > 0 && priceWords.length > 0) {
            let wordMatches = 0;
            
            deviceWords.forEach(deviceWord => {
              priceWords.forEach(priceWord => {
                if (deviceWord === priceWord) {
                  wordMatches += 1;
                } else if (deviceWord.length > 2 && priceWord.length > 2) {
                  if (deviceWord.includes(priceWord) || priceWord.includes(deviceWord)) {
                    wordMatches += 0.8;
                  } else if (calculateSimilarity(deviceWord, priceWord) > 0.85) {
                    wordMatches += 0.7;
                  }
                }
              });
            });
            
            scoringDetails.wordMatch = wordMatches / Math.max(deviceWords.length, priceWords.length);
            score = Math.max(score, scoringDetails.wordMatch * 0.7); // Reduce weight to prioritize pattern matching
          }
          
          // Strategy 5: Edit distance similarity
          const similarity = calculateSimilarity(normalizedDeviceModel, normalizedPriceModel);
          if (similarity > 0.6) {
            scoringDetails.similarityMatch = similarity;
            score = Math.max(score, similarity * 0.6); // Reduce weight
          }
          
          // Strategy 6: Number sequence matching
          const deviceNumbers: string[] = normalizedDeviceModel.match(/\d+/g) || [];
          const priceNumbers: string[] = normalizedPriceModel.match(/\d+/g) || [];
          
          if (deviceNumbers.length > 0 && priceNumbers.length > 0) {
            const commonNumbers = deviceNumbers.filter(num => priceNumbers.includes(num));
            scoringDetails.numberMatch = commonNumbers.length / Math.max(deviceNumbers.length, priceNumbers.length);
            
            // Boost score for number matches
            if (scoringDetails.numberMatch > 0.5) {
              score = Math.max(score, score + scoringDetails.numberMatch * 0.2);
            }
          }
          
          // Strategy 7: Check if make is mentioned in device model
          if (normalizedDeviceModel.includes(normalizedMake)) {
            scoringDetails.makeInModel = 0.2;
            score += 0.1; // Reduce boost
          }
        }
        
        return {
          item,
          score: Math.min(score, 1.0), // Cap at 1.0
          details: scoringDetails
        };
      });
      
      // Sort by score and get best matches
      matches.sort((a, b) => b.score - a.score);
      
      console.log('🔍 AUTO-FILL: Top 10 scoring matches:', matches.slice(0, 10).map(m => ({
        make: m.item.make,
        model: m.item.model,
        score: m.score.toFixed(3),
        details: m.details
      })));
      
      const bestMatch = matches[0];
      
      // Use best match if score is above 50% threshold and model exists in database
      if (bestMatch && bestMatch.score > 0.5) {
        console.log('🔍 AUTO-FILL: ✅ Auto-selecting best match (>50% confidence):', {
          detectedModel: testResults.deviceModel,
          matchedMake: bestMatch.item.make,
          matchedModel: bestMatch.item.model,
          confidence: (bestMatch.score * 100).toFixed(1) + '%',
          scoringBreakdown: bestMatch.details
        });
        
        setFormData(prev => ({
          ...prev,
          make: bestMatch.item.make,
          model: bestMatch.item.model
        }));
        
        // Auto-select storage if only one option available
        setTimeout(() => {
          const storageOptions = priceData
            .filter(item => item.make === bestMatch.item.make && item.model === bestMatch.item.model)
            .map(item => item.memorySize);
          const uniqueStorageOptions = [...new Set(storageOptions)];
          
          if (uniqueStorageOptions.length === 1) {
            console.log('🔍 AUTO-FILL: Auto-selecting single storage option:', uniqueStorageOptions[0]);
            setFormData(prev => ({ ...prev, storage: uniqueStorageOptions[0] }));
          }
        }, 100);
        
      } else {
        console.log('🔍 AUTO-FILL: ❌ No confident match found (best score:', bestMatch?.score?.toFixed(3) || 'none', ')');
        
        // Fallback: Try to detect make only
        const makeMap = {
          samsung: 'Samsung',
          apple: 'Apple', 
          iphone: 'Apple',
          google: 'Google',
          pixel: 'Google',
          oneplus: 'OnePlus',
          'one plus': 'OnePlus',
          xiaomi: 'Xiaomi',
          redmi: 'Xiaomi',
          huawei: 'Huawei',
          honor: 'Honor',
          nokia: 'Nokia',
          motorola: 'Motorola',
          sony: 'Sony',
          oppo: 'Oppo',
          vivo: 'Vivo',
          realme: 'Realme'
        };
        
        for (const [brand, make] of Object.entries(makeMap)) {
          if (deviceModel.includes(brand)) {
            // Check if this make exists in our available makes
            if (availableMakes.includes(make)) {
              console.log('🔍 AUTO-FILL: ✅ Detected make only:', make);
              setFormData(prev => ({ ...prev, make, model: '' }));
              break;
            }
          }
        }
      }
    }
  }, [testResults, priceData, availableMakes]);

  // Grade restrictions based on test results
  const getAvailableGrades = () => {
    if (testResults?.overallScore !== undefined) {
      if (testResults.overallScore >= 70) {
        return [
          { value: 'cosmetic', label: 'Cosmetic' },
          { value: 'excellent', label: 'Excellent' },
          { value: 'good', label: 'Good' },
          { value: 'screen-broken', label: 'Screen Broken' },
          { value: 'case-broken', label: 'Case Broken' }
        ];
      } else {
        // Below 70% - only B and C grades (Good, Screen Broken, Case Broken)
        return [
          { value: 'good', label: 'Good' },
          { value: 'screen-broken', label: 'Screen Broken' },
          { value: 'case-broken', label: 'Case Broken' }
        ];
      }
    }
    
    // Default condition options when no test results
    return [
      { value: 'cosmetic', label: 'Cosmetic' },
      { value: 'excellent', label: 'Excellent' },
      { value: 'good', label: 'Good' },
      { value: 'screen-broken', label: 'Screen Broken' },
      { value: 'case-broken', label: 'Case Broken' }
    ];
  };

  const conditionOptions = getAvailableGrades();

  const handleMakeChange = (make: string) => {
    console.log('🔍 FORM DEBUG: Make changed to:', make);
    setFormData(prev => ({ 
      ...prev, 
      make, 
      model: '', 
      storage: '' 
    }));
  };

  const handleModelChange = (model: string) => {
    console.log('🔍 FORM DEBUG: Model changed to:', model);
    setFormData(prev => ({ 
      ...prev, 
      model,
      storage: '' 
    }));
  };

  const handleStoreIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    console.log('🔍 FORM: Store ID input changed to:', `"${value}"`);
    
    setFormData(prev => {
      const updated = { ...prev, storeId: value };
      console.log('🔍 FORM: Updated formData storeId:', `"${updated.storeId}"`);
      return updated;
    });
  };

  const handleImeiChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    console.log('🔍 FORM: IMEI input changed to:', `"${value}"`);
    
    setFormData(prev => {
      const updated = { ...prev, imeiNumber: value };
      console.log('🔍 FORM: Updated formData imeiNumber:', `"${updated.imeiNumber}"`);
      return updated;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('🚀 ===== PHONE INFO FORM SUBMISSION START =====');
    console.log('🚀 FORM: Complete formData at submission:', formData);
    
    if (formData.make && formData.model && formData.storage && formData.condition && formData.storeId?.trim()) {
      const submissionData = {
        make: formData.make,
        model: formData.model,
        storage: formData.storage,
        condition: formData.condition,
        batteryHealth: formData.batteryHealth ? parseInt(formData.batteryHealth) : undefined,
        storeId: formData.storeId.trim(),
        imeiNumber: formData.imeiNumber?.trim() || undefined
      };
      
      console.log('🚀 FORM: Final submission data being sent to parent:', submissionData);
      onSubmit(submissionData);
    } else {
      console.log('❌ FORM: Validation failed - missing required fields');
      console.log('❌ FORM: Missing fields check:');
      console.log('  - make:', !!formData.make, `"${formData.make}"`);
      console.log('  - model:', !!formData.model, `"${formData.model}"`);
      console.log('  - storage:', !!formData.storage, `"${formData.storage}"`);
      console.log('  - condition:', !!formData.condition, `"${formData.condition}"`);
      console.log('  - storeId (trimmed):', !!(formData.storeId?.trim()), `"${formData.storeId?.trim()}"`);
    }
  };

  // Use tile selection for makes with 5+ models to ensure we catch everything
  const useTileSelection = availableModels.length >= 5;

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <Smartphone className="text-blue-600" />
          Phone Information
        </CardTitle>
        <p className="text-gray-600">Tell us about your phone to get started</p>
        
        {/* Database status indicator */}
        <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
          <Database size={14} />
          <span>{priceData.length} device records loaded</span>
        </div>

        {/* Test results indicator */}
        {testResults?.deviceModel && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-4">
            <div className="flex items-center gap-2 text-blue-800">
              <Smartphone size={16} />
              <span className="font-medium">Mobile Test Results Detected</span>
            </div>
            <p className="text-blue-700 text-sm mt-1">
              Device: {testResults.deviceModel} | Test Score: {testResults.overallScore}%
            </p>
            <p className="text-blue-600 text-xs mt-1">
              Form has been auto-filled where possible. Grade options are restricted based on test results.
            </p>
          </div>
        )}
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="make">Phone Make</Label>
              <Select value={formData.make} onValueChange={handleMakeChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select phone make" />
                </SelectTrigger>
                <SelectContent>
                  {availableMakes.map(make => (
                    <SelectItem key={make} value={make}>{make}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <HardDrive size={16} />
                Memory Size
              </Label>
              <Select value={formData.storage} onValueChange={(value) => {
                console.log('🔍 FORM DEBUG: Memory size selected:', value);
                setFormData(prev => ({ ...prev, storage: value }));
              }} disabled={!formData.model}>
                <SelectTrigger>
                  <SelectValue placeholder={formData.model ? "Select memory size" : "Select model first"} />
                </SelectTrigger>
                <SelectContent>
                  {availableMemorySize.map(memorySize => (
                    <SelectItem key={memorySize} value={memorySize}>{memorySize}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="model">
              Phone Model
              {formData.make && (
                <span className="text-sm text-gray-500 ml-2">
                  ({availableModels.length} models available)
                  {useTileSelection && (
                    <span className="text-blue-600"> - Using enhanced search view</span>
                  )}
                </span>
              )}
            </Label>
            {!formData.make ? (
              <div className="p-4 border rounded-lg bg-gray-50 text-center text-gray-500">
                Please select a phone make first
              </div>
            ) : useTileSelection ? (
              <ModelTileSelection
                models={availableModels}
                selectedModel={formData.model}
                onModelSelect={handleModelChange}
                make={formData.make}
              />
            ) : (
              <Select value={formData.model} onValueChange={handleModelChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select phone model" />
                </SelectTrigger>
                <SelectContent>
                  {availableModels.map(model => (
                    <SelectItem key={model} value={model}>{model}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Settings size={16} />
                Condition
                {testResults?.overallScore !== undefined && (
                  <span className={`ml-2 text-xs px-2 py-1 rounded-full ${
                    testResults.overallScore >= 70 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-orange-100 text-orange-700'
                  }`}>
                    {testResults.overallScore >= 70 
                      ? `✓ All grades available (Score: ${testResults.overallScore}%)` 
                      : `⚠ Limited to B/C grades (Score: ${testResults.overallScore}%)`
                    }
                  </span>
                )}
              </Label>
              <Select value={formData.condition} onValueChange={(value) => setFormData(prev => ({ ...prev, condition: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select condition" />
                </SelectTrigger>
                <SelectContent>
                  {conditionOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Battery size={16} />
                Battery Health (%)
              </Label>
              <Input
                type="number"
                value={formData.batteryHealth}
                onChange={(e) => setFormData(prev => ({ ...prev, batteryHealth: e.target.value }))}
                placeholder="Enter battery health percentage (e.g., 85)"
                min="0"
                max="100"
                className="w-full"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Scan size={16} />
                Store ID *
              </Label>
              <Input
                type="text"
                value={formData.storeId}
                onChange={handleStoreIdChange}
                placeholder="Enter store ID (e.g., STORE001)"
                className="w-full"
                required
                maxLength={50}
              />
              <p className="text-sm text-gray-500">Required field for tracking</p>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Hash size={16} />
                IMEI Number
              </Label>
              <Input
                type="text"
                value={formData.imeiNumber}
                onChange={handleImeiChange}
                placeholder="Enter IMEI number (e.g., *#06#)"
                className="w-full"
                maxLength={20}
                pattern="[0-9]*"
              />
              <p className="text-sm text-gray-500">Optional - Used for device identification</p>
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
            disabled={!formData.make || !formData.model || !formData.storage || !formData.condition || !formData.storeId?.trim()}
          >
            Continue to Contact Details
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default PhoneInfoForm;
