
import React, { useState, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Search, Smartphone, Filter, RefreshCw } from 'lucide-react';

interface ModelTileSelectionProps {
  models: string[];
  selectedModel: string;
  onModelSelect: (model: string) => void;
  make: string;
}

const ModelTileSelection: React.FC<ModelTileSelectionProps> = ({
  models,
  selectedModel,
  onModelSelect,
  make
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAll, setShowAll] = useState(false);

  const filteredModels = useMemo(() => {
    let filtered = models;
    
    if (searchTerm.trim()) {
      filtered = models.filter(model =>
        model.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Show more models by default, only limit if there are A LOT
    if (!showAll && filtered.length > 200) {
      filtered = filtered.slice(0, 200);
    }
    
    return filtered;
  }, [models, searchTerm, showAll]);

  // Enhanced debugging for all makes, especially Samsung
  console.log(`🔍 MODEL TILES DEBUG for ${make}:`);
  console.log(`📱 Total models received:`, models.length);
  console.log(`🔎 Search term: "${searchTerm}"`);
  console.log(`📋 Filtered models count:`, filteredModels.length);
  console.log(`🔄 Show all enabled:`, showAll);
  
  // Specific debugging for Samsung models
  if (make === 'Samsung') {
    console.log(`📱 ALL SAMSUNG MODELS (first 50):`, models.slice(0, 50));
    console.log(`📱 ALL SAMSUNG MODELS (last 50):`, models.slice(-50));
    
    // Look for S20 specifically
    const s20Models = models.filter(model => 
      model.toLowerCase().includes('s20') || 
      model.toLowerCase().includes('s 20') ||
      model.toLowerCase().includes('galaxy s20') ||
      model.toLowerCase().includes('galaxy s 20')
    );
    console.log(`📱 SAMSUNG S20 MODELS FOUND (${s20Models.length}):`, s20Models);
    
    // Look for fold models
    const foldModels = models.filter(model => 
      model.toLowerCase().includes('fold') || 
      model.toLowerCase().includes('flip') ||
      model.toLowerCase().includes('z fold') ||
      model.toLowerCase().includes('z flip')
    );
    console.log(`📱 SAMSUNG FOLD/FLIP MODELS FOUND (${foldModels.length}):`, foldModels);
    
    // Show all unique model patterns for debugging
    const modelPatterns = new Set();
    models.forEach(model => {
      const pattern = model.toLowerCase().replace(/\s+/g, ' ').trim();
      if (pattern.includes('s2') || pattern.includes('galaxy s2') || pattern.includes('fold') || pattern.includes('flip')) {
        modelPatterns.add(pattern);
      }
    });
    console.log(`📱 SAMSUNG PATTERN ANALYSIS:`, Array.from(modelPatterns).sort());
    
    // Check if search term matches any models
    if (searchTerm.toLowerCase().includes('s20') || searchTerm.toLowerCase().includes('fold') || searchTerm.toLowerCase().includes('flip')) {
      const searchResults = models.filter(model =>
        model.toLowerCase().includes(searchTerm.toLowerCase())
      );
      console.log(`🔎 SEARCH RESULTS for "${searchTerm}":`, searchResults);
    }
  }

  const handleClearSearch = () => {
    setSearchTerm('');
    setShowAll(false);
  };

  const handleShowAll = () => {
    setShowAll(true);
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label className="flex items-center gap-2">
          <Search size={16} />
          Search Models ({models.length} total available)
        </Label>
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder={`Search ${make} models (e.g., "s20", "fold", "ultra", "pro")...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
          <Button 
            onClick={handleClearSearch} 
            variant="outline" 
            size="sm"
            className="flex items-center gap-1"
          >
            <RefreshCw size={14} />
            Clear
          </Button>
        </div>
        
        <div className="flex items-center justify-between text-sm text-gray-600">
          <span>
            Showing {filteredModels.length} of {models.length} models
            {!showAll && filteredModels.length === 200 && models.length > 200 && (
              <span className="text-orange-600"> (limited to first 200)</span>
            )}
          </span>
          
          {!showAll && models.length > 200 && (
            <Button 
              onClick={handleShowAll} 
              variant="outline" 
              size="sm"
              className="text-blue-600 border-blue-300 hover:bg-blue-50"
            >
              <Filter size={14} className="mr-1" />
              Show All {models.length} Models
            </Button>
          )}
        </div>

        {/* Enhanced quick search suggestions */}
        {make === 'Samsung' && !searchTerm && (
          <div className="flex flex-wrap gap-2 pt-2">
            <span className="text-sm text-gray-500">Quick search:</span>
            {['s20', 's21', 's22', 's23', 's24', 's25', 'fold', 'flip', 'ultra', 'pro', 'note', 'galaxy'].map(term => (
              <Button
                key={term}
                onClick={() => setSearchTerm(term)}
                variant="outline"
                size="sm"
                className="text-xs px-2 py-1 h-auto"
              >
                {term}
              </Button>
            ))}
          </div>
        )}

        {/* Show debug info for Samsung when no search term */}
        {make === 'Samsung' && !searchTerm && (
          <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
            Debug: Found {models.length} Samsung models. Try searching for "s20" to find S20 series.
          </div>
        )}
      </div>

      <div className="max-h-96 overflow-y-auto border rounded-lg p-2 bg-gray-50">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {filteredModels.map((model) => (
            <Card
              key={model}
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedModel === model
                  ? 'ring-2 ring-blue-500 bg-blue-50 border-blue-300'
                  : 'hover:bg-gray-50 bg-white'
              }`}
              onClick={() => onModelSelect(model)}
            >
              <CardContent className="p-3">
                <div className="flex items-center gap-2">
                  <Smartphone size={16} className="text-gray-600 flex-shrink-0" />
                  <span className="text-sm font-medium truncate" title={model}>
                    {model}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {filteredModels.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <Smartphone size={48} className="mx-auto mb-2 opacity-50" />
            <p>No models found matching "{searchTerm}"</p>
            <p className="text-sm">Try a different search term or clear the search</p>
            {searchTerm && (
              <Button 
                onClick={handleClearSearch} 
                variant="outline" 
                size="sm" 
                className="mt-2"
              >
                Clear Search
              </Button>
            )}
          </div>
        )}

        {/* Show load more option at bottom if there are more models */}
        {!showAll && filteredModels.length === 200 && models.length > 200 && (
          <div className="text-center pt-4 border-t mt-4">
            <Button 
              onClick={handleShowAll}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Load All {models.length} Models
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ModelTileSelection;
