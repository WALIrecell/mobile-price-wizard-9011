
import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, CheckCircle, Smartphone, Volume2, VolumeX, Camera, Cpu, Wifi, Speaker } from 'lucide-react';
import { PhoneData } from '../pages/Index';
import { DiagnosticTest, DiagnosticAnimationProps } from '../types/diagnostic';
import { ModemAudioManager } from '../utils/modemAudio';
import { generateOrRetrieveTestResults } from '../utils/diagnosticTestGenerator';
import PhoneVisualization from './PhoneVisualization';
import DiagnosticTestResults from './DiagnosticTestResults';

const iconMap = {
  Camera,
  Cpu,
  Smartphone,
  Wifi,
  Speaker
};

const DiagnosticAnimation: React.FC<DiagnosticAnimationProps> = ({ phoneData, onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [currentTest, setCurrentTest] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [usingCachedResults, setUsingCachedResults] = useState(false);
  
  const audioManagerRef = useRef<ModemAudioManager | null>(null);
  
  // Generate or retrieve cached test results and add icons
  const [tests, setTests] = useState<DiagnosticTest[]>(() => {
    const results = generateOrRetrieveTestResults(phoneData);
    // Add icons to the results
    const testsWithIcons = results.map(test => {
      if (test.iconName && iconMap[test.iconName]) {
        const IconComponent = iconMap[test.iconName];
        return {
          ...test,
          icon: <IconComponent size={20} />
        };
      }
      return test;
    });
    
    // Check if we're using cached results
    if (phoneData.imeiNumber) {
      setUsingCachedResults(true);
    }
    return testsWithIcons;
  });

  // Initialize audio manager
  useEffect(() => {
    audioManagerRef.current = new ModemAudioManager(soundEnabled);
    
    return () => {
      if (audioManagerRef.current) {
        audioManagerRef.current.cleanup();
      }
    };
  }, [soundEnabled]);

  useEffect(() => {
    if (currentTest < tests.length) {
      const timer = setTimeout(() => {
        // Play modem handshake when starting a test
        audioManagerRef.current?.playModemHandshakeSequence();
        
        // Start testing current component
        setTests(prev => prev.map((test, index) => 
          index === currentTest ? { ...test, status: 'testing' as const } : test
        ));

        // Play data transmission sound during test
        setTimeout(() => audioManagerRef.current?.playDataTransmissionSound(), 1000);

        // Complete test after duration with predetermined result
        setTimeout(() => {
          setTests(prev => prev.map((test, index) => {
            if (index === currentTest) {
              // Play result sound
              if (test.finalStatus === 'passed') {
                audioManagerRef.current?.playModemConnectedTone();
              } else {
                audioManagerRef.current?.playModemErrorSequence();
              }
              return { ...test, status: test.finalStatus };
            }
            return test;
          }));
          setCurrentTest(prev => prev + 1);
          setProgress(prev => prev + (100 / tests.length));
        }, tests[currentTest].duration);
      }, 500);

      return () => clearTimeout(timer);
    } else if (currentTest >= tests.length && !isComplete) {
      setTimeout(() => {
        setIsComplete(true);
        // Play simple beep instead of modem negotiation tones
        if (soundEnabled) {
          audioManagerRef.current?.playCompletionBeep();
        }
      }, 1000);
    }
  }, [currentTest, tests.length, isComplete, soundEnabled]);

  const toggleSound = () => {
    setSoundEnabled(!soundEnabled);
    if (audioManagerRef.current) {
      audioManagerRef.current.setSoundEnabled(!soundEnabled);
      if (!soundEnabled) {
        // Play test sound when enabling - a classic carrier tone
        setTimeout(() => audioManagerRef.current?.playModemConnectedTone(), 100);
      }
    }
  };

  const failedTests = tests.filter(test => test.status === 'failed').length;
  const passedTests = tests.filter(test => test.status === 'passed').length;

  const handleComplete = () => {
    onComplete(tests);
  };

  return (
    <Card className="max-w-4xl mx-auto bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 border-purple-500/20">
      <CardHeader className="text-center">
        <div className="flex items-center justify-between">
          <div className="flex-1" />
          <CardTitle className="flex items-center justify-center gap-2 text-2xl text-white">
            <Smartphone className="text-purple-400" />
            Advanced Diagnostic Scanning
          </CardTitle>
          <div className="flex-1 flex justify-end">
            <Button
              onClick={toggleSound}
              variant="ghost"
              size="sm"
              className="text-purple-200 hover:text-white hover:bg-purple-800/30"
            >
              {soundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
            </Button>
          </div>
        </div>
        <p className="text-purple-200">
          Analyzing {phoneData.make} {phoneData.model} with AI-powered diagnostics
        </p>
        {usingCachedResults && phoneData.imeiNumber && (
          <p className="text-yellow-300 text-sm animate-pulse">
            📱 Using cached results for IMEI: {phoneData.imeiNumber} (valid for 24 hours)
          </p>
        )}
        {soundEnabled && currentTest < tests.length && (
          <p className="text-purple-300 text-sm animate-pulse">
            🔊 1995 Dial-Up Modem Audio - Authentic Handshake & Data Transfer Sounds
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Futuristic Phone Visualization */}
        <PhoneVisualization 
          progress={progress}
          currentTest={currentTest}
          tests={tests}
        />

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-purple-200">
            <span>Diagnostic Progress</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-3 bg-slate-700 [&>div]:bg-gradient-to-r [&>div]:from-purple-500 [&>div]:to-pink-500" />
        </div>

        {/* Test Results */}
        <DiagnosticTestResults tests={tests} />

        {/* Summary */}
        {isComplete && (
          <div className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 p-4 rounded-lg border border-purple-400/30 space-y-2">
            <h4 className="font-semibold text-purple-100">Diagnostic Summary</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2 text-green-400">
                <CheckCircle size={16} />
                <span>{passedTests} Components Healthy</span>
              </div>
              <div className="flex items-center gap-2 text-red-400">
                <AlertTriangle size={16} />
                <span>{failedTests} Issues Detected</span>
              </div>
            </div>
            {usingCachedResults && (
              <div className="text-yellow-300 text-sm mt-2">
                ℹ️ Results retrieved from 24-hour cache for consistent evaluation
              </div>
            )}
          </div>
        )}

        {isComplete && (
          <Button 
            onClick={handleComplete}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-3 text-lg shadow-lg"
          >
            Continue to Condition Assessment
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default DiagnosticAnimation;
