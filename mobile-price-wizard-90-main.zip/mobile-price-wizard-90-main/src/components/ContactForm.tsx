
import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Phone, ArrowRight } from 'lucide-react';
import EmailVerificationMessage from './EmailVerificationMessage';

interface ContactFormProps {
  onSubmit: (mobileNumber: string) => void;
}

const ContactForm: React.FC<ContactFormProps> = ({ onSubmit }) => {
  const [mobileNumber, setMobileNumber] = useState('');
  const [showEmailVerification, setShowEmailVerification] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!mobileNumber.trim()) {
      toast({
        title: "Mobile number required",
        description: "Please enter your mobile number to continue.",
        variant: "destructive",
      });
      return;
    }

    // Validate mobile number format
    const cleanNumber = mobileNumber.replace(/\D/g, '');
    if (cleanNumber.length < 10) {
      toast({
        title: "Invalid mobile number",
        description: "Please enter a valid mobile number.",
        variant: "destructive",
      });
      return;
    }

    // If email verification is needed, show the message
    if (mobileNumber.includes('@')) {
      setUserEmail(mobileNumber);
      setShowEmailVerification(true);
      return;
    }

    onSubmit(mobileNumber);
  };

  const handleResendEmail = () => {
    toast({
      title: "Email Resent",
      description: "We've sent another verification email to your inbox.",
    });
  };

  if (showEmailVerification) {
    return (
      <EmailVerificationMessage 
        email={userEmail}
        onResendEmail={handleResendEmail}
      />
    );
  }

  return (
    <Card className="p-8 bg-white/90 backdrop-blur-sm border border-pink-200 shadow-xl">
      <div className="text-center mb-6">
        <div className="mx-auto w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center mb-4">
          <Phone className="h-8 w-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          Contact Information
        </h2>
        <p className="text-gray-600">
          Please provide your mobile number for updates about your trade-in
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label htmlFor="mobile" className="text-sm font-medium text-gray-700">
            Mobile Number *
          </Label>
          <Input
            id="mobile"
            type="tel"
            value={mobileNumber}
            onChange={(e) => setMobileNumber(e.target.value)}
            placeholder="Enter your mobile number"
            className="mt-1 border-pink-300 focus:border-pink-500 focus:ring-pink-500"
            required
          />
          <p className="text-xs text-gray-500 mt-1">
            We'll send you updates about your trade-in offer
          </p>
        </div>

        <Button 
          type="submit" 
          className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg"
        >
          Continue
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </form>
    </Card>
  );
};

export default ContactForm;
