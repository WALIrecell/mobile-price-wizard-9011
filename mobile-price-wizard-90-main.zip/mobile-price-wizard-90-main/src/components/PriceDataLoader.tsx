
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Database, RefreshCw, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface PriceData {
  make: string;
  model: string;
  memorySize: string;
  gradeA: number;
  gradeB: number;
  gradeC: number;
  broken: number;
}

interface PriceDataLoaderProps {
  onPriceDataLoaded: (priceData: PriceData[]) => void;
}

const PriceDataLoader: React.FC<PriceDataLoaderProps> = ({ onPriceDataLoaded }) => {
  const [priceData, setPriceData] = useState<PriceData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const loadPriceData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      console.log('🔍 DATABASE QUERY: Starting to fetch ALL data from price_data table...');
      
      // First, get the total count
      const { count, error: countError } = await supabase
        .from('price_data')
        .select('*', { count: 'exact', head: true });

      if (countError) {
        console.error('🔍 COUNT ERROR:', countError);
      } else {
        console.log('🔍 TOTAL RECORDS IN DATABASE:', count);
      }

      // Fetch ALL records in chunks to handle large datasets
      let allData: any[] = [];
      const chunkSize = 1000;
      let offset = 0;
      let hasMore = true;

      while (hasMore) {
        console.log(`🔍 FETCHING CHUNK: offset ${offset}, limit ${chunkSize}`);
        
        const { data: chunk, error } = await supabase
          .from('price_data')
          .select('*')
          .order('make', { ascending: true })
          .range(offset, offset + chunkSize - 1);

        if (error) {
          console.error('🔍 CHUNK ERROR:', error);
          throw error;
        }

        if (chunk && chunk.length > 0) {
          allData = [...allData, ...chunk];
          console.log(`🔍 CHUNK LOADED: ${chunk.length} records. Total so far: ${allData.length}`);
          
          // If we got fewer records than the chunk size, we've reached the end
          if (chunk.length < chunkSize) {
            hasMore = false;
          } else {
            offset += chunkSize;
          }
        } else {
          hasMore = false;
        }
      }

      console.log('🔍 FINAL DATA LOAD: Total records fetched:', allData.length);
      console.log('🔍 DATABASE vs EXPECTED: Database count =', count, ', Fetched =', allData.length);

      if (allData && allData.length > 0) {
        console.log('🔍 FIRST 5 RECORDS:', allData.slice(0, 5));
        console.log('🔍 LAST 5 RECORDS:', allData.slice(-5));
        
        // Get all unique makes
        const allMakes = [...new Set(allData.map(item => item.make))];
        console.log('🔍 ALL MAKES:', allMakes.length, allMakes);
        
        // Detailed Samsung analysis
        const samsungRecords = allData.filter(item => item.make === 'Samsung');
        console.log('🔍 SAMSUNG RECORDS: Total Samsung records in database:', samsungRecords.length);
        
        const samsungModels = [...new Set(samsungRecords.map(item => item.model))];
        console.log('🔍 SAMSUNG MODELS: Unique Samsung models:', samsungModels.length);
        console.log('🔍 SAMSUNG MODELS: First 20:', samsungModels.slice(0, 20));
        console.log('🔍 SAMSUNG MODELS: Last 20:', samsungModels.slice(-20));
        
        // Look for Fold models with comprehensive search
        const foldModels = samsungModels.filter(model => {
          const modelLower = model.toLowerCase();
          return modelLower.includes('fold') || 
                 modelLower.includes('flip') ||
                 modelLower.includes('z fold') ||
                 modelLower.includes('z flip') ||
                 modelLower.includes('galaxy z') ||
                 modelLower.includes('filp'); // Include misspellings
        });
        console.log('📱 FOLD MODELS IN DB:', foldModels.length, foldModels);
        
        // Look for S20 models
        const s20Models = samsungModels.filter(model => {
          const modelLower = model.toLowerCase();
          return modelLower.includes('s20') || 
                 modelLower.includes('s 20') ||
                 modelLower.includes('galaxy s20') ||
                 modelLower.includes('galaxy s 20');
        });
        console.log('📱 S20 MODELS IN DB:', s20Models.length, s20Models);

        const formattedData: PriceData[] = allData.map(item => ({
          make: item.make,
          model: item.model,
          memorySize: item.memory_size,
          gradeA: Number(item.grade_a),
          gradeB: Number(item.grade_b),
          gradeC: Number(item.grade_c),
          broken: Number(item.broken)
        }));

        console.log('🔍 FORMATTED DATA: Total records after formatting:', formattedData.length);
        
        // Final verification of Samsung models in formatted data
        const formattedSamsungModels = [...new Set(formattedData.filter(item => item.make === 'Samsung').map(item => item.model))];
        console.log('🔍 FORMATTED SAMSUNG: Total unique Samsung models after formatting:', formattedSamsungModels.length);

        setPriceData(formattedData);
        onPriceDataLoaded(formattedData);
        
        toast({
          title: "Price data loaded successfully",
          description: `Loaded all ${formattedData.length} records from database (${formattedSamsungModels.length} Samsung models including ${foldModels.length} Fold/Flip and ${s20Models.length} S20 models)`
        });
      } else {
        setError('No price data found in database. Please upload price data using the Admin tab.');
        console.log('🔍 NO DATA: Database returned empty result');
      }
    } catch (err) {
      console.error('Error loading price data:', err);
      setError('Failed to load price data from database');
      toast({
        title: "Error loading price data",
        description: "Please try again or contact support",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadPriceData();
  }, []);

  if (isLoading) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardContent className="flex items-center justify-center py-8">
          <RefreshCw className="animate-spin mr-2" />
          <span>Loading ALL price data from database...</span>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-600">
            <AlertCircle />
            Price Data Not Available
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-600">{error}</p>
          <Button onClick={loadPriceData} variant="outline">
            <RefreshCw className="mr-2 h-4 w-4" />
            Retry Loading
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="text-green-600" />
          All Price Data Loaded Successfully
        </CardTitle>
        <p className="text-sm text-gray-600">
          Ready to evaluate devices using complete price database
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-green-50 p-4 rounded-lg">
          <h3 className="font-semibold mb-2">Complete Database Status:</h3>
          <div className="text-sm text-gray-700 mb-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <strong>Total Records:</strong> {priceData.length}
              </div>
              <div>
                <strong>Unique Models:</strong> {[...new Set(priceData.map(item => item.model))].length}
              </div>
              <div>
                <strong>Unique Makes:</strong> {[...new Set(priceData.map(item => item.make))].length}
              </div>
              <div>
                <strong>Samsung Models:</strong> {[...new Set(priceData.filter(item => item.make === 'Samsung').map(item => item.model))].length}
              </div>
            </div>
          </div>
          
          {/* Show Samsung model breakdown */}
          {priceData.filter(item => item.make === 'Samsung').length > 0 && (
            <div className="mb-4 p-3 bg-blue-50 rounded">
              <h4 className="font-medium text-blue-800 mb-2">Samsung Model Analysis:</h4>
              <div className="text-sm text-blue-700">
                <div>Total Samsung Records: {priceData.filter(item => item.make === 'Samsung').length}</div>
                <div>Unique Samsung Models: {[...new Set(priceData.filter(item => item.make === 'Samsung').map(item => item.model))].length}</div>
                <div>
                  Fold/Flip Models: {[...new Set(priceData.filter(item => 
                    item.make === 'Samsung' && 
                    (item.model.toLowerCase().includes('fold') || 
                     item.model.toLowerCase().includes('flip') ||
                     item.model.toLowerCase().includes('z fold') ||
                     item.model.toLowerCase().includes('z flip') ||
                     item.model.toLowerCase().includes('filp'))
                  ).map(item => item.model))].length}
                </div>
                <div>
                  S20 Models: {[...new Set(priceData.filter(item => 
                    item.make === 'Samsung' && 
                    (item.model.toLowerCase().includes('s20') || 
                     item.model.toLowerCase().includes('s 20'))
                  ).map(item => item.model))].length}
                </div>
              </div>
            </div>
          )}
          
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {priceData.slice(0, 5).map((item, index) => (
              <div key={index} className="text-sm bg-white p-2 rounded">
                <div className="font-medium">{item.make} {item.model} ({item.memorySize})</div>
                <div className="text-xs text-gray-600 mt-1">
                  Grade A: ${item.gradeA} | Grade B: ${item.gradeB} | Grade C: ${item.gradeC} | Broken: ${item.broken}
                </div>
              </div>
            ))}
            {priceData.length > 5 && (
              <div className="text-sm text-gray-500">...and {priceData.length - 5} more entries</div>
            )}
          </div>
          <div className="flex gap-2 mt-4">
            <Button 
              onClick={() => onPriceDataLoaded(priceData)} 
              className="flex-1"
            >
              Start Device Evaluation
            </Button>
            <Button 
              onClick={loadPriceData}
              variant="outline"
              className="flex-1"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh All Data
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PriceDataLoader;
