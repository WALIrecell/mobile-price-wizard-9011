import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { CheckCircle, Plus, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

const formSchema = z.object({
  make: z.string().min(1, 'Make is required'),
  model: z.string().min(1, 'Model is required'),
  memorySize: z.string().min(1, 'Memory size is required'),
  gradeA: z.string().min(1, 'Grade A price is required'),
  gradeB: z.string().min(1, 'Grade B price is required'),
  gradeC: z.string().min(1, 'Grade C price is required'),
  broken: z.string().min(1, 'Broken price is required'),
});

type FormData = z.infer<typeof formSchema>;

interface AdminQuickEntryProps {
  onDataAdded: () => void;
}

const AdminQuickEntry: React.FC<AdminQuickEntryProps> = ({ onDataAdded }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastAdded, setLastAdded] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      make: '',
      model: '',
      memorySize: '',
      gradeA: '',
      gradeB: '',
      gradeC: '',
      broken: '',
    },
  });

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    
    try {
      const priceData = {
        make: data.make,
        model: data.model,
        memory_size: data.memorySize,
        grade_a: parseFloat(data.gradeA),
        grade_b: parseFloat(data.gradeB),
        grade_c: parseFloat(data.gradeC),
        broken: parseFloat(data.broken),
      };

      const { error } = await supabase
        .from('price_data')
        .insert([priceData]);

      if (error) {
        throw error;
      }

      setLastAdded(`${data.make} ${data.model} (${data.memorySize})`);
      form.reset();
      
      toast({
        title: "Entry added successfully",
        description: `${data.make} ${data.model} has been added to the price database`,
      });

      onDataAdded();
    } catch (error) {
      console.error('Error adding price data:', error);
      toast({
        title: "Failed to add entry",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plus className="h-5 w-5" />
          Quick Manual Entry
        </CardTitle>
        <p className="text-sm text-gray-600">
          Add individual device pricing data without uploading a CSV file.
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {lastAdded && (
          <div className="flex items-center space-x-2 text-green-600 bg-green-50 p-3 rounded-lg">
            <CheckCircle className="h-4 w-4" />
            <span className="text-sm">Last added: <strong>{lastAdded}</strong></span>
          </div>
        )}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="make"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Make</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Apple, Samsung" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="model"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Model</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., iPhone 13, Galaxy S21" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="memorySize"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Memory Size</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., 128GB, 256GB, 512GB" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <FormField
                control={form.control}
                name="gradeA"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Grade A Price</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="0.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="gradeB"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Grade B Price</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="0.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="gradeC"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Grade C Price</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="0.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="broken"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Broken Price</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="0.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Adding Entry...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Add to Price Database
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default AdminQuickEntry;