import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Camera, CheckCircle, FileImage, Upload } from 'lucide-react';
import { PhoneData } from '../pages/Index';
import { useToast } from '@/hooks/use-toast';

interface DeviceImagesProps {
  phoneData: PhoneData;
  onComplete: (frontImage: File, backImage: File) => void;
}

const DeviceImages: React.FC<DeviceImagesProps> = ({ phoneData, onComplete }) => {
  const [frontImage, setFrontImage] = useState<File | null>(null);
  const [backImage, setBackImage] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const MAX_FILE_SIZE = 100 * 1024; // 100KB in bytes

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>, type: 'front' | 'back') => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: "Please select an image file (JPG, PNG, etc.)",
          variant: "destructive"
        });
        return;
      }

      // Validate file size (100KB max)
      if (file.size > MAX_FILE_SIZE) {
        toast({
          title: "File too large",
          description: `Please select an image smaller than 100KB. Current file is ${formatFileSize(file.size)}.`,
          variant: "destructive"
        });
        return;
      }

      if (type === 'front') {
        setFrontImage(file);
      } else {
        setBackImage(file);
      }
    }
  };

  const handleContinue = async () => {
    if (!frontImage || !backImage) {
      toast({
        title: "Missing images",
        description: "Please upload both front and back images of the device.",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);
    
    try {
      onComplete(frontImage, backImage);
      
      toast({
        title: "Images captured!",
        description: "Device images have been captured successfully.",
      });
    } catch (error) {
      console.error('Error processing images:', error);
      toast({
        title: "Upload failed",
        description: "There was an error processing your images. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <Camera className="text-blue-600" />
          Capture Device Images
        </CardTitle>
        <p className="text-gray-600">
          Take photos of the front and back of the device (max 100KB each)
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Device Info */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="font-semibold text-blue-900 mb-2">Device Details</h3>
          <p className="text-blue-700">{phoneData.make} {phoneData.model} - {phoneData.storage}</p>
          <p className="text-sm text-blue-600">Grade: {phoneData.grade} | Price: د.إ {phoneData.price}</p>
        </div>

        {/* Front Image Upload */}
        <div className="space-y-3">
          <h4 className="font-semibold flex items-center gap-2">
            <Camera size={16} />
            Front Image
          </h4>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
            <input
              type="file"
              id="front-image"
              accept="image/*"
              onChange={(e) => handleImageChange(e, 'front')}
              className="hidden"
            />
            <label htmlFor="front-image" className="cursor-pointer">
              <div className="space-y-3">
                {frontImage ? (
                  <div className="flex items-center justify-center gap-2 text-green-600">
                    <CheckCircle size={24} />
                    <span>Front image captured</span>
                  </div>
                ) : (
                  <>
                    <FileImage size={32} className="mx-auto text-gray-400" />
                    <p className="text-gray-700">Click to capture front image</p>
                  </>
                )}
                <p className="text-sm text-gray-500">PNG, JPG up to 100KB</p>
              </div>
            </label>
          </div>
          
          {frontImage && (
            <div className="bg-green-50 p-3 rounded-lg">
              <div className="flex items-center gap-3">
                <FileImage size={16} className="text-green-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-green-900">{frontImage.name}</p>
                  <p className="text-xs text-green-600">{formatFileSize(frontImage.size)}</p>
                </div>
                <CheckCircle size={16} className="text-green-600" />
              </div>
            </div>
          )}
        </div>

        {/* Back Image Upload */}
        <div className="space-y-3">
          <h4 className="font-semibold flex items-center gap-2">
            <Camera size={16} />
            Back Image
          </h4>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
            <input
              type="file"
              id="back-image"
              accept="image/*"
              onChange={(e) => handleImageChange(e, 'back')}
              className="hidden"
            />
            <label htmlFor="back-image" className="cursor-pointer">
              <div className="space-y-3">
                {backImage ? (
                  <div className="flex items-center justify-center gap-2 text-green-600">
                    <CheckCircle size={24} />
                    <span>Back image captured</span>
                  </div>
                ) : (
                  <>
                    <FileImage size={32} className="mx-auto text-gray-400" />
                    <p className="text-gray-700">Click to capture back image</p>
                  </>
                )}
                <p className="text-sm text-gray-500">PNG, JPG up to 100KB</p>
              </div>
            </label>
          </div>
          
          {backImage && (
            <div className="bg-green-50 p-3 rounded-lg">
              <div className="flex items-center gap-3">
                <FileImage size={16} className="text-green-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-green-900">{backImage.name}</p>
                  <p className="text-xs text-green-600">{formatFileSize(backImage.size)}</p>
                </div>
                <CheckCircle size={16} className="text-green-600" />
              </div>
            </div>
          )}
        </div>

        {/* Progress Indicator */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex items-center justify-between text-sm">
            <span>Images captured:</span>
            <span className="font-medium">
              {(frontImage ? 1 : 0) + (backImage ? 1 : 0)} / 2
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((frontImage ? 1 : 0) + (backImage ? 1 : 0)) * 50}%` }}
            />
          </div>
        </div>

        <Button 
          onClick={handleContinue}
          disabled={!frontImage || !backImage || isUploading}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
        >
          {isUploading ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Processing...
            </div>
          ) : (
            'Continue to Final Offer'
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default DeviceImages;
