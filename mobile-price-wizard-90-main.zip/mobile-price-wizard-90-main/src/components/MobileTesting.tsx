import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, XCircle, Smartphone, Upload, Zap, Eye, Volume2, Camera, Flashlight, Wifi, Hand, Vibrate, Monitor, Battery, Cpu, Settings, CheckSquare } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';
import { createWorker } from 'tesseract.js';

const MobileTesting: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const sessionId = searchParams.get('sessionId');
  
  // Main app state following 4-step process: upload → verification → testing → results
  const [currentStep, setCurrentStep] = useState<'upload' | 'verification' | 'testing' | 'results'>('upload');
  const [currentTest, setCurrentTest] = useState(0);
  const [testResults, setTestResults] = useState({
    displayTest: false,
    audioTest: false,
    cameraTest: false,
    flashTest: false,
    vibrationTest: false,
    sensorsTest: false,
    connectivityTest: false,
    batteryTest: false,
    performanceTest: false
  });
  const [resultCode, setResultCode] = useState('');
  
  // Display test specific states
  const [displayTestColor, setDisplayTestColor] = useState('black');
  const [isFullscreenTest, setIsFullscreenTest] = useState(false);
  const [isTestingActive, setIsTestingActive] = useState(false);
  const [autoTestResult, setAutoTestResult] = useState<boolean | null>(null);
  const [touchPoints, setTouchPoints] = useState<{x: number, y: number}[]>([]);
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null);

  // Device info states
  const [deviceInfo, setDeviceInfo] = useState({
    make: '',
    model: '',
    selectedModel: '',
    storage: '',
    batteryHealth: ''
  });
  const [uploadedImage, setUploadedImage] = useState<File | null>(null);
  const [isProcessingOCR, setIsProcessingOCR] = useState(false);
  const [extractedModels, setExtractedModels] = useState<string[]>([]);

  const tests = [
    {
      name: 'Display Test',
      key: 'displayTest' as keyof typeof testResults,
      icon: Monitor,
      description: 'Test screen colors and pixels',
      instruction: 'Look for any dead pixels, discoloration, or screen issues',
      autoTest: false
    },
    {
      name: 'Audio Test',
      key: 'audioTest' as keyof typeof testResults,
      icon: Volume2,
      description: 'Test speakers and microphone',
      instruction: 'Listen for sound and speak into microphone',
      autoTest: true
    },
    {
      name: 'Camera Test',
      key: 'cameraTest' as keyof typeof testResults,
      icon: Camera,
      description: 'Test front and rear cameras',
      instruction: 'Allow camera access when prompted',
      autoTest: true
    },
    {
      name: 'Flash Test',
      key: 'flashTest' as keyof typeof testResults,
      icon: Flashlight,
      description: 'Test camera flash/torch',
      instruction: 'Flash will activate automatically',
      autoTest: true
    },
    {
      name: 'Vibration Test',
      key: 'vibrationTest' as keyof typeof testResults,
      icon: Vibrate,
      description: 'Test device vibration motor',
      instruction: 'Feel for vibration patterns',
      autoTest: true
    },
    {
      name: 'Sensors Test',
      key: 'sensorsTest' as keyof typeof testResults,
      icon: Settings,
      description: 'Test device sensors',
      instruction: 'Tilt and move your device',
      autoTest: true
    },
    {
      name: 'Connectivity Test',
      key: 'connectivityTest' as keyof typeof testResults,
      icon: Wifi,
      description: 'Test WiFi and network',
      instruction: 'Checking internet connection',
      autoTest: true
    },
    {
      name: 'Battery Test',
      key: 'batteryTest' as keyof typeof testResults,
      icon: Battery,
      description: 'Test battery status',
      instruction: 'Checking battery health',
      autoTest: true
    },
    {
      name: 'Performance Test',
      key: 'performanceTest' as keyof typeof testResults,
      icon: Cpu,
      description: 'Test device performance',
      instruction: 'Running performance benchmark',
      autoTest: true
    }
  ];

  const currentTestData = tests[currentTest];

  // OCR and device info functions
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadedImage(file);
    setIsProcessingOCR(true);

    try {
      const worker = await createWorker('eng');
      const { data: { text } } = await worker.recognize(file);
      await worker.terminate();

      // Extract device information from OCR text
      const lines = text.split('\n').filter(line => line.trim().length > 0);
      const potentialModels = lines
        .filter(line => {
          const lower = line.toLowerCase();
          return lower.includes('model') || 
                 lower.includes('samsung') || 
                 lower.includes('galaxy') ||
                 lower.includes('iphone') ||
                 lower.includes('pixel') ||
                 lower.includes('android') ||
                 lower.includes('storage') ||
                 lower.includes('gb') ||
                 lower.match(/[a-z]+\s*\d+/i);
        })
        .map(line => line.trim())
        .slice(0, 10);

      setExtractedModels(potentialModels);

      // Auto-extract storage info
      const storageMatch = text.match(/(\d+)\s*GB/i);
      if (storageMatch) {
        setDeviceInfo(prev => ({ ...prev, storage: storageMatch[1] + 'GB' }));
      }

      // Auto-detect phone make and model from database
      await autoDetectPhoneFromDatabase(text, potentialModels);

      toast({
        title: "Image Processed",
        description: `Found ${potentialModels.length} potential device matches`,
      });

      // Move to verification step
      if (potentialModels.length > 0) {
        setCurrentStep('verification');
      }

    } catch (error) {
      console.error('OCR Error:', error);
      toast({
        title: "OCR Failed",
        description: "Could not read text from image. Please try a clearer image.",
        variant: "destructive"
      });
    } finally {
      setIsProcessingOCR(false);
    }
  };

  // Function to auto-detect phone make and model from database
  const autoDetectPhoneFromDatabase = async (ocrText: string, potentialModels: string[]) => {
    try {
      // Fetch all price data from database
      const { data: priceData, error } = await supabase
        .from('price_data')
        .select('make, model');

      if (error) {
        console.error('Database fetch error:', error);
        return;
      }

      if (!priceData || priceData.length === 0) {
        console.log('No price data available');
        return;
      }

      console.log('🔍 AUTO-DETECT: Processing OCR text for database matching');
      console.log('🔍 AUTO-DETECT: OCR Text:', ocrText);
      console.log('🔍 AUTO-DETECT: Potential models:', potentialModels);

      const normalizedOcrText = ocrText.toLowerCase();
      let bestMatch = null;
      let bestScore = 0;

      // Enhanced phone detection patterns
      const phonePatterns = [
        // iPhone patterns
        /iphone\s*(\d+(?:\s*pro(?:\s*max)?)?|\d+(?:\s*plus)?|\d+(?:\s*mini)?)/gi,
        // Samsung Galaxy patterns
        /galaxy\s*([a-z]\d+(?:\s*\w+)*)/gi,
        /samsung\s*([a-z]\d+(?:\s*\w+)*)/gi,
        // General model patterns
        /model[:]\s*([^\n\r]+)/gi,
        // Brand + model patterns
        /(apple|samsung|google|pixel|xiaomi|huawei|oneplus|lg|sony|motorola)\s+([a-z0-9\s]+)/gi
      ];

      // Extract potential phone identifiers from OCR text
      const extractedIdentifiers = [];
      phonePatterns.forEach(pattern => {
        let match;
        while ((match = pattern.exec(normalizedOcrText)) !== null) {
          extractedIdentifiers.push(match[0].trim());
          if (match[1]) extractedIdentifiers.push(match[1].trim());
          if (match[2]) extractedIdentifiers.push(match[2].trim());
        }
      });

      // Add potential models to identifiers
      extractedIdentifiers.push(...potentialModels.map(m => m.toLowerCase()));

      console.log('🔍 AUTO-DETECT: Extracted identifiers:', extractedIdentifiers);

      // Search for matches in database
      for (const identifier of extractedIdentifiers) {
        if (!identifier || identifier.length < 2) continue;

        for (const dbRecord of priceData) {
          const dbMake = dbRecord.make.toLowerCase();
          const dbModel = dbRecord.model.toLowerCase();
          const combinedDbInfo = `${dbMake} ${dbModel}`;

          // Calculate similarity scores
          const makeScore = calculateSimilarity(identifier, dbMake);
          const modelScore = calculateSimilarity(identifier, dbModel);
          const combinedScore = calculateSimilarity(identifier, combinedDbInfo);

          // Check for exact or near-exact matches
          const isExactMakeMatch = identifier.includes(dbMake) || dbMake.includes(identifier);
          const isExactModelMatch = identifier.includes(dbModel) || dbModel.includes(identifier);
          const isExactCombinedMatch = identifier.includes(combinedDbInfo) || combinedDbInfo.includes(identifier);

          // Calculate final score with bonuses for exact matches
          let finalScore = Math.max(makeScore, modelScore, combinedScore);
          if (isExactMakeMatch) finalScore += 0.3;
          if (isExactModelMatch) finalScore += 0.4;
          if (isExactCombinedMatch) finalScore += 0.5;

          // Special handling for iPhone models
          if (identifier.includes('iphone') && dbMake === 'apple') {
            const iphoneNumberMatch = identifier.match(/(\d+)/);
            const dbModelNumberMatch = dbModel.match(/(\d+)/);
            if (iphoneNumberMatch && dbModelNumberMatch && iphoneNumberMatch[1] === dbModelNumberMatch[1]) {
              finalScore += 0.6;
            }
          }

          // Special handling for Samsung Galaxy models
          if ((identifier.includes('galaxy') || identifier.includes('samsung')) && dbMake === 'samsung') {
            const galaxyModelMatch = identifier.match(/([a-z]\d+)/);
            const dbModelMatch = dbModel.match(/([a-z]\d+)/);
            if (galaxyModelMatch && dbModelMatch && galaxyModelMatch[1] === dbModelMatch[1]) {
              finalScore += 0.6;
            }
          }

          console.log(`🔍 AUTO-DETECT: Comparing "${identifier}" with "${dbMake} ${dbModel}" - Score: ${finalScore.toFixed(3)}`);

          if (finalScore > bestScore && finalScore > 0.6) { // Threshold for confident match
            bestScore = finalScore;
            bestMatch = { make: dbRecord.make, model: dbRecord.model };
          }
        }
      }

      // Auto-populate if we found a confident match
      if (bestMatch && bestScore > 0.6) {
        console.log(`🎯 AUTO-DETECT: Found confident match (${bestScore.toFixed(3)}):`, bestMatch);
        
        setDeviceInfo(prev => ({
          ...prev,
          make: bestMatch.make,
          model: bestMatch.model,
          selectedModel: `${bestMatch.make} ${bestMatch.model}`
        }));

        toast({
          title: "Phone Auto-Detected!",
          description: `Found: ${bestMatch.make} ${bestMatch.model}`,
        });
      } else {
        console.log('🔍 AUTO-DETECT: No confident match found, manual selection required');
      }

    } catch (error) {
      console.error('Auto-detection error:', error);
    }
  };

  // Helper function for similarity calculation
  const calculateSimilarity = (str1: string, str2: string): number => {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    if (longer.length === 0) return 1.0;
    return (longer.length - editDistance(longer, shorter)) / longer.length;
  };

  // Helper function for edit distance calculation
  const editDistance = (str1: string, str2: string): number => {
    const matrix = [];
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }
    return matrix[str2.length][str1.length];
  };

  const handleModelSelection = (selectedModel: string) => {
    setDeviceInfo(prev => ({ ...prev, selectedModel }));
  };

  const startTesting = () => {
    if (!deviceInfo.selectedModel) {
      toast({
        title: "Model Required",
        description: "Please select a device model before starting tests",
        variant: "destructive"
      });
      return;
    }
    setCurrentStep('testing');
  };

  // Display test functions
  const startDisplayTest = (color: string) => {
    if (color === 'green') {
      // Special bubble popping test for green
      startBubbleTest();
    } else {
      setDisplayTestColor(color);
      setIsFullscreenTest(true);
      document.documentElement.requestFullscreen?.();
    }
  };

  const startBubbleTest = () => {
    const testOverlay = document.createElement('div');
    testOverlay.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
      z-index: 10000; background: linear-gradient(45deg, #ff0000, #00ff00, #0000ff);
    `;
    
    // Create bubble popping test
    const bubbles: HTMLElement[] = [];
    let poppedCount = 0;
    const totalBubbles = 20;
    let timeLeft = 25;
    let gameEnded = false;
    
    testOverlay.innerHTML = `
      <div style="position: absolute; top: 20px; left: 50%; transform: translateX(-50%); text-align: center; color: white; background: rgba(0,0,0,0.8); padding: 15px; border-radius: 10px; font-size: 18px;">
        <h3 style="margin: 0 0 10px 0;">Touch Screen Test</h3>
        <p style="margin: 5px 0;">Pop all 20 bubbles within 25 seconds!</p>
        <div id="bubbleCounter" style="font-size: 20px; font-weight: bold; margin-top: 10px;">Bubbles: ${totalBubbles}/${totalBubbles}</div>
        <div id="timer" style="font-size: 24px; font-weight: bold; margin-top: 10px; color: #ffff00;">Time: 25s</div>
      </div>
    `;
    
    // Start countdown timer
    const timerInterval = setInterval(() => {
      if (gameEnded) {
        clearInterval(timerInterval);
        return;
      }
      
      timeLeft--;
      const timerEl = document.getElementById('timer');
      if (timerEl) {
        timerEl.textContent = `Time: ${timeLeft}s`;
        if (timeLeft <= 10) {
          timerEl.style.color = '#ff0000'; // Red when time is running out
        }
      }
      
      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        endBubbleTest(false, 'Time\'s up! Test failed.', testOverlay, style);
      }
    }, 1000);
    
    const endBubbleTest = (passed: boolean, message: string, overlay: HTMLElement, styleEl: HTMLElement) => {
      if (gameEnded) return;
      gameEnded = true;
      clearInterval(timerInterval);
      
      const counter = document.getElementById('bubbleCounter');
      if (counter) {
        counter.innerHTML = `<span style="color: ${passed ? '#00ff00' : '#ff0000'};">${message}</span>`;
      }
      
      setTimeout(() => {
        document.body.removeChild(overlay);
        document.head.removeChild(styleEl);
        handleTestResult(passed);
        toast({
          title: passed ? "Display Test Passed!" : "Display Test Failed!",
          description: passed ? "All bubbles successfully popped" : "Time ran out or test failed",
        });
      }, 2000);
    };
    
    // Create bubbles at random positions
    for (let i = 0; i < totalBubbles; i++) {
      const bubble = document.createElement('div');
      const size = 50 + Math.random() * 30; // Random size between 50-80px
      const hue = Math.random() * 360;
      
      bubble.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        background: radial-gradient(circle, hsla(${hue}, 70%, 80%, 0.9), hsla(${hue}, 60%, 60%, 0.7));
        border-radius: 50%;
        border: 3px solid rgba(255,255,255,0.8);
        cursor: pointer;
        animation: float 2s ease-in-out infinite;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        top: ${Math.random() * (window.innerHeight - 200) + 100}px;
        left: ${Math.random() * (window.innerWidth - 100) + 50}px;
        user-select: none;
      `;
      
      // Add ripple effect on click
      bubble.addEventListener('click', (e) => {
        if (gameEnded) return;
        e.stopPropagation();
        
        // Create pop animation
        bubble.style.animation = 'pop 0.3s ease-out forwards';
        bubble.style.transform = 'scale(0)';
        bubble.style.opacity = '0';
        
        setTimeout(() => bubble.remove(), 300);
        
        poppedCount++;
        const counter = document.getElementById('bubbleCounter');
        if (counter) {
          counter.textContent = `Bubbles: ${totalBubbles - poppedCount}/${totalBubbles}`;
        }
        
        if (poppedCount === totalBubbles) {
          endBubbleTest(true, '✓ All bubbles popped! Test passed!', testOverlay, style);
        }
      });
      
      bubbles.push(bubble);
      testOverlay.appendChild(bubble);
    }
    
    // Add animations
    const style = document.createElement('style');
    style.textContent = `
      @keyframes float {
        0%, 100% { transform: translateY(0px) scale(1); opacity: 0.9; }
        50% { transform: translateY(-15px) scale(1.1); opacity: 1; }
      }
      @keyframes pop {
        0% { transform: scale(1); }
        50% { transform: scale(1.3); }
        100% { transform: scale(0); opacity: 0; }
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(testOverlay);
    
    document.body.appendChild(testOverlay);
  };

  const exitDisplayTest = () => {
    setIsFullscreenTest(false);
    document.exitFullscreen?.();
  };

  // Test execution functions
  const runTouchTest = () => {
    setIsTestingActive(true);
    setTouchPoints([]);
    setTimeout(() => {
      setIsTestingActive(false);
      setAutoTestResult(touchPoints.length >= 4);
    }, 10000);
  };

  const runAudioTest = async () => {
    setIsTestingActive(true);
    
    const testOverlay = document.createElement('div');
    testOverlay.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
      z-index: 10000; background: linear-gradient(135deg, #1e293b, #334155);
      display: flex; flex-direction: column; align-items: center; justify-content: center;
    `;
    
    testOverlay.innerHTML = `
      <div style="text-align: center; color: white; padding: 30px; border-radius: 15px; background: rgba(0,0,0,0.8); max-width: 90%; margin: 0 auto;">
        <h3 style="margin: 0 0 20px 0; font-size: 24px;">Audio Test</h3>
        <p style="margin: 10px 0; font-size: 16px; opacity: 0.9;">Testing speakers and microphone for 7 seconds...</p>
        <div id="audioStatus" style="font-size: 18px; font-weight: bold; margin: 20px 0; color: #60a5fa;">Preparing audio test...</div>
        <div id="countdown" style="font-size: 24px; font-weight: bold; margin: 20px 0; color: #10b981;">7</div>
        <div id="frequencyDisplay" style="font-size: 14px; margin: 10px 0; opacity: 0.7;"></div>
        <div style="margin: 20px 0;">
          <div style="width: 200px; height: 10px; background: rgba(255,255,255,0.2); border-radius: 5px; margin: 0 auto; overflow: hidden;">
            <div id="volumeBar" style="height: 100%; background: linear-gradient(90deg, #10b981, #3b82f6); width: 0%; transition: width 0.1s;"></div>
          </div>
        </div>
        <div id="testPhase" style="font-size: 16px; margin: 15px 0; color: #fbbf24;">Phase 1: Speaker Test</div>
      </div>
      <div style="position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%); display: flex; gap: 20px;">
        <button id="passTestBtn" style="
          padding: 15px 30px; background: #10b981; color: white; border: none; 
          border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; 
          margin: 0 15px; box-shadow: 0 4px 8px rgba(16, 185, 129, 0.3);
        ">✓ PASS</button>
        <button id="failTestBtn" style="
          padding: 15px 30px; background: #ef4444; color: white; border: none; 
          border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; 
          margin: 0 15px; box-shadow: 0 4px 8px rgba(239, 68, 68, 0.3);
        ">✗ FAIL</button>
      </div>
    `;
    
    document.body.appendChild(testOverlay);
    
    try {
      // Get microphone access first
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Create analyzer for microphone input
      const analyser = audioContext.createAnalyser();
      const microphone = audioContext.createMediaStreamSource(stream);
      microphone.connect(analyser);
      
      analyser.fftSize = 2048;
      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      
      const statusEl = document.getElementById('audioStatus');
      const countdownEl = document.getElementById('countdown');
      const freqEl = document.getElementById('frequencyDisplay');
      const volumeBar = document.getElementById('volumeBar');
      const phaseEl = document.getElementById('testPhase');
      const passBtn = document.getElementById('passTestBtn');
      const failBtn = document.getElementById('failTestBtn');
      
      let testPhase = 'speaker'; // 'speaker', 'microphone', 'complete'
      let countdown = 7;
      let speakerDetected = false;
      let microphoneDetected = false;
      let oscillators: OscillatorNode[] = [];
      
      // Monitor microphone continuously
      const monitorAudio = () => {
        analyser.getByteFrequencyData(dataArray);
        
        // Calculate volume level
        const volume = dataArray.reduce((sum, value) => sum + value, 0) / bufferLength;
        const volumePercent = Math.min(100, (volume / 128) * 100);
        
        if (volumeBar) {
          volumeBar.style.width = `${volumePercent}%`;
        }
        
        // Check for frequency ranges (200-800Hz for our test tones)
        let targetFreqDetected = false;
        for (let i = 50; i < 200; i++) { // Check frequency range where our tones are
          if (dataArray[i] > 80) {
            targetFreqDetected = true;
            break;
          }
        }
        
        if (freqEl) {
          freqEl.textContent = `Microphone Level: ${Math.round(volumePercent)}% | Audio Detected: ${targetFreqDetected ? 'YES' : 'NO'}`;
        }
        
        // Detect microphone activity during speaker test (feedback loop indicates working speakers)
        if (testPhase === 'speaker' && (volumePercent > 25 || targetFreqDetected)) {
          speakerDetected = true;
        }
        
        // Detect microphone activity during microphone test
        if (testPhase === 'microphone' && volumePercent > 30) {
          microphoneDetected = true;
        }
        
        if (testPhase !== 'complete') {
          requestAnimationFrame(monitorAudio);
        }
      };
      
      // Create multiple audible test tones
      const createTestTones = () => {
        const frequencies = [440, 523, 659, 784]; // Musical notes: A4, C5, E5, G5
        
        frequencies.forEach((freq, index) => {
          const oscillator = audioContext.createOscillator();
          const gainNode = audioContext.createGain();
          
          oscillator.connect(gainNode);
          gainNode.connect(audioContext.destination);
          
          oscillator.frequency.setValueAtTime(freq, audioContext.currentTime);
          oscillator.type = 'sine';
          gainNode.gain.setValueAtTime(0.4, audioContext.currentTime);
          
          oscillators.push(oscillator);
          
          // Play each tone in sequence
          oscillator.start(audioContext.currentTime + index * 0.3);
          oscillator.stop(audioContext.currentTime + (index + 1) * 0.3);
        });
      };
      
      const completeTest = (passed: boolean) => {
        // Stop all oscillators
        oscillators.forEach(osc => {
          try {
            osc.stop();
          } catch (e) {
            // Oscillator might already be stopped
          }
        });
        stream.getTracks().forEach(track => track.stop());
        audioContext.close();
        document.body.removeChild(testOverlay);
        setAutoTestResult(passed);
        setIsTestingActive(false);
        
        toast({
          title: passed ? "Audio Test Passed!" : "Audio Test Failed",
          description: passed ? "Speaker and microphone test completed" : "Audio test failed",
        });
      };
      
      // Countdown and test sequence
      const runTestSequence = () => {
        const countdownInterval = setInterval(() => {
          countdown--;
          if (countdownEl) countdownEl.textContent = countdown.toString();
          
          if (countdown <= 0) {
            clearInterval(countdownInterval);
            
            if (testPhase === 'speaker') {
              // Switch to microphone test
              testPhase = 'microphone';
              countdown = 4; // 4 seconds for microphone test
              if (phaseEl) phaseEl.textContent = 'Phase 2: Microphone Test - Please speak or make noise';
              if (statusEl) statusEl.textContent = 'Say something into the microphone...';
              if (countdownEl) countdownEl.textContent = countdown.toString();
              runTestSequence(); // Continue with microphone test
            } else {
              // Test complete
              testPhase = 'complete';
              const autoSuccess = speakerDetected || microphoneDetected;
              
              if (statusEl) {
                statusEl.textContent = autoSuccess ? 
                  '✓ Audio detected! Use buttons to confirm' : 
                  'No audio detected - please use manual buttons';
              }
              if (phaseEl) phaseEl.textContent = `Speaker: ${speakerDetected ? '✓' : '✗'} | Microphone: ${microphoneDetected ? '✓' : '✗'}`;
              if (countdownEl) countdownEl.textContent = '✓';
            }
          }
        }, 1000);
      };
      
      // Start monitoring immediately
      monitorAudio();
      
      // Start the test sequence after 1 second
      setTimeout(() => {
        if (statusEl) statusEl.textContent = 'Playing musical tones - listen carefully...';
        createTestTones();
        runTestSequence();
        
        // Create new tones every 1.5 seconds during speaker test
        const toneInterval = setInterval(() => {
          if (testPhase === 'speaker') {
            createTestTones();
          } else {
            clearInterval(toneInterval);
          }
        }, 1500);
      }, 1000);
      
      // Manual confirmation buttons
      if (passBtn) {
        passBtn.addEventListener('click', () => completeTest(true));
      }
      
      if (failBtn) {
        failBtn.addEventListener('click', () => completeTest(false));
      }
      
    } catch (error) {
      console.error('Audio test failed:', error);
      document.body.removeChild(testOverlay);
      setAutoTestResult(false);
      setIsTestingActive(false);
      
      toast({
        title: "Audio Test Error",
        description: "Could not access microphone or speakers",
      });
    }
  };

  const runCameraTest = async () => {
    setIsTestingActive(true);
    
    const testOverlay = document.createElement('div');
    testOverlay.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
      z-index: 10000; background: #000000;
      display: flex; flex-direction: column;
    `;
    
    testOverlay.innerHTML = `
      <div style="color: white; padding: 20px; text-align: center; background: rgba(0,0,0,0.9);">
        <h3 style="margin: 0 0 20px 0; font-size: 24px;">Camera Test</h3>
        <div id="cameraControls" style="display: flex; justify-content: center; gap: 10px; margin-bottom: 20px;">
          <button id="frontCameraBtn" style="
            padding: 10px 20px; background: #3b82f6; color: white; border: none; 
            border-radius: 8px; font-size: 14px; cursor: pointer;
          ">Front Camera</button>
          <button id="backCameraBtn" style="
            padding: 10px 20px; background: #6b7280; color: white; border: none; 
            border-radius: 8px; font-size: 14px; cursor: pointer;
          ">Back Camera</button>
          <button id="zoomTestBtn" style="
            padding: 10px 20px; background: #6b7280; color: white; border: none; 
            border-radius: 8px; font-size: 14px; cursor: pointer;
          ">Zoom Test</button>
        </div>
        <div id="cameraStatus" style="font-size: 16px; margin: 10px 0; color: #60a5fa;">Click a button to test cameras</div>
        <div id="zoomControls" style="display: none; margin: 15px 0;">
          <label style="color: white; margin-right: 10px;">Zoom:</label>
          <input type="range" id="zoomSlider" min="1" max="10" value="1" step="0.1" style="width: 200px; margin-right: 10px;">
          <span id="zoomLevel" style="color: white;">1x</span>
        </div>
      </div>
      <div style="flex: 1; position: relative; display: flex; align-items: center; justify-content: center;">
        <video id="cameraVideo" style="width: 100%; height: 100%; object-fit: cover; display: none;" autoplay playsinline></video>
        <div id="cameraPlaceholder" style="color: white; font-size: 18px; text-align: center;">
          Select a camera mode to begin testing
        </div>
      </div>
      <div style="
        position: fixed; bottom: 0; left: 0; right: 0; 
        padding: 20px; text-align: center; background: rgba(0,0,0,0.95);
        border-top: 2px solid #3b82f6; z-index: 10001;
      ">
        <div style="margin-bottom: 10px; color: #ffffff; font-weight: bold;">
          Test the camera and mark result:
        </div>
        <button id="passTestBtn" style="
          padding: 15px 30px; background: #10b981; color: white; border: none; 
          border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; 
          margin: 0 15px; box-shadow: 0 4px 8px rgba(16, 185, 129, 0.3);
        ">✓ PASS</button>
        <button id="failTestBtn" style="
          padding: 15px 30px; background: #ef4444; color: white; border: none; 
          border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; 
          margin: 0 15px; box-shadow: 0 4px 8px rgba(239, 68, 68, 0.3);
        ">✗ FAIL</button>
      </div>
    `;
    
    document.body.appendChild(testOverlay);
    
    const video = document.getElementById('cameraVideo') as HTMLVideoElement;
    const placeholder = document.getElementById('cameraPlaceholder') as HTMLElement;
    const statusEl = document.getElementById('cameraStatus') as HTMLElement;
    const frontBtn = document.getElementById('frontCameraBtn') as HTMLButtonElement;
    const backBtn = document.getElementById('backCameraBtn') as HTMLButtonElement;
    const zoomBtn = document.getElementById('zoomTestBtn') as HTMLButtonElement;
    const zoomControls = document.getElementById('zoomControls') as HTMLElement;
    const zoomSlider = document.getElementById('zoomSlider') as HTMLInputElement;
    const zoomLevel = document.getElementById('zoomLevel') as HTMLElement;
    const passBtn = document.getElementById('passTestBtn') as HTMLButtonElement;
    const failBtn = document.getElementById('failTestBtn') as HTMLButtonElement;
    
    let currentStream: MediaStream | null = null;
    let currentTrack: MediaStreamTrack | null = null;
    let currentCameraStep = 0; // 0: front, 1: back, 2: zoom
    const cameraSteps = ['front', 'back', 'zoom'];
    const cameraButtons = [frontBtn, backBtn, zoomBtn];
    
    const stopCurrentStream = () => {
      if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
        currentStream = null;
        currentTrack = null;
      }
      video.style.display = 'none';
      placeholder.style.display = 'block';
    };
    
    const setActiveButton = (activeBtn: HTMLButtonElement) => {
      [frontBtn, backBtn, zoomBtn].forEach(btn => {
        btn.style.background = '#6b7280';
      });
      activeBtn.style.background = '#3b82f6';
    };
    
    const startCamera = async (facingMode: 'user' | 'environment') => {
      try {
        stopCurrentStream();
        statusEl.textContent = 'Starting camera...';
        statusEl.style.color = '#60a5fa';
        
        // Try multiple constraint configurations for better compatibility
        const constraints = [
          {
            video: {
              facingMode: facingMode,
              width: { ideal: 1920, min: 640 },
              height: { ideal: 1080, min: 480 }
            }
          },
          {
            video: {
              facingMode: facingMode,
              width: { ideal: 1280 },
              height: { ideal: 720 }
            }
          },
          {
            video: {
              facingMode: facingMode
            }
          }
        ];
        
        let stream: MediaStream | null = null;
        let lastError: Error | null = null;
        
        // Try constraints in order of preference
        for (const constraint of constraints) {
          try {
            stream = await navigator.mediaDevices.getUserMedia(constraint);
            break;
          } catch (error) {
            lastError = error as Error;
            console.warn('Failed constraint attempt:', constraint, error);
          }
        }
        
        if (!stream) {
          throw lastError || new Error('Failed to start camera');
        }
        
        currentStream = stream;
        currentTrack = currentStream.getVideoTracks()[0];
        
        if (!currentTrack) {
          throw new Error('No video track available');
        }
        
        video.srcObject = currentStream;
        video.style.display = 'block';
        video.style.transform = 'none'; // Reset any previous zoom transforms
        placeholder.style.display = 'none';
        
        // Wait for video to be ready
        await new Promise((resolve, reject) => {
          const timeout = setTimeout(() => reject(new Error('Video load timeout')), 10000);
          video.onloadedmetadata = () => {
            clearTimeout(timeout);
            resolve(true);
          };
          video.onerror = () => {
            clearTimeout(timeout);
            reject(new Error('Video load error'));
          };
        });
        
        statusEl.textContent = `${facingMode === 'user' ? 'Front' : 'Back'} camera active - Check image quality and clarity`;
        statusEl.style.color = '#10b981';
        
      } catch (error) {
        console.error('Camera error:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        statusEl.textContent = `Failed to access ${facingMode === 'user' ? 'front' : 'back'} camera: ${errorMessage}`;
        statusEl.style.color = '#ef4444';
        
        // Show placeholder if camera fails
        video.style.display = 'none';
        placeholder.style.display = 'block';
        placeholder.textContent = `Camera unavailable: ${errorMessage}`;
      }
    };
    
    const updateZoom = async () => {
      if (!currentTrack) {
        statusEl.textContent = 'No camera active for zoom test';
        statusEl.style.color = '#ef4444';
        return;
      }

      try {
        const zoomValue = parseFloat(zoomSlider.value);
        zoomLevel.textContent = `${zoomValue.toFixed(1)}x`;
        
        // Check if track supports zoom
        const capabilities = currentTrack.getCapabilities() as any;
        
        if (capabilities.zoom) {
          // Apply zoom constraint using any type for non-standard properties
          await (currentTrack as any).applyConstraints({
            advanced: [{ zoom: zoomValue }]
          });
          statusEl.textContent = `Zoom applied: ${zoomValue.toFixed(1)}x - Check if image zooms in/out`;
          statusEl.style.color = '#10b981';
        } else {
          // Try alternative zoom methods
          try {
            // Try using transform on the video element as fallback
            video.style.transform = `scale(${zoomValue})`;
            video.style.transformOrigin = 'center center';
            statusEl.textContent = `Digital zoom applied: ${zoomValue.toFixed(1)}x - Check zoom effect`;
            statusEl.style.color = '#10b981';
          } catch (fallbackError) {
            statusEl.textContent = `Zoom not supported - Slider shows ${zoomValue.toFixed(1)}x but no zoom effect`;
            statusEl.style.color = '#f59e0b';
          }
        }
      } catch (error) {
        console.error('Zoom error:', error);
        // Fallback to digital zoom
        try {
          const zoomValue = parseFloat(zoomSlider.value);
          video.style.transform = `scale(${zoomValue})`;
          video.style.transformOrigin = 'center center';
          statusEl.textContent = `Digital zoom fallback: ${zoomValue.toFixed(1)}x`;
          statusEl.style.color = '#f59e0b';
        } catch (fallbackError) {
          statusEl.textContent = `Zoom failed: Cannot apply zoom on this device`;
          statusEl.style.color = '#ef4444';
        }
      }
    };
    
    // Event listeners
    frontBtn.addEventListener('click', () => {
      setActiveButton(frontBtn);
      startCamera('user');
      zoomControls.style.display = 'none';
    });
    
    backBtn.addEventListener('click', () => {
      setActiveButton(backBtn);
      startCamera('environment');
      zoomControls.style.display = 'none';
    });
    
    zoomBtn.addEventListener('click', async () => {
      setActiveButton(zoomBtn);
      await startCamera('environment');
      zoomControls.style.display = 'block';
      statusEl.textContent = 'Use zoom slider to test zoom functionality';
    });
    
    zoomSlider.addEventListener('input', updateZoom);
    
    passBtn.addEventListener('click', () => {
      // Progress to next camera step
      currentCameraStep++;
      
      if (currentCameraStep >= cameraSteps.length) {
        // All camera tests completed successfully
        stopCurrentStream();
        document.body.removeChild(testOverlay);
        setAutoTestResult(true);
        setIsTestingActive(false);
        toast({
          title: "Camera Test Passed!",
          description: "All camera functions working properly",
        });
      } else {
        // Move to next camera test
        const nextButton = cameraButtons[currentCameraStep];
        nextButton.click();
        toast({
          title: `${cameraSteps[currentCameraStep - 1]} camera passed`,
          description: `Now testing ${cameraSteps[currentCameraStep]} camera`,
        });
      }
    });
    
    failBtn.addEventListener('click', () => {
      stopCurrentStream();
      document.body.removeChild(testOverlay);
      setAutoTestResult(false);
      setIsTestingActive(false);
      toast({
        title: "Camera Test Failed",
        description: `${cameraSteps[currentCameraStep]} camera issues detected`,
      });
    });
    
    // Auto-start with front camera
    setTimeout(() => {
      frontBtn.click();
    }, 500);
  };

  const runFlashTest = async () => {
    setIsTestingActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      
      const track = stream.getVideoTracks()[0];
      const capabilities = track.getCapabilities() as any;
      
      if (capabilities.torch) {
        await track.applyConstraints({
          advanced: [{ torch: true } as any]
        });
        
        setTimeout(async () => {
          await track.applyConstraints({
            advanced: [{ torch: false } as any]
          });
          stream.getTracks().forEach(track => track.stop());
          setAutoTestResult(true);
          setIsTestingActive(false);
        }, 2000);
      } else {
        stream.getTracks().forEach(track => track.stop());
        setAutoTestResult(false);
        setIsTestingActive(false);
      }
    } catch (error) {
      console.error('Flash test failed:', error);
      setAutoTestResult(false);
      setIsTestingActive(false);
    }
  };

  const runVibrationTest = () => {
    setIsTestingActive(true);
    
    const testOverlay = document.createElement('div');
    testOverlay.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
      z-index: 10000; background: linear-gradient(135deg, #1e293b, #334155);
      display: flex; flex-direction: column; align-items: center; justify-content: center;
    `;
    
    testOverlay.innerHTML = `
      <div style="text-align: center; color: white; padding: 30px; border-radius: 15px; background: rgba(0,0,0,0.8); max-width: 90%; margin: 0 auto;">
        <h3 style="margin: 0 0 20px 0; font-size: 24px;">📳 Vibration Test</h3>
        <p style="margin: 10px 0; font-size: 16px; opacity: 0.9;">Test device vibration motor</p>
        <div id="vibrationStatus" style="font-size: 18px; font-weight: bold; margin: 20px 0; color: #60a5fa;">Ready to test vibration...</div>
        
        <button id="startVibrateBtn" style="
          padding: 15px 30px; background: #3b82f6; color: white; border: none; 
          border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; 
          margin: 15px; box-shadow: 0 4px 8px rgba(59, 130, 246, 0.3);
          display: block; margin: 20px auto;
        ">🚀 Start Automatic Test</button>
        
        <div id="manualButtons" style="display: none; margin-top: 20px;">
          <p style="margin: 15px 0; font-size: 16px; color: #fbbf24;">Did you feel the vibration patterns?</p>
          <div style="display: flex; gap: 20px; justify-content: center; margin-top: 20px;">
            <button id="passTestBtn" style="
              padding: 15px 30px; background: #10b981; color: white; border: none; 
              border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; 
              box-shadow: 0 4px 8px rgba(16, 185, 129, 0.3);
            ">✓ Working / Pass</button>
            <button id="failTestBtn" style="
              padding: 15px 30px; background: #ef4444; color: white; border: none; 
              border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; 
              box-shadow: 0 4px 8px rgba(239, 68, 68, 0.3);
            ">✗ Not Working / Fail</button>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(testOverlay);
    
    const statusEl = document.getElementById('vibrationStatus');
    const startBtn = document.getElementById('startVibrateBtn');
    const manualButtons = document.getElementById('manualButtons');
    const passBtn = document.getElementById('passTestBtn');
    const failBtn = document.getElementById('failTestBtn');
    
    // iOS-compatible vibration function
    const triggerVibration = () => {
      try {
        const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
        
        if (isIOS) {
          // For iOS, try Haptic Feedback API first, then fallback to vibrate
          try {
            // @ts-ignore - Haptic feedback for iOS
            if (window.DeviceMotionEvent && typeof DeviceMotionEvent.requestPermission === 'function') {
              // iOS 13+ haptic feedback
              if (navigator.vibrate) {
                navigator.vibrate(200);
                return true;
              }
            }
            // Fallback for older iOS
            if (navigator.vibrate) {
              navigator.vibrate(200);
              return true;
            }
          } catch (e) {
            console.log('iOS haptic failed, trying basic vibration');
            if (navigator.vibrate) {
              navigator.vibrate(200);
              return true;
            }
          }
        } else {
          // Android-style pattern
          if (navigator.vibrate) {
            navigator.vibrate([200, 100, 200, 100, 400]);
            return true;
          }
        }
        
        // Final fallback - try any vibration API available
        if (navigator.vibrate) {
          navigator.vibrate(200);
          return true;
        }
        
        return false;
      } catch (error) {
        console.error('Vibration error:', error);
        return false;
      }
    };
    
    const completeTest = (passed) => {
      document.body.removeChild(testOverlay);
      setAutoTestResult(passed);
      setIsTestingActive(false);
    };
    
    // Start vibration test
    if (startBtn) {
      startBtn.addEventListener('click', () => {
        if (statusEl) statusEl.textContent = 'Testing vibration patterns...';
        startBtn.style.display = 'none';
        
        // For iOS, we need to trigger vibration immediately on user interaction
        const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
        
        if (isIOS) {
          // Immediate vibration test on iOS
          const vibrationWorked = triggerVibration();
          
          if (vibrationWorked) {
            if (statusEl) statusEl.textContent = 'Did you feel that vibration? Testing more patterns...';
            
            // Continue with pattern testing
            let countdown = 3;
            const countdownInterval = setInterval(() => {
              if (statusEl) statusEl.textContent = `Testing vibration patterns... ${countdown}`;
              
              // Trigger vibration every second
              triggerVibration();
              
              countdown--;
              if (countdown <= 0) {
                clearInterval(countdownInterval);
                if (statusEl) statusEl.textContent = 'Vibration test complete! Did you feel the vibrations?';
                if (manualButtons) manualButtons.style.display = 'block';
              }
            }, 1000);
          } else {
            if (statusEl) statusEl.textContent = 'Vibration may not be supported. Please test manually.';
            if (manualButtons) manualButtons.style.display = 'block';
          }
        } else {
          // Android behavior
          const vibrationWorked = triggerVibration();
          
          if (vibrationWorked) {
            let countdown = 3;
            const countdownInterval = setInterval(() => {
              if (statusEl) statusEl.textContent = `Feel the vibration patterns... ${countdown}`;
              triggerVibration();
              
              countdown--;
              if (countdown <= 0) {
                clearInterval(countdownInterval);
                if (statusEl) statusEl.textContent = 'Vibration test complete!';
                if (manualButtons) manualButtons.style.display = 'block';
              }
            }, 1000);
          } else {
            if (statusEl) statusEl.textContent = 'Vibration not supported on this device';
            if (manualButtons) manualButtons.style.display = 'block';
          }
        }
      });
    }
    
    // Manual confirmation buttons
    if (passBtn) {
      passBtn.addEventListener('click', () => completeTest(true));
    }
    
    if (failBtn) {
      failBtn.addEventListener('click', () => completeTest(false));
    }
  };

  const runSensorsTest = () => {
    const testOverlay = document.createElement('div');
    testOverlay.style.cssText = `
      position: fixed; top: 0; left: 0; right: 0; bottom: 0; 
      background: linear-gradient(45deg, #1a1a2e, #16213e); 
      z-index: 10000; display: flex; align-items: center; justify-content: center;
      color: white; font-family: Arial, sans-serif; overflow-y: auto;
    `;
    
    let timeLeft = 5;
    let testEnded = false;
    let sensorData = {
      compass: { value: 0, variation: 0, readings: [] as number[] },
      gyro: { x: 0, y: 0, z: 0, variation: 0, readings: [] as number[] },
      accelerometer: { x: 0, y: 0, z: 0, variation: 0, readings: [] as number[] }
    };
    
    testOverlay.innerHTML = `
      <div style="text-align: center; max-width: 500px; padding: 20px;">
        <h2 style="margin-bottom: 20px; color: #4ade80;">🔧 Sensor Test</h2>
        <p style="margin-bottom: 20px; font-size: 16px;">Testing device sensors for 5 seconds...</p>
        <div id="timer" style="font-size: 24px; font-weight: bold; margin-bottom: 20px; color: #ffff00;">Time: 5s</div>
        
        <!-- Compass -->
        <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 10px; margin-bottom: 15px;">
          <h3 style="margin: 0 0 10px 0; color: #60a5fa;">📍 Compass</h3>
          <div style="position: relative; width: 120px; height: 120px; margin: 0 auto; border: 2px solid #60a5fa; border-radius: 50%;">
            <div id="compass-needle" style="position: absolute; top: 50%; left: 50%; width: 4px; height: 50px; background: #ef4444; transform-origin: bottom center; transform: translate(-50%, -100%) rotate(0deg); transition: transform 0.3s;"></div>
            <div style="position: absolute; top: 5px; left: 50%; transform: translateX(-50%); color: #60a5fa; font-weight: bold;">N</div>
          </div>
          <p id="compass-reading" style="margin: 10px 0 0 0;">Heading: 0°</p>
        </div>
        
        <!-- Gyroscope -->
        <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 10px; margin-bottom: 15px;">
          <h3 style="margin: 0 0 10px 0; color: #f59e0b;">🌀 Gyroscope</h3>
          <div style="display: flex; justify-content: space-around;">
            <div style="text-align: center;">
              <div style="font-size: 12px; color: #f59e0b;">X</div>
              <div id="gyro-x" style="font-size: 18px; font-weight: bold;">0.0</div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 12px; color: #f59e0b;">Y</div>
              <div id="gyro-y" style="font-size: 18px; font-weight: bold;">0.0</div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 12px; color: #f59e0b;">Z</div>
              <div id="gyro-z" style="font-size: 18px; font-weight: bold;">0.0</div>
            </div>
          </div>
        </div>
        
        <!-- Accelerometer -->
        <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 10px; margin-bottom: 20px;">
          <h3 style="margin: 0 0 10px 0; color: #10b981;">📱 Accelerometer</h3>
          <div style="display: flex; justify-content: space-around;">
            <div style="text-align: center;">
              <div style="font-size: 12px; color: #10b981;">X</div>
              <div id="accel-x" style="font-size: 18px; font-weight: bold;">0.0</div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 12px; color: #10b981;">Y</div>
              <div id="accel-y" style="font-size: 18px; font-weight: bold;">0.0</div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 12px; color: #10b981;">Z</div>
              <div id="accel-z" style="font-size: 18px; font-weight: bold;">0.0</div>
            </div>
          </div>
        </div>
        
        <div id="test-status" style="margin: 20px 0; font-size: 16px; font-weight: bold;">Move your device to test sensors...</div>
      </div>
    `;
    
    document.body.appendChild(testOverlay);
    
    // Start timer countdown
    const timerInterval = setInterval(() => {
      if (testEnded) {
        clearInterval(timerInterval);
        return;
      }
      
      timeLeft--;
      const timerEl = document.getElementById('timer');
      if (timerEl) {
        timerEl.textContent = `Time: ${timeLeft}s`;
        if (timeLeft <= 3) {
          timerEl.style.color = '#ff0000';
        }
      }
      
      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        endSensorTest();
      }
    }, 1000);
    
    // Device orientation event for compass
    const handleOrientation = (event: DeviceOrientationEvent) => {
      if (testEnded) return;
      
      const heading = (event as any).webkitCompassHeading || event.alpha || 0;
      sensorData.compass.readings.push(heading);
      sensorData.compass.value = heading;
      
      // Update compass needle
      const needle = document.getElementById('compass-needle');
      const reading = document.getElementById('compass-reading');
      if (needle) needle.style.transform = `translate(-50%, -100%) rotate(${heading}deg)`;
      if (reading) reading.textContent = `Heading: ${Math.round(heading)}°`;
    };
    
    // Device motion event for gyroscope and accelerometer
    const handleMotion = (event: DeviceMotionEvent) => {
      if (testEnded) return;
      
      // Gyroscope data
      if (event.rotationRate) {
        const { alpha, beta, gamma } = event.rotationRate;
        sensorData.gyro.x = alpha || 0;
        sensorData.gyro.y = beta || 0;
        sensorData.gyro.z = gamma || 0;
        sensorData.gyro.readings.push(Math.abs(alpha || 0) + Math.abs(beta || 0) + Math.abs(gamma || 0));
        
        const gyroXEl = document.getElementById('gyro-x');
        const gyroYEl = document.getElementById('gyro-y');
        const gyroZEl = document.getElementById('gyro-z');
        if (gyroXEl) gyroXEl.textContent = (alpha || 0).toFixed(1);
        if (gyroYEl) gyroYEl.textContent = (beta || 0).toFixed(1);
        if (gyroZEl) gyroZEl.textContent = (gamma || 0).toFixed(1);
      }
      
      // Accelerometer data
      if (event.acceleration) {
        const { x, y, z } = event.acceleration;
        sensorData.accelerometer.x = x || 0;
        sensorData.accelerometer.y = y || 0;
        sensorData.accelerometer.z = z || 0;
        sensorData.accelerometer.readings.push(Math.abs(x || 0) + Math.abs(y || 0) + Math.abs(z || 0));
        
        const accelXEl = document.getElementById('accel-x');
        const accelYEl = document.getElementById('accel-y');
        const accelZEl = document.getElementById('accel-z');
        if (accelXEl) accelXEl.textContent = (x || 0).toFixed(1);
        if (accelYEl) accelYEl.textContent = (y || 0).toFixed(1);
        if (accelZEl) accelZEl.textContent = (z || 0).toFixed(1);
      }
    };
    
    const endSensorTest = () => {
      if (testEnded) return;
      testEnded = true;
      
      // Calculate variations
      const compassVariation = sensorData.compass.readings.length > 0 ? 
        Math.max(...sensorData.compass.readings) - Math.min(...sensorData.compass.readings) : 0;
      const gyroVariation = sensorData.gyro.readings.length > 0 ? 
        Math.max(...sensorData.gyro.readings) - Math.min(...sensorData.gyro.readings) : 0;
      const accelVariation = sensorData.accelerometer.readings.length > 0 ? 
        Math.max(...sensorData.accelerometer.readings) - Math.min(...sensorData.accelerometer.readings) : 0;
      
      // Test passes if there's significant variation in at least 2 sensors
      const testPassed = (
        (compassVariation > 10 && gyroVariation > 0.5) ||
        (compassVariation > 10 && accelVariation > 1) ||
        (gyroVariation > 0.5 && accelVariation > 1)
      );
      
      const statusEl = document.getElementById('test-status');
      if (statusEl) {
        statusEl.innerHTML = `
          <div style="color: ${testPassed ? '#22c55e' : '#ef4444'}; font-size: 18px; margin-bottom: 10px;">
            ${testPassed ? '✓ SENSORS WORKING' : '✗ SENSORS NOT DETECTED'}
          </div>
          <div style="font-size: 14px; color: #ccc;">
            Compass: ${compassVariation.toFixed(1)}° | Gyro: ${gyroVariation.toFixed(1)} | Accel: ${accelVariation.toFixed(1)}
          </div>
        `;
      }
      
      // Remove event listeners
      window.removeEventListener('deviceorientation', handleOrientation);
      window.removeEventListener('devicemotion', handleMotion);
      
      // Auto close and continue
      setTimeout(() => {
        document.body.removeChild(testOverlay);
        setTestResults(prev => ({ ...prev, sensorsTest: testPassed }));
        setCurrentTest(prev => prev + 1);
        toast({
          title: testPassed ? "Sensor Test Passed!" : "Sensor Test Failed!",
          description: testPassed ? "All sensors working correctly" : "Sensors not responding properly",
        });
      }, 2000);
    };
    
    // Request permission and start listening (for iOS)
    if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
      (DeviceOrientationEvent as any).requestPermission()
        .then((response: string) => {
          if (response === 'granted') {
            window.addEventListener('deviceorientation', handleOrientation);
            window.addEventListener('devicemotion', handleMotion);
          }
        });
    } else {
      // For other browsers
      window.addEventListener('deviceorientation', handleOrientation);
      window.addEventListener('devicemotion', handleMotion);
    }
  };

  const runConnectivityTest = () => {
    setIsTestingActive(true);
    const online = navigator.onLine;
    setAutoTestResult(online);
    setTimeout(() => setIsTestingActive(false), 1000);
  };

  const runBatteryTest = async () => {
    setIsTestingActive(true);
    
    const testOverlay = document.createElement('div');
    testOverlay.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
      z-index: 10000; background: #000;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
    `;
    
    testOverlay.innerHTML = `
      <div style="text-align: center; color: white; padding: 30px; border-radius: 15px; background: rgba(0,0,0,0.8); max-width: 90%; margin: 0 auto;">
        <h3 style="margin: 0 0 20px 0; font-size: 24px;">Battery Stress Test</h3>
        <p style="margin: 10px 0; font-size: 16px; opacity: 0.9;">Running intensive graphics, audio and flash for 15 seconds...</p>
        <div id="batteryStatus" style="font-size: 18px; font-weight: bold; margin: 20px 0; color: #60a5fa;">Initializing...</div>
        <div id="batteryLevels" style="font-size: 14px; margin: 10px 0; opacity: 0.7;"></div>
        <div id="countdown" style="font-size: 20px; margin: 15px 0; color: #10b981;"></div>
        <canvas id="intensiveGraphics" width="300" height="200" style="border: 2px solid #fff; margin: 20px 0;"></canvas>
      </div>
    `;
    
    document.body.appendChild(testOverlay);
    
    try {
      // Get initial battery level
      const battery = await (navigator as any).getBattery?.();
      const initialLevel = battery ? battery.level * 100 : null;
      
      const statusEl = document.getElementById('batteryStatus');
      const levelsEl = document.getElementById('batteryLevels');
      const countdownEl = document.getElementById('countdown');
      const canvas = document.getElementById('intensiveGraphics') as HTMLCanvasElement;
      const ctx = canvas.getContext('2d');
      
      if (statusEl) statusEl.textContent = 'Recording initial battery level...';
      if (levelsEl && initialLevel !== null) {
        levelsEl.textContent = `Initial battery: ${initialLevel.toFixed(1)}%`;
      }
      
      // Create audio context for intensive sound
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator1 = audioContext.createOscillator();
      const oscillator2 = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator1.connect(gainNode);
      oscillator2.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator1.frequency.setValueAtTime(440, audioContext.currentTime);
      oscillator2.frequency.setValueAtTime(880, audioContext.currentTime);
      oscillator1.type = 'sawtooth';
      oscillator2.type = 'square';
      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
      
      // Start intensive graphics animation
      let animationFrame = 0;
      const startTime = Date.now();
      const testDuration = 15000; // 15 seconds
      
      const intensiveAnimation = () => {
        if (!ctx) return;
        
        animationFrame++;
        const elapsed = Date.now() - startTime;
        const remaining = Math.max(0, testDuration - elapsed);
        
        if (countdownEl) {
          countdownEl.textContent = `${Math.ceil(remaining / 1000)}s remaining`;
        }
        
        // Clear canvas
        ctx.fillStyle = `hsl(${animationFrame % 360}, 70%, 50%)`;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw intensive animations
        for (let i = 0; i < 50; i++) {
          ctx.fillStyle = `hsl(${(animationFrame + i * 7) % 360}, 80%, 60%)`;
          ctx.fillRect(
            Math.sin(animationFrame * 0.1 + i) * 100 + canvas.width / 2,
            Math.cos(animationFrame * 0.05 + i) * 50 + canvas.height / 2,
            20, 20
          );
        }
        
        // Draw rotating patterns
        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(animationFrame * 0.1);
        for (let i = 0; i < 12; i++) {
          ctx.fillStyle = `hsl(${(animationFrame + i * 30) % 360}, 100%, 50%)`;
          ctx.fillRect(-5, -50, 10, 100);
          ctx.rotate(Math.PI / 6);
        }
        ctx.restore();
        
        if (remaining > 0) {
          requestAnimationFrame(intensiveAnimation);
        }
      };
      
      // Start flash (rapid screen brightness changes)
      const flashInterval = setInterval(() => {
        testOverlay.style.background = testOverlay.style.background === '#000' ? '#fff' : '#000';
      }, 100);
      
      // Vibration pattern
      if (navigator.vibrate) {
        const vibratePattern = () => {
          navigator.vibrate([200, 100, 200, 100, 200]);
          setTimeout(vibratePattern, 1000);
        };
        vibratePattern();
      }
      
      // Start everything
      if (statusEl) statusEl.textContent = 'Running intensive stress test...';
      oscillator1.start();
      oscillator2.start();
      intensiveAnimation();
      
      // Complete test after 15 seconds
      setTimeout(async () => {
        // Stop all intensive operations
        clearInterval(flashInterval);
        oscillator1.stop();
        oscillator2.stop();
        audioContext.close();
        
        // Get final battery level
        const finalLevel = battery ? battery.level * 100 : null;
        
        let testPassed = true;
        let resultMessage = '';
        
        if (initialLevel !== null && finalLevel !== null) {
          const batteryDrop = initialLevel - finalLevel;
          if (levelsEl) {
            levelsEl.textContent = `Initial: ${initialLevel.toFixed(1)}% → Final: ${finalLevel.toFixed(1)}% (${batteryDrop > 0 ? '-' : '+'}${Math.abs(batteryDrop).toFixed(1)}%)`;
          }
          
          // If battery dropped more than 1%, test fails
          if (batteryDrop > 1.0) {
            testPassed = false;
            resultMessage = `Battery dropped ${batteryDrop.toFixed(1)}% - Possible battery issue`;
            if (statusEl) statusEl.style.color = '#ef4444';
          } else {
            resultMessage = `Battery stable (${batteryDrop.toFixed(1)}% change) - Battery OK`;
            if (statusEl) statusEl.style.color = '#10b981';
          }
          
          setDeviceInfo(prev => ({ ...prev, batteryHealth: `${finalLevel.toFixed(1)}%` }));
        } else {
          resultMessage = 'Battery API not available - Test completed';
          testPassed = true; // Default to pass if API unavailable
        }
        
        if (statusEl) statusEl.textContent = resultMessage;
        if (countdownEl) countdownEl.textContent = 'Test Complete!';
        
        setTimeout(() => {
          document.body.removeChild(testOverlay);
          setAutoTestResult(testPassed);
          setIsTestingActive(false);
          
          toast({
            title: testPassed ? "Battery Test Passed!" : "Battery Test Failed",
            description: resultMessage,
          });
        }, 3000);
        
      }, testDuration);
      
    } catch (error) {
      console.error('Battery test error:', error);
      document.body.removeChild(testOverlay);
      setAutoTestResult(false);
      setIsTestingActive(false);
      
      toast({
        title: "Battery Test Error",
        description: "Could not access battery API",
        variant: "destructive"
      });
    }
  };

  const runPerformanceTest = () => {
    setIsTestingActive(true);
    const start = performance.now();
    
    // Simple performance test
    let result = 0;
    for (let i = 0; i < 1000000; i++) {
      result += Math.sqrt(i);
    }
    
    const duration = performance.now() - start;
    setAutoTestResult(duration < 100); // Pass if under 100ms
    setTimeout(() => setIsTestingActive(false), 2000);
  };

  const startAutoTest = () => {
    setAutoTestResult(null);
    
    switch (currentTestData.key) {
      case 'audioTest':
        runAudioTest();
        break;
      case 'cameraTest':
        runCameraTest();
        break;
      case 'flashTest':
        runFlashTest();
        break;
      case 'vibrationTest':
        runVibrationTest();
        break;
      case 'sensorsTest':
        runSensorsTest();
        break;
      case 'connectivityTest':
        runConnectivityTest();
        break;
      case 'batteryTest':
        runBatteryTest();
        break;
      case 'performanceTest':
        runPerformanceTest();
        break;
    }
  };

  const handleTouch = (e: React.TouchEvent) => {
    // Touch handling removed since touchTest was removed
  };

  useEffect(() => {
    if (!sessionId) {
      navigate('/');
      return;
    }
  }, [sessionId, navigate]);

  useEffect(() => {
    if (autoTestResult !== null) {
      setTimeout(() => {
        handleTestResult(autoTestResult);
        setAutoTestResult(null);
      }, 1000);
    }
  }, [autoTestResult]);

  const handleTestResult = (passed: boolean) => {
    const updatedResults = {
      ...testResults,
      [currentTestData.key]: passed
    };
    setTestResults(updatedResults);

    if (currentTest < tests.length - 1) {
      setCurrentTest(currentTest + 1);
    } else {
      completeAllTests(updatedResults);
    }
  };

  const completeAllTests = async (finalResults: typeof testResults) => {
    setCurrentStep('results');
    
    const passedTests = Object.values(finalResults).filter(Boolean).length;
    const overallScore = Math.round((passedTests / tests.length) * 100);

    const testData = {
      ...finalResults,
      overallScore,
      sessionId,
      timestamp: new Date().toISOString(),
      deviceModel: deviceInfo.selectedModel,
      storage: deviceInfo.storage,
      batteryHealth: deviceInfo.batteryHealth
    };

    try {
      const { data, error } = await supabase.functions.invoke('receive-test-results', {
        body: {
          action: 'store',
          testResults: testData
        }
      });

      if (error) throw error;
      
      if (data?.resultCode) {
        setResultCode(data.resultCode);
        toast({
          title: "Tests Complete!",
          description: `Your result code is: ${data.resultCode}`,
        });
      }
    } catch (error) {
      console.error('Error storing test results:', error);
      toast({
        title: "Error",
        description: "Failed to save test results. Please try again.",
        variant: "destructive"
      });
    }
  };

  if (!sessionId) {
    return null;
  }

  // Fullscreen display test
  if (isFullscreenTest) {
    return (
      <div 
        className={`fixed inset-0 z-50 ${
          displayTestColor === 'black' ? 'bg-black' :
          displayTestColor === 'white' ? 'bg-white' :
          displayTestColor === 'red' ? 'bg-red-500' :
          displayTestColor === 'green' ? 'bg-green-500' :
          displayTestColor === 'blue' ? 'bg-blue-500' : 'bg-black'
        }`}
        onClick={exitDisplayTest}
      >
        <div className="absolute top-4 left-4 right-4 text-center">
          <p className={`text-lg font-medium ${
            displayTestColor === 'white' || displayTestColor === 'green' || displayTestColor === 'blue' 
              ? 'text-black' : 'text-white'
          }`}>
            Displaying {displayTestColor} - Tap anywhere to exit
          </p>
        </div>
      </div>
    );
  }

  // Step navigation component
  const StepIndicator = () => (
    <div className="w-full max-w-sm mx-auto mb-4 sm:mb-8">
      <div className="flex items-center justify-between bg-white rounded-lg p-2 sm:p-4 shadow-sm overflow-x-auto">
        {[
          { key: 'upload', label: 'Upload', icon: Upload },
          { key: 'verification', label: 'Verify', icon: CheckSquare },
          { key: 'testing', label: 'Test', icon: Settings },
          { key: 'results', label: 'Results', icon: CheckCircle }
        ].map((step, index) => (
          <div key={step.key} className="flex items-center flex-shrink-0">
            <div className={`flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-full ${
              currentStep === step.key 
                ? 'bg-blue-500 text-white' 
                : index < ['upload', 'verification', 'testing', 'results'].indexOf(currentStep)
                ? 'bg-green-500 text-white'
                : 'bg-gray-200 text-gray-500'
            }`}>
              <step.icon className="w-3 h-3 sm:w-5 sm:h-5" />
            </div>
            <span className={`ml-1 sm:ml-2 text-xs sm:text-sm font-medium ${
              currentStep === step.key ? 'text-blue-600' : 'text-gray-500'
            }`}>
              {step.label}
            </span>
            {index < 3 && (
              <div className={`w-4 sm:w-8 h-0.5 mx-1 sm:mx-4 ${
                index < ['upload', 'verification', 'testing', 'results'].indexOf(currentStep)
                  ? 'bg-green-500'
                  : 'bg-gray-200'
              }`} />
            )}
          </div>
        ))}
      </div>
    </div>
  );

  // Upload step
  if (currentStep === 'upload') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-2 sm:p-4">
        <div className="container mx-auto px-2 py-4 max-w-sm">
          <div className="text-center mb-6">
            <h1 className="text-2xl sm:text-4xl font-bold text-white mb-2">Device Diagnostic Center</h1>
            <p className="text-sm sm:text-base text-blue-200">Comprehensive mobile device testing suite</p>
          </div>

          <StepIndicator />

          <div className="w-full">
            <Card className="p-4 sm:p-8">
              <div className="text-center mb-4 sm:mb-6">
                <Upload className="w-12 h-12 sm:w-16 sm:h-16 text-blue-500 mx-auto mb-3 sm:mb-4" />
                <h2 className="text-xl sm:text-2xl font-bold mb-2">Upload Device Settings Screenshot</h2>
                <p className="text-sm sm:text-base text-gray-600">OCR-powered device recognition will identify your phone model and storage</p>
              </div>

              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 sm:p-8 text-center mb-4">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                <label htmlFor="image-upload" className="cursor-pointer">
                  <Upload className="w-8 h-8 sm:w-12 sm:h-12 text-gray-400 mx-auto mb-3 sm:mb-4" />
                  <p className="text-sm sm:text-base text-gray-600 mb-2">Click to upload image</p>
                  <p className="text-xs sm:text-sm text-gray-500">Supports JPG, PNG, WebP files</p>
                </label>
              </div>

              {isProcessingOCR && (
                <div className="text-center p-3 sm:p-4 bg-blue-50 rounded-lg">
                  <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-blue-500 mx-auto mb-2 animate-pulse" />
                  <p className="text-sm sm:text-base text-blue-800 font-medium">Processing image...</p>
                </div>
              )}

              {uploadedImage && (
                <div className="mt-4">
                  <img 
                    src={URL.createObjectURL(uploadedImage)} 
                    alt="Device screenshot"
                    className="w-full h-32 sm:h-48 object-cover rounded border"
                  />
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Verification step
  if (currentStep === 'verification') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">Device Diagnostic Center</h1>
            <p className="text-blue-200">Verify your device information</p>
          </div>

          <StepIndicator />

          <div className="max-w-md mx-auto">
            <Card className="p-6">
              <div className="text-center mb-6">
                <CheckSquare className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Verify Device Information</h2>
                <p className="text-gray-600">Confirm the detected information is correct</p>
              </div>

              <div className="space-y-4">
                {extractedModels.length > 0 && (
                  <div>
                    <Label className="block text-sm font-medium mb-2">
                      Select Your Device Model
                    </Label>
                    <Select onValueChange={handleModelSelection}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Choose your device model" />
                      </SelectTrigger>
                      <SelectContent>
                        {extractedModels.map((model, index) => (
                          <SelectItem key={index} value={model}>
                            {model}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div>
                  <Label htmlFor="manualModel" className="block text-sm font-medium mb-2">
                    Or Enter Model Manually
                  </Label>
                  <Input
                    id="manualModel"
                    value={deviceInfo.selectedModel}
                    onChange={(e) => setDeviceInfo(prev => ({ ...prev, selectedModel: e.target.value }))}
                    placeholder="e.g., Samsung Galaxy S23, iPhone 14 Pro"
                    className="w-full"
                  />
                </div>

                {deviceInfo.storage && (
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="text-sm text-green-800">
                      <strong>Detected Storage:</strong> {deviceInfo.storage}
                    </p>
                  </div>
                )}

                <Button
                  onClick={startTesting}
                  disabled={!deviceInfo.selectedModel}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                >
                  Start Comprehensive Testing
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Results step
  if (currentStep === 'results') {
    const passedTests = Object.values(testResults).filter(Boolean).length;
    const overallScore = Math.round((passedTests / tests.length) * 100);

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">Device Diagnostic Center</h1>
            <p className="text-blue-200">Testing complete - View your results</p>
          </div>

          <StepIndicator />

          <div className="max-w-2xl mx-auto">
            <Card className="p-6 text-center">
              <div className="mb-6">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Diagnostic Complete!</h2>
                <p className="text-gray-600">Device: {deviceInfo.selectedModel}</p>
                <div className="text-3xl font-bold text-blue-600 mt-2">
                  Overall Score: {overallScore}%
                </div>
              </div>

              {resultCode && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                  <h3 className="font-semibold text-blue-800 mb-2">Your Result Code:</h3>
                  <div className="text-3xl font-mono font-bold text-blue-600 bg-white rounded px-4 py-2 border">
                    {resultCode}
                  </div>
                  <p className="text-sm text-blue-600 mt-2">
                    Enter this code on the main system to transfer results
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3 mb-6">
                {tests.map((test, index) => {
                  const passed = testResults[test.key];
                  return (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div className="flex items-center">
                        <test.icon className="w-5 h-5 text-gray-600 mr-2" />
                        <span className="text-sm text-gray-700">{test.name}</span>
                      </div>
                      {passed ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 mb-2">Device Summary</h4>
                <div className="text-sm text-gray-600 space-y-1">
                  <p><strong>Model:</strong> {deviceInfo.selectedModel}</p>
                  {deviceInfo.storage && <p><strong>Storage:</strong> {deviceInfo.storage}</p>}
                  {deviceInfo.batteryHealth && <p><strong>Battery:</strong> {deviceInfo.batteryHealth}</p>}
                  <p><strong>Tests Passed:</strong> {passedTests}/{tests.length}</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Testing step - Display test handling
  if (currentStep === 'testing' && currentTestData.key === 'displayTest') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-2 sm:p-4">
        <div className="container mx-auto px-2 py-4 max-w-sm">
          <StepIndicator />

          <div className="w-full">
            <Card className="p-4 sm:p-6">
              <div className="text-center mb-4 sm:mb-6">
                <Monitor className="w-12 h-12 sm:w-16 sm:h-16 text-blue-500 mx-auto mb-3 sm:mb-4" />
                <h3 className="text-lg sm:text-xl font-semibold mb-2">Display Test</h3>
                <p className="text-sm sm:text-base text-gray-600">Test your screen for dead pixels and color accuracy</p>
                <div className="text-xs sm:text-sm text-gray-500 mt-2">
                  Test {currentTest + 1} of {tests.length}
                </div>
              </div>

              <div className="space-y-3 mb-4 sm:mb-6">
                <p className="text-xs sm:text-sm text-gray-600 text-center">
                  Tap each color to test fullscreen display. Look for dead pixels, discoloration, or brightness issues.
                </p>
                <div className="grid grid-cols-2 gap-2 sm:gap-3">
                  {['black', 'white', 'red', 'green', 'blue'].slice(0, 4).map((color) => (
                    <Button
                      key={color}
                      onClick={() => startDisplayTest(color)}
                      className={`h-10 sm:h-12 text-xs sm:text-sm font-medium ${
                        color === 'black' ? 'bg-black hover:bg-gray-800 text-white' :
                        color === 'white' ? 'bg-white text-black hover:bg-gray-100 border' :
                        color === 'red' ? 'bg-red-500 hover:bg-red-600 text-white' :
                        'bg-green-500 hover:bg-green-600 text-white'
                      }`}
                    >
                      Test {color.charAt(0).toUpperCase() + color.slice(1)}
                    </Button>
                  ))}
                </div>
                <Button
                  onClick={() => startDisplayTest('blue')}
                  className="w-full h-10 sm:h-12 bg-blue-500 hover:bg-blue-600 text-white text-xs sm:text-sm font-medium"
                >
                  Test Blue
                </Button>
              </div>

              <div className="space-y-2 sm:space-y-3">
                <Button
                  onClick={() => handleTestResult(true)}
                  className="w-full h-10 sm:h-12 bg-green-500 hover:bg-green-600 text-white flex items-center justify-center gap-2 text-xs sm:text-sm"
                >
                  <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                  Display Works Perfectly
                </Button>
                <Button
                  onClick={() => handleTestResult(false)}
                  variant="outline"
                  className="w-full h-10 sm:h-12 border-red-300 text-red-600 hover:bg-red-50 flex items-center justify-center gap-2 text-xs sm:text-sm"
                >
                  <XCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                  Found Issues
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Testing step - Other tests
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-2 sm:p-4">
      <div className="container mx-auto px-2 py-4 max-w-sm">
        <StepIndicator />

        <div className="w-full">
          <Card className="p-4 sm:p-6">
            <div className="text-center mb-4 sm:mb-6">
              <currentTestData.icon className="w-12 h-12 sm:w-16 sm:h-16 text-blue-500 mx-auto mb-3 sm:mb-4" />
              <h3 className="text-lg sm:text-xl font-semibold mb-2">{currentTestData.name}</h3>
              <p className="text-sm sm:text-base text-gray-600 mb-2">{currentTestData.description}</p>
              <p className="text-xs sm:text-sm text-blue-600 font-medium">{currentTestData.instruction}</p>
              <div className="text-xs sm:text-sm text-gray-500 mt-2">
                Test {currentTest + 1} of {tests.length}
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentTest + 1) / tests.length) * 100}%` }}
                />
              </div>
            </div>

            <div className="text-center mb-6 sm:mb-8" onTouchStart={handleTouch}>
              {/* Camera preview */}
              {videoStream && (
                <video 
                  ref={(video) => {
                    if (video && videoStream) {
                      video.srcObject = videoStream;
                      video.play();
                    }
                  }}
                  className="w-full h-32 sm:h-48 object-cover rounded-lg mt-4 bg-black"
                  muted
                  autoPlay
                  playsInline
                />
              )}
              
              {/* Test status */}
              {isTestingActive && (
                <div className="mt-4 p-2 sm:p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-blue-800 text-xs sm:text-sm font-medium">
                    🔄 Test in progress...
                  </p>
                </div>
              )}
              
              {autoTestResult !== null && (
                <div className={`mt-4 p-2 sm:p-3 rounded-lg ${autoTestResult ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                  <p className={`text-xs sm:text-sm font-medium ${autoTestResult ? 'text-green-800' : 'text-red-800'}`}>
                    {autoTestResult ? '✅ Test Passed!' : '❌ Test Failed!'}
                  </p>
                </div>
              )}
            </div>

            <div className="space-y-2 sm:space-y-3">
              {currentTestData.autoTest && (
                <Button
                  onClick={startAutoTest}
                  disabled={isTestingActive}
                  className="w-full h-10 sm:h-12 bg-blue-500 hover:bg-blue-600 text-white flex items-center justify-center gap-2 text-xs sm:text-sm"
                >
                  <Smartphone className="w-4 h-4 sm:w-5 sm:h-5" />
                  {isTestingActive ? 'Testing...' : 'Start Automatic Test'}
                </Button>
              )}
              
              <Button
                onClick={() => handleTestResult(true)}
                className="w-full h-10 sm:h-12 bg-green-500 hover:bg-green-600 text-white flex items-center justify-center gap-2 text-xs sm:text-sm"
              >
                <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                Working / Pass
              </Button>
              <Button
                onClick={() => handleTestResult(false)}
                variant="outline"
                className="w-full h-10 sm:h-12 border-red-300 text-red-600 hover:bg-red-50 flex items-center justify-center gap-2 text-xs sm:text-sm"
              >
                <XCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                Not Working / Fail
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default MobileTesting;