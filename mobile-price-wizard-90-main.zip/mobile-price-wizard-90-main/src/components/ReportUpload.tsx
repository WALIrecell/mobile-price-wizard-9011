
import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { FileImage, CheckCircle, Save, Camera, Brain, Loader2 } from 'lucide-react';
import { PhoneData } from '../pages/Index';
import { useToast } from '@/hooks/use-toast';
import TestResultsRetrieval from './TestResultsRetrieval';
import { supabase } from '@/integrations/supabase/client';

interface ReportUploadProps {
  phoneData: PhoneData;
  onUpload: (file: File, testResults?: any, aiAnalysis?: any) => void;
}

const ReportUpload: React.FC<ReportUploadProps> = ({ phoneData, onUpload }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [cameraMode, setCameraMode] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [testResults, setTestResults] = useState<any>(phoneData.testResults || null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const MAX_FILE_SIZE = 2000 * 1024; // 2000KB in bytes

  // Cleanup camera stream on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);


  const handleTestResultsRetrieved = (results: any) => {
    setTestResults(results);
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    
    try {
      // Simply proceed to next step without saving to Google Sheets
      // Data will be saved only after offer decision is made
      console.log('Report uploaded, proceeding to device images capture');
      
      onUpload(selectedFile, testResults, aiAnalysis);
      setIsComplete(true);
      
      toast({
        title: "Upload successful!",
        description: "Your diagnostic report has been uploaded.",
      });
    } catch (error) {
      console.error('Error uploading file:', error);
      toast({
        title: "Upload failed",
        description: "There was an error uploading your file. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      setStream(mediaStream);
      setCameraMode(true);
      
      // Small delay to ensure video element is ready
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current?.play().catch(e => {
              console.error('Error playing video:', e);
            });
          };
        }
      }, 100);
    } catch (error) {
      console.error('Error starting camera:', error);
      toast({
        title: "Camera Error",
        description: "Unable to access camera. Please check permissions and try again.",
        variant: "destructive"
      });
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setCameraMode(false);
  };

  const analyzeImageWithAI = async (imageDataUrl: string) => {
    setIsAnalyzing(true);
    try {
      const { data, error } = await supabase.functions.invoke('analyze-phone-condition', {
        body: { imageData: imageDataUrl }
      });

      if (error) {
        console.error('AI analysis error:', error);
        toast({
          title: "Analysis Error",
          description: "Unable to analyze image. Continuing with manual grading.",
          variant: "destructive"
        });
        return null;
      }

      console.log('AI Analysis Result:', data);
      return data;
    } catch (error) {
      console.error('Error calling AI analysis:', error);
      toast({
        title: "Analysis Error", 
        description: "Unable to analyze image. Continuing with manual grading.",
        variant: "destructive"
      });
      return null;
    } finally {
      setIsAnalyzing(false);
    }
  };

  const capturePhoto = async () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0);
        
        canvas.toBlob(async (blob) => {
          if (blob) {
            // Check file size
            if (blob.size > MAX_FILE_SIZE) {
              toast({
                title: "Image too large",
                description: `Please try again. Image size is ${formatFileSize(blob.size)}, max is 2000KB.`,
                variant: "destructive"
              });
              return;
            }
            
            const file = new File([blob], `diagnostic-report-${Date.now()}.jpg`, {
              type: 'image/jpeg'
            });
            setSelectedFile(file);
            stopCamera();
            
            // Convert to base64 for AI analysis
            const imageDataUrl = canvas.toDataURL('image/jpeg', 0.8);
            
            toast({
              title: "Photo captured!",
              description: "Analyzing device condition with AI...",
            });

            // Analyze with AI
            const analysis = await analyzeImageWithAI(imageDataUrl);
            if (analysis) {
              setAiAnalysis(analysis);
              toast({
                title: "AI Analysis Complete!",
                description: `Detected grade: ${analysis.grade} (${analysis.condition})`,
              });
            }
          }
        }, 'image/jpeg', 0.8);
      }
    }
  };

  if (isComplete) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center bg-gradient-to-r from-green-50 to-blue-50">
          <CardTitle className="flex items-center justify-center gap-2 text-2xl text-green-700">
            <CheckCircle className="text-green-600" />
            Report Uploaded!
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 text-center">
          <div className="py-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={40} className="text-green-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Report Ready!</h3>
            <p className="text-gray-600 mb-4">
              Your diagnostic report has been uploaded successfully. Next, capture device images.
            </p>
            
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <h4 className="font-semibold mb-2">Evaluation Summary:</h4>
              <div className="text-left space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Store ID:</span>
                  <span className="font-medium">{phoneData.storeId || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Device:</span>
                  <span className="font-medium">{phoneData.make} {phoneData.model}</span>
                </div>
                <div className="flex justify-between">
                  <span>Storage:</span>
                  <span className="font-medium">{phoneData.storage}</span>
                </div>
                {phoneData.batteryHealth && (
                  <div className="flex justify-between">
                    <span>Battery Health:</span>
                    <span className="font-medium">{phoneData.batteryHealth}%</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Grade:</span>
                  <span className="font-medium">{phoneData.grade}</span>
                </div>
                <div className="flex justify-between">
                  <span>Condition:</span>
                  <span className="font-medium">{phoneData.condition}</span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Value:</span>
                  <span className="font-medium text-green-600">د.إ {phoneData.price}</span>
                </div>
                <div className="flex justify-between">
                  <span>Contact:</span>
                  <span className="font-medium">{phoneData.mobileNumber}</span>
                </div>
                {testResults && testResults.overallScore !== undefined && (
                  <div className="flex justify-between">
                    <span>Device Health:</span>
                    <span className="font-medium text-blue-600">{testResults.overallScore}%</span>
                  </div>
                )}
              </div>
            </div>

            <p className="text-sm text-gray-500">
              Ready to proceed to device image capture
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <Camera className="text-blue-600" />
          Capture Diagnostic Report
        </CardTitle>
        <p className="text-gray-600">
          Use device camera to capture the diagnostic report image (max 2000KB)
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Camera Option Only */}
        {!cameraMode && !selectedFile && (
          <div className="flex justify-center">
            <div 
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-green-400 transition-colors cursor-pointer max-w-sm w-full"
              onClick={startCamera}
            >
              <div className="space-y-4">
                <Camera size={48} className="mx-auto text-gray-400" />
                <div>
                  <p className="text-xl font-medium text-gray-700">
                    Take Picture
                  </p>
                  <p className="text-sm text-gray-500">
                    Use device camera to capture diagnostic report
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Camera View */}
        {cameraMode && !selectedFile && (
          <div className="space-y-4">
            <div className="relative">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full rounded-lg"
                style={{ maxHeight: '400px' }}
              />
              <canvas
                ref={canvasRef}
                className="hidden"
              />
            </div>
            <div className="flex gap-4 justify-center">
              <Button
                onClick={capturePhoto}
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-2"
              >
                <Camera size={20} className="mr-2" />
                Capture Photo
              </Button>
              <Button
                onClick={stopCamera}
                variant="outline"
                className="px-6 py-2"
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        {/* Selected File Info */}
        {selectedFile && (
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center gap-3">
              <FileImage size={20} className="text-blue-600" />
              <div className="flex-1">
                <p className="font-medium text-blue-900">{selectedFile.name}</p>
                <p className="text-sm text-blue-600">{formatFileSize(selectedFile.size)}</p>
              </div>
              {isAnalyzing ? (
                <Loader2 size={20} className="text-blue-600 animate-spin" />
              ) : (
                <CheckCircle size={20} className="text-green-600" />
              )}
            </div>
            
            {/* AI Analysis Results */}
            {aiAnalysis && (
              <div className="mt-4 p-3 bg-white rounded-lg border">
                <div className="flex items-center gap-2 mb-2">
                  <Brain size={16} className="text-purple-600" />
                  <span className="font-medium text-purple-900">AI Analysis</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div><span className="text-gray-600">Detected Grade:</span> <span className="font-medium text-purple-600">{aiAnalysis.grade}</span></div>
                  <div><span className="text-gray-600">Scratches:</span> <span className="font-medium">{aiAnalysis.scratchCount}</span></div>
                  <div><span className="text-gray-600">Screen Damage:</span> <span className="font-medium">{aiAnalysis.hasScreenDamage ? 'Yes' : 'No'}</span></div>
                  <div><span className="text-gray-600">Confidence:</span> <span className="font-medium">{aiAnalysis.confidence}%</span></div>
                </div>
                <p className="text-xs text-gray-500 mt-2">{aiAnalysis.condition}</p>
              </div>
            )}

            {isAnalyzing && (
              <div className="mt-4 p-3 bg-white rounded-lg border">
                <div className="flex items-center gap-2">
                  <Loader2 size={16} className="text-blue-600 animate-spin" />
                  <span className="text-blue-900">Analyzing device condition...</span>
                </div>
              </div>
            )}
            
            <Button
              onClick={() => {
                setSelectedFile(null);
                setCameraMode(false);
                setAiAnalysis(null);
              }}
              variant="outline"
              size="sm"
              className="mt-3"
            >
              Choose Different Image
            </Button>
          </div>
        )}

        {/* Test Results Retrieval */}
        <TestResultsRetrieval 
          onTestResultsRetrieved={handleTestResultsRetrieved}
          existingResults={testResults}
          savedResultCode={phoneData.resultCode}
        />

        {/* Data Summary */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-semibold mb-3 flex items-center gap-2">
            <Save size={16} />
            Evaluation Summary
          </h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div><span className="text-gray-600">Store ID:</span> {phoneData.storeId || 'N/A'}</div>
            <div><span className="text-gray-600">Device:</span> {phoneData.make} {phoneData.model}</div>
            <div><span className="text-gray-600">Storage:</span> {phoneData.storage}</div>
            {phoneData.batteryHealth && (
              <div><span className="text-gray-600">Battery Health:</span> {phoneData.batteryHealth}%</div>
            )}
            <div><span className="text-gray-600">IMEI:</span> {phoneData.imeiNumber || 'Will be added in next step'}</div>
            <div><span className="text-gray-600">Grade:</span> {phoneData.grade}</div>
            <div><span className="text-gray-600">Price:</span> د.إ {phoneData.price}</div>
            <div><span className="text-gray-600">Condition:</span> {phoneData.condition}</div>
            <div><span className="text-gray-600">Contact:</span> {phoneData.mobileNumber}</div>
            {testResults && testResults.overallScore !== undefined && (
              <div><span className="text-gray-600">Device Health:</span> {testResults.overallScore}%</div>
            )}
          </div>
        </div>

        <Button 
          onClick={handleUpload}
          disabled={!selectedFile || isUploading}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
        >
          {isUploading ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Uploading...
            </div>
          ) : (
            'Continue to Device Images'
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default ReportUpload;
