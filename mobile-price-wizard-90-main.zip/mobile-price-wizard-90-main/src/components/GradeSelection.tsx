import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Award, DollarSign, AlertTriangle } from 'lucide-react';
import { PhoneData } from '../pages/Index';

interface PriceData {
  make: string;
  model: string;
  memorySize: string;
  gradeA: number;
  gradeB: number;
  gradeC: number;
  broken: number;
}

interface GradeSelectionProps {
  phoneData: PhoneData;
  priceData: PriceData[];
  onGradeSelect: (grade: string, price: number) => void;
}

interface Grade {
  letter: string;
  name: string;
  description: string;
  color: string;
  bgColor: string;
  priceKey: keyof Pick<PriceData, 'gradeA' | 'gradeB' | 'gradeC' | 'broken'>;
}

const GradeSelection: React.FC<GradeSelectionProps> = ({ phoneData, priceData, onGradeSelect }) => {
  const [selectedGrade, setSelectedGrade] = useState<string>('');

  const grades: Grade[] = [
    {
      letter: 'A',
      name: 'Excellent',
      description: 'Like new condition, minimal wear, all functions perfect',
      color: 'text-green-700',
      bgColor: 'bg-green-50 border-green-200 hover:bg-green-100',
      priceKey: 'gradeA'
    },
    {
      letter: 'B',
      name: 'Good',
      description: 'Light wear, minor scratches, all functions working',
      color: 'text-blue-700',
      bgColor: 'bg-blue-50 border-blue-200 hover:bg-blue-100',
      priceKey: 'gradeB'
    },
    {
      letter: 'C',
      name: 'Fair',
      description: 'Moderate wear, visible scratches, functions properly',
      color: 'text-yellow-700',
      bgColor: 'bg-yellow-50 border-yellow-200 hover:bg-yellow-100',
      priceKey: 'gradeC'
    },
    {
      letter: 'Broken',
      name: 'Broken',
      description: 'Device has significant damage or functional issues',
      color: 'text-red-700',
      bgColor: 'bg-red-50 border-red-200 hover:bg-red-100',
      priceKey: 'broken'
    }
  ];

  const findPriceInfo = () => {
    return priceData.find(p => 
      p.make.toLowerCase() === phoneData.make.toLowerCase() &&
      p.model.toLowerCase() === phoneData.model.toLowerCase() &&
      p.memorySize === phoneData.storage
    );
  };

  const getPrice = (grade: Grade) => {
    const priceInfo = findPriceInfo();
    if (!priceInfo) return 0;
    return Math.round(priceInfo[grade.priceKey]);
  };

  const handleGradeSelect = (grade: Grade) => {
    const price = getPrice(grade);
    setSelectedGrade(grade.letter);
    onGradeSelect(grade.letter, price);
  };

  const priceInfo = findPriceInfo();

  if (!priceInfo) {
    return (
      <Card className="max-w-4xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 text-red-600">
            <AlertTriangle className="text-red-600" />
            Price Data Not Available
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-gray-600 mb-4">
            No pricing data found for {phoneData.make} {phoneData.model} ({phoneData.storage}).
            Please check your uploaded price data or contact support.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <Award className="text-blue-600" />
          Condition Assessment
        </CardTitle>
        <p className="text-gray-600">
          Select the grade that best matches your {phoneData.make} {phoneData.model}
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-4 mb-8">
          {grades.map((grade) => {
            const price = getPrice(grade);
            
            return (
              <Card 
                key={grade.letter}
                className={`cursor-pointer transition-all duration-200 border-2 ${grade.bgColor} ${
                  selectedGrade === grade.letter ? 'ring-2 ring-blue-500 scale-105' : ''
                }`}
                onClick={() => handleGradeSelect(grade)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Badge 
                        className={`text-2xl font-bold px-3 py-1 ${grade.color} bg-white`}
                      >
                        {grade.letter}
                      </Badge>
                      <div>
                        <h3 className={`text-xl font-semibold ${grade.color}`}>
                          {grade.name}
                        </h3>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1">
                        <span className="text-2xl font-bold text-green-600">
                          د.إ {price}
                        </span>
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {grade.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-semibold mb-2">Device Information:</h4>
          <div className="grid md:grid-cols-3 gap-4 text-sm">
            {phoneData.batteryHealth && (
              <div>
                <span className="text-gray-600">Battery Health:</span>
                <span className="ml-2 font-medium">{phoneData.batteryHealth}%</span>
              </div>
            )}
            <div>
              <span className="text-gray-600">Physical Condition:</span>
              <span className="ml-2 font-medium capitalize">{phoneData.condition}</span>
            </div>
            <div>
              <span className="text-gray-600">Memory Size:</span>
              <span className="ml-2 font-medium">{phoneData.storage}</span>
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Prices are direct values from uploaded price data.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default GradeSelection;
