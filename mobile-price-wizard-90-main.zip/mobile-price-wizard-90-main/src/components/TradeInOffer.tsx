
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, CheckCircle, X, HandHeart, AlertTriangle } from 'lucide-react';
import { PhoneData } from '../pages/Index';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface PriceData {
  make: string;
  model: string;
  memorySize: string;
  gradeA: number;
  gradeB: number;
  gradeC: number;
  broken: number;
}

interface TradeInOfferProps {
  phoneData: PhoneData;
  priceData: PriceData[];
  onOfferDecision: (accepted: boolean, finalPrice?: number) => void;
}

const TradeInOffer: React.FC<TradeInOfferProps> = ({ 
  phoneData, 
  priceData, 
  onOfferDecision 
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const findPriceInfo = () => {
    return priceData.find(p => 
      p.make.toLowerCase() === phoneData.make.toLowerCase() &&
      p.model.toLowerCase() === phoneData.model.toLowerCase() &&
      p.memorySize === phoneData.storage
    );
  };

  const calculateOfferPrice = () => {
    const priceInfo = findPriceInfo();
    if (!priceInfo || !phoneData.grade) return 0;

    // Direct price lookup based on grade
    let price = 0;
    switch (phoneData.grade.toLowerCase()) {
      case 'a':
        price = priceInfo.gradeA;
        break;
      case 'b':
        price = priceInfo.gradeB;
        break;
      case 'c':
        price = priceInfo.gradeC;
        break;
      case 'broken':
        price = priceInfo.broken;
        break;
      default:
        price = 0;
    }
    
    return Math.round(price);
  };

  const handleOfferDecision = async (accepted: boolean) => {
    setIsProcessing(true);
    const finalPrice = accepted ? calculateOfferPrice() : undefined;

    try {
      const dataToSave = {
        make: phoneData.make,
        model: phoneData.model,
        storage: phoneData.storage,
        batteryHealth: phoneData.batteryHealth,
        condition: phoneData.condition,
        grade: phoneData.grade,
        price: finalPrice || 0,
        mobileNumber: phoneData.mobileNumber,
        reportFileName: phoneData.reportImage?.name || '',
        offerStatus: accepted ? 'ACCEPTED' : 'REJECTED'
      };

      console.log('Saving trade-in decision to Google Sheets:', dataToSave);
      
      const { data, error } = await supabase.functions.invoke('save-to-sheets', {
        body: dataToSave,
      });

      if (error) {
        throw error;
      }

      if (data?.success) {
        toast({
          title: accepted ? "Offer Accepted!" : "Offer Declined",
          description: accepted 
            ? `Your trade-in offer of د.إ ${finalPrice} has been accepted and saved.`
            : "Your decision has been recorded. Thank you for considering our service.",
        });
        
        onOfferDecision(accepted, finalPrice);
      } else {
        throw new Error(data?.error || 'Failed to save decision');
      }
    } catch (error) {
      console.error('Error saving trade-in decision:', error);
      toast({
        title: "Error saving decision",
        description: "There was an error processing your decision. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const priceInfo = findPriceInfo();
  const offerPrice = calculateOfferPrice();

  if (!priceInfo) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 text-red-600">
            <AlertTriangle />
            Price Data Not Available
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-gray-600 mb-4">
            We don't have pricing data for your {phoneData.make} {phoneData.model} ({phoneData.storage}).
            Please contact us directly for a custom quote.
          </p>
          <Button 
            onClick={() => onOfferDecision(false)}
            variant="outline"
          >
            Continue Without Offer
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center bg-gradient-to-r from-green-50 to-blue-50">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <HandHeart className="text-green-600" />
          Trade-In Offer
        </CardTitle>
        <p className="text-gray-600">
          Based on your device evaluation
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Offer Price Display */}
        <div className="text-center py-8 bg-gradient-to-r from-green-100 to-blue-100 rounded-xl">
          <div className="flex items-center justify-center gap-2 mb-2">
            <DollarSign size={32} className="text-green-600" />
            <span className="text-5xl font-bold text-green-600">
              د.إ {offerPrice}
            </span>
          </div>
          <p className="text-lg text-gray-600">Trade-In Offer</p>
          <Badge className="mt-2 bg-green-100 text-green-800">
            Final Calculated Price
          </Badge>
        </div>

        {/* Device Summary */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-semibold mb-3">Offer Details:</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div><span className="text-gray-600">Device:</span> {phoneData.make} {phoneData.model}</div>
            <div><span className="text-gray-600">Storage:</span> {phoneData.storage}</div>
            <div><span className="text-gray-600">Grade:</span> {phoneData.grade}</div>
            <div><span className="text-gray-600">Condition:</span> {phoneData.condition} (Data Only)</div>
            {phoneData.batteryHealth && (
              <div><span className="text-gray-600">Battery:</span> {phoneData.batteryHealth}% (Data Only)</div>
            )}
            <div><span className="text-gray-600">Base Price:</span> د.إ {priceInfo.gradeA}</div>
          </div>
        </div>

        {/* Price Calculation Breakdown */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-semibold mb-2">Price Calculation:</h4>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span>Device:</span>
              <span>{phoneData.make} {phoneData.model} ({phoneData.storage})</span>
            </div>
            <div className="flex justify-between">
              <span>Selected Grade:</span>
              <span>{phoneData.grade}</span>
            </div>
            <hr className="my-2" />
            <div className="flex justify-between font-semibold">
              <span>Trade-in Price:</span>
              <span className="text-green-600">د.إ {offerPrice}</span>
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            * Price taken directly from uploaded price data
          </p>
        </div>

        {/* Decision Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <Button 
            onClick={() => handleOfferDecision(false)}
            disabled={isProcessing}
            variant="outline"
            className="py-3 text-lg border-red-300 text-red-600 hover:bg-red-50"
          >
            <X size={20} className="mr-2" />
            Decline Offer
          </Button>
          <Button 
            onClick={() => handleOfferDecision(true)}
            disabled={isProcessing}
            className="py-3 text-lg bg-green-600 hover:bg-green-700 text-white"
          >
            <CheckCircle size={20} className="mr-2" />
            Accept Offer
          </Button>
        </div>

        <div className="text-center text-sm text-gray-500">
          <p>By accepting this offer, you agree to our trade-in terms and conditions.</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default TradeInOffer;
