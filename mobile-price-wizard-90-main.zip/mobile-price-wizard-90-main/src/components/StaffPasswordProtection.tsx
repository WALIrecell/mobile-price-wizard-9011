import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Lock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface StaffPasswordProtectionProps {
  onAuthenticated: () => void;
}

const StaffPasswordProtection: React.FC<StaffPasswordProtectionProps> = ({ onAuthenticated }) => {
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Check password - hardcoded as per requirement
    if (password === 'admin123') {
      sessionStorage.setItem('staff_authenticated', 'true');
      onAuthenticated();
      toast({
        title: "Access granted",
        description: "You can now use Staff Quick Entry.",
      });
    } else {
      toast({
        title: "Access denied",
        description: "Incorrect password. Please try again.",
        variant: "destructive",
      });
    }

    setIsLoading(false);
    setPassword('');
  };

  return (
    <div className="max-w-md mx-auto mt-8">
      <Card className="bg-white/80 backdrop-blur-sm border border-pink-200 shadow-lg">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 p-3 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full w-fit">
            <Lock className="h-6 w-6 text-white" />
          </div>
          <CardTitle className="text-xl bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
            Staff Access Required
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Input
                type="password"
                placeholder="Enter staff password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border-pink-200 focus:border-pink-500 focus:ring-pink-500"
                required
              />
            </div>
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white"
            >
              {isLoading ? 'Verifying...' : 'Access Staff Tools'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default StaffPasswordProtection;