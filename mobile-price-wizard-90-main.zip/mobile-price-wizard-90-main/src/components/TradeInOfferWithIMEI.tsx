import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, DollarSign, Smartphone } from 'lucide-react';
import { PhoneData } from '../pages/Index';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface PriceData {
  make: string;
  model: string;
  memorySize: string;
  gradeA: number;
  gradeB: number;
  gradeC: number;
  broken: number;
}

interface TradeInOfferWithIMEIProps {
  phoneData: PhoneData;
  priceData: PriceData[];
  onOfferDecision: (accepted: boolean, finalPrice?: number) => void;
}

const TradeInOfferWithIMEI: React.FC<TradeInOfferWithIMEIProps> = ({ 
  phoneData, 
  priceData, 
  onOfferDecision 
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const saveToGoogleSheets = async (offerStatus: string) => {
    try {
      console.log('=== TRADEIN OFFER: SAVING TO GOOGLE SHEETS ===');
      console.log('Offer status:', offerStatus);
      console.log('Complete phone data:', phoneData);
      console.log('Store ID from phone data:', phoneData.storeId);
      console.log('Store ID type:', typeof phoneData.storeId);
      console.log('Store ID length:', phoneData.storeId?.length);
      console.log('Condition from phone data:', phoneData.condition);
      
      // Convert report image to base64 if it exists
      let reportImageBase64 = '';
      if (phoneData.reportImage) {
        const reader = new FileReader();
        reportImageBase64 = await new Promise((resolve) => {
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(phoneData.reportImage!);
        });
      }

      const dataToSave = {
        make: phoneData.make,
        model: phoneData.model,
        storage: phoneData.storage,
        condition: phoneData.condition,
        batteryHealth: phoneData.batteryHealth,
        imeiNumber: phoneData.imeiNumber,
        storeId: phoneData.storeId,
        grade: phoneData.grade,
        price: phoneData.price || 0,
        mobileNumber: phoneData.mobileNumber,
        reportImage: reportImageBase64,
        offerStatus: offerStatus,
        testResults: phoneData.testResults || null
      };

      console.log('=== FINAL DATA OBJECT FOR SUPABASE ===');
      console.log('Data being sent:', dataToSave);
      console.log('Store ID being sent:', dataToSave.storeId);
      console.log('Condition being sent:', dataToSave.condition);

      const { data, error } = await supabase.functions.invoke('save-to-sheets', {
        body: dataToSave,
      });

      if (error) {
        console.error('Supabase function error:', error);
        throw error;
      }

      if (!data?.success) {
        console.error('Function returned failure:', data);
        throw new Error(data?.error || 'Failed to save to Google Sheets');
      }

      console.log('=== SUCCESS RESPONSE ===');
      console.log('Function response:', data);
      return true;
    } catch (error) {
      console.error('=== ERROR IN SAVE TO SHEETS ===');
      console.error('Error details:', error);
      toast({
        title: "Error saving data",
        description: "There was an error saving your decision. Please try again.",
        variant: "destructive"
      });
      return false;
    }
  };

  const handleAcceptOffer = async () => {
    setIsProcessing(true);
    
    const success = await saveToGoogleSheets('ACCEPTED');
    
    if (success) {
      toast({
        title: "Offer Accepted!",
        description: "Your trade-in offer has been accepted and saved.",
      });
      
      onOfferDecision(true, phoneData.price || 0);
    }
    
    setIsProcessing(false);
  };

  const handleRejectOffer = async () => {
    setIsProcessing(true);
    
    const success = await saveToGoogleSheets('REJECTED');
    
    if (success) {
      toast({
        title: "Offer Declined",
        description: "Your decision has been saved. Thank you for using our service.",
      });
      
      onOfferDecision(false, phoneData.price || 0);
    }
    
    setIsProcessing(false);
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <DollarSign className="text-blue-600" />
          Trade-In Offer
        </CardTitle>
        <p className="text-gray-600">
          Review your final offer
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Offer Details */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-semibold mb-3 flex items-center gap-2">
            <Smartphone size={16} />
            Device Information
          </h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div><span className="text-gray-600">Device:</span> {phoneData.make} {phoneData.model}</div>
            <div><span className="text-gray-600">Storage:</span> {phoneData.storage}</div>
            <div><span className="text-gray-600">Condition:</span> {phoneData.condition || 'Not specified'}</div>
            <div><span className="text-gray-600">Grade:</span> {phoneData.grade}</div>
            <div><span className="text-gray-600">Store ID:</span> {phoneData.storeId || 'Not provided'}</div>
          </div>
        </div>

        {/* Final Offer Price */}
        <div className="text-center space-y-3">
          <h4 className="font-semibold">Final Offer Price</h4>
          <div className="text-3xl font-bold text-green-600">د.إ {(phoneData.price || 0).toFixed(2)}</div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <Button 
            onClick={handleAcceptOffer}
            disabled={isProcessing}
            className="bg-green-600 hover:bg-green-700 text-white py-3 text-lg"
          >
            {isProcessing ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Processing...
              </div>
            ) : (
              <>
                <CheckCircle className="mr-2" size={20} />
                Accept Offer
              </>
            )}
          </Button>
          <Button 
            onClick={handleRejectOffer}
            disabled={isProcessing}
            variant="outline"
            className="py-3 text-lg"
          >
            {isProcessing ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                Processing...
              </div>
            ) : (
              <>
                <XCircle className="mr-2" size={20} />
                Reject Offer
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default TradeInOfferWithIMEI;
