
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, Smartphone, CheckCircle, Clock } from 'lucide-react';
import { PhoneData } from '../pages/Index';

interface PriceDisplayProps {
  phoneData: PhoneData;
  onContinue: () => void;
}

const PriceDisplay: React.FC<PriceDisplayProps> = ({ phoneData, onContinue }) => {
  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center bg-gradient-to-r from-green-50 to-blue-50">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <CheckCircle className="text-green-600" />
          Evaluation Complete
        </CardTitle>
        <p className="text-gray-600">
          Here's your phone's estimated value
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Price Display */}
        <div className="text-center py-8 bg-gradient-to-r from-green-100 to-blue-100 rounded-xl">
          <div className="flex items-center justify-center gap-2 mb-2">
            <DollarSign size={32} className="text-green-600" />
            <span className="text-5xl font-bold text-green-600">
              د.إ {phoneData.price}
            </span>
          </div>
          <p className="text-lg text-gray-600">Estimated Market Value</p>
          <Badge className="mt-2 bg-green-100 text-green-800">
            Grade {phoneData.grade} Condition
          </Badge>
        </div>

        {/* Phone Details Summary */}
        <div className="space-y-4">
          <h3 className="font-semibold text-lg">Device Summary</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Smartphone size={16} className="text-blue-600" />
                <span className="font-medium">Device</span>
              </div>
              <p className="text-sm text-gray-600">
                {phoneData.make} {phoneData.model}
              </p>
              <p className="text-sm text-gray-600">
                {phoneData.storage} Storage
              </p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle size={16} className="text-green-600" />
                <span className="font-medium">Condition</span>
              </div>
              <p className="text-sm text-gray-600">
                Grade {phoneData.grade} - {phoneData.condition}
              </p>
              {phoneData.batteryHealth && (
                <p className="text-sm text-gray-600">
                  {phoneData.batteryHealth}% Battery Health
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Contact Info */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Clock size={16} className="text-blue-600" />
            <span className="font-medium">Next Steps</span>
          </div>
          <p className="text-sm text-gray-600">
            Results will be sent to: {phoneData.mobileNumber}
          </p>
          <p className="text-sm text-gray-600">
            Upload your diagnostic report to complete the evaluation
          </p>
        </div>

        <Button 
          onClick={onContinue}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
        >
          Upload Diagnostic Report
        </Button>
      </CardContent>
    </Card>
  );
};

export default PriceDisplay;
