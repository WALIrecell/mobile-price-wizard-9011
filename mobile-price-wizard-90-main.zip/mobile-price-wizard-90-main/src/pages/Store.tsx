
import React from 'react';
import Index from './Index';

const Store = () => {
  return <Index />;
};

export default Store;
